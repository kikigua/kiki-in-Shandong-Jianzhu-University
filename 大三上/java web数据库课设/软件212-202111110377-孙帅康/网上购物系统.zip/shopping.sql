/*
 Navicat Premium Data Transfer

 Source Server         : text
 Source Server Type    : MySQL
 Source Server Version : 80031
 Source Host           : localhost:3306
 Source Schema         : shopping

 Target Server Type    : MySQL
 Target Server Version : 80031
 File Encoding         : 65001

 Date: 18/01/2024 11:46:44
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for classify
-- ----------------------------
DROP TABLE IF EXISTS `classify`;
CREATE TABLE `classify`  (
  `commodity_id` int(0) NOT NULL,
  `family_id` int(0) NOT NULL,
  PRIMARY KEY (`commodity_id`, `family_id`) USING BTREE,
  INDEX `family_id`(`family_id`) USING BTREE,
  CONSTRAINT `commodity_id` FOREIGN KEY (`commodity_id`) REFERENCES `commodity` (`commodity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `family_id` FOREIGN KEY (`family_id`) REFERENCES `commodity_family` (`family_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of classify
-- ----------------------------
INSERT INTO `classify` VALUES (1, 1);
INSERT INTO `classify` VALUES (8, 2);
INSERT INTO `classify` VALUES (9, 2);
INSERT INTO `classify` VALUES (11, 2);
INSERT INTO `classify` VALUES (6, 3);
INSERT INTO `classify` VALUES (7, 3);
INSERT INTO `classify` VALUES (10, 3);
INSERT INTO `classify` VALUES (11, 4);
INSERT INTO `classify` VALUES (2, 5);
INSERT INTO `classify` VALUES (3, 5);
INSERT INTO `classify` VALUES (4, 6);
INSERT INTO `classify` VALUES (1, 7);
INSERT INTO `classify` VALUES (5, 8);
INSERT INTO `classify` VALUES (3, 9);
INSERT INTO `classify` VALUES (5, 9);

-- ----------------------------
-- Table structure for commodity
-- ----------------------------
DROP TABLE IF EXISTS `commodity`;
CREATE TABLE `commodity`  (
  `commodity_id` int(0) NOT NULL AUTO_INCREMENT,
  `commodity_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `commodity_pic` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT '/img/goods/0.jpg',
  `commodity_num` int(0) NULL DEFAULT 0,
  `commodity_price` float(10, 2) NULL DEFAULT 0.00,
  `commodity_sale` int(0) NULL DEFAULT 0,
  `commodity_info` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `manager_id` int(0) NULL DEFAULT NULL,
  PRIMARY KEY (`commodity_id`) USING BTREE,
  UNIQUE INDEX `u_commodity_name`(`commodity_name`) USING BTREE,
  INDEX `comm_manager`(`manager_id`) USING BTREE,
  CONSTRAINT `comm_manager` FOREIGN KEY (`manager_id`) REFERENCES `managers` (`manager_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 57 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of commodity
-- ----------------------------
INSERT INTO `commodity` VALUES (1, '巧克力', '/img/goods/0.jpg', 100, 20.00, 780, '甜甜的', 1);
INSERT INTO `commodity` VALUES (2, '钢笔', '/img/goods/0.jpg', 260, 50.00, 230, '高端的笔尖，顺滑的书写', 1);
INSERT INTO `commodity` VALUES (3, '四六级真题', '/img/goods/0.jpg', 1000, 9.90, 500, '四六级冲刺，历年真题详解', 2);
INSERT INTO `commodity` VALUES (4, '999感冒灵', '/img/goods/0.jpg', 150, 15.00, 300, '感冒不用拍，快用999', 3);
INSERT INTO `commodity` VALUES (5, '边城（沈从文）', '/img/goods/0.jpg', 60, 45.00, 56, '徜徉知识的海洋，领略文学的魅力', 2);
INSERT INTO `commodity` VALUES (6, '手机壳', '/img/goods/0.jpg', 480, 13.00, 330, '小清新的风格，与众不同的设计', 4);
INSERT INTO `commodity` VALUES (7, '笔记本电脑', '/img/goods/0.jpg', 50, 4550.00, 30, '轻便、便携的笔记本电脑，随时随地办公', 4);
INSERT INTO `commodity` VALUES (8, '卫衣', '/img/goods/0.jpg', 99, 75.00, 90, '简约时尚，穿出自己的风格', 1);
INSERT INTO `commodity` VALUES (9, '牛仔裤', '/img/goods/0.jpg', 63, 89.00, 70, '简约时尚，百搭单品', 1);
INSERT INTO `commodity` VALUES (10, '数据线', '/img/goods/0.jpg', 123, 16.00, 58, '快速充电', 4);
INSERT INTO `commodity` VALUES (11, '手套', '/img/goods/0.jpg', 163, 12.00, 450, '保暖的必备品哦', 1);
INSERT INTO `commodity` VALUES (12, '棉服', '/img/goods/0.jpg', 100, 226.00, 0, '冬天到了，你缺一件它', 1);
INSERT INTO `commodity` VALUES (13, '板蓝根颗粒', '/img/goods/0.jpg', 127, 8.90, 860, '仲景 板蓝根颗粒 10g×20袋 清热解毒凉血利咽 用于肺胃热盛所致的咽喉肿痛 急性扁桃体炎', 3);
INSERT INTO `commodity` VALUES (14, '111222333', '/img/goods/0.jpg', 123, 56.00, 0, '111222', 1);
INSERT INTO `commodity` VALUES (15, '222', '/img/goods/0.jpg', 0, 0.00, 0, '222', 2);
INSERT INTO `commodity` VALUES (16, '333', '/img/goods/0.jpg', 0, 0.00, 0, '333', 3);
INSERT INTO `commodity` VALUES (17, '444', '/img/goods/0.jpg', 0, 0.00, 0, '444', 4);
INSERT INTO `commodity` VALUES (18, '555666', '/img/goods/0.jpg', 123, 86.30, 0, '555666', 1);
INSERT INTO `commodity` VALUES (19, '66677', '/img/goods/0.jpg', 563, 53.90, 0, '66677', 1);
INSERT INTO `commodity` VALUES (23, '22223333333', '/img/goods/0.jpg', 423, 53.00, 0, '22222333333', 4);

-- ----------------------------
-- Table structure for commodity_family
-- ----------------------------
DROP TABLE IF EXISTS `commodity_family`;
CREATE TABLE `commodity_family`  (
  `family_id` int(0) NOT NULL AUTO_INCREMENT,
  `family_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`family_id`) USING BTREE,
  UNIQUE INDEX `u_family_name`(`family_name`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 40 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of commodity_family
-- ----------------------------
INSERT INTO `commodity_family` VALUES (32, '111');
INSERT INTO `commodity_family` VALUES (31, '123');
INSERT INTO `commodity_family` VALUES (33, '222');
INSERT INTO `commodity_family` VALUES (34, '333');
INSERT INTO `commodity_family` VALUES (36, '444');
INSERT INTO `commodity_family` VALUES (38, '456');
INSERT INTO `commodity_family` VALUES (37, '555');
INSERT INTO `commodity_family` VALUES (39, '896');
INSERT INTO `commodity_family` VALUES (17, '女装');
INSERT INTO `commodity_family` VALUES (5, '学习用品');
INSERT INTO `commodity_family` VALUES (10, '家电');
INSERT INTO `commodity_family` VALUES (3, '数码产品');
INSERT INTO `commodity_family` VALUES (8, '文学');
INSERT INTO `commodity_family` VALUES (7, '糖果');
INSERT INTO `commodity_family` VALUES (15, '美妆');
INSERT INTO `commodity_family` VALUES (6, '药品');
INSERT INTO `commodity_family` VALUES (2, '衣物');
INSERT INTO `commodity_family` VALUES (4, '针织品');
INSERT INTO `commodity_family` VALUES (1, '零食');

-- ----------------------------
-- Table structure for managers
-- ----------------------------
DROP TABLE IF EXISTS `managers`;
CREATE TABLE `managers`  (
  `manager_id` int(0) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `tel` varchar(11) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  PRIMARY KEY (`manager_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of managers
-- ----------------------------
INSERT INTO `managers` VALUES (1, '张三', '19862101623');
INSERT INTO `managers` VALUES (2, '李四', '19862101321');
INSERT INTO `managers` VALUES (3, '王五', '18523647952');
INSERT INTO `managers` VALUES (4, '李华', '15635462013');

-- ----------------------------
-- Table structure for order
-- ----------------------------
DROP TABLE IF EXISTS `order`;
CREATE TABLE `order`  (
  `order_id` int(0) NOT NULL,
  `orderstatus_id` int(0) NULL DEFAULT 1,
  `orderdate` timestamp(0) NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP(0),
  `manager_id` int(0) NULL DEFAULT NULL,
  `vip_id` int(0) NULL DEFAULT NULL,
  `countmoney` float(10, 2) NULL DEFAULT 0.00,
  PRIMARY KEY (`order_id`) USING BTREE,
  INDEX `order_status`(`orderstatus_id`) USING BTREE,
  INDEX `order_manager`(`manager_id`) USING BTREE,
  INDEX `order_vip`(`vip_id`) USING BTREE,
  CONSTRAINT `order_manager` FOREIGN KEY (`manager_id`) REFERENCES `managers` (`manager_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `order_status` FOREIGN KEY (`orderstatus_id`) REFERENCES `orderstatus` (`orderstatus_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `order_vip` FOREIGN KEY (`vip_id`) REFERENCES `vip` (`vip_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of order
-- ----------------------------
INSERT INTO `order` VALUES (1, 3, '2024-01-17 15:27:36', 2, 3, 0.00);
INSERT INTO `order` VALUES (2, 1, '2024-01-17 15:37:23', 2, 2, 0.00);
INSERT INTO `order` VALUES (3, 1, '2024-01-10 15:37:31', 1, 2, 180.00);
INSERT INTO `order` VALUES (6, 2, '2024-01-18 15:39:54', 1, 2, 66.00);
INSERT INTO `order` VALUES (7, 3, '2024-01-11 15:40:26', 3, 2, 88.00);
INSERT INTO `order` VALUES (9, 4, '2024-01-26 15:40:54', 2, 3, 59.00);
INSERT INTO `order` VALUES (10, 1, '2024-01-17 15:41:16', 2, 3, 59.00);

-- ----------------------------
-- Table structure for orderstatus
-- ----------------------------
DROP TABLE IF EXISTS `orderstatus`;
CREATE TABLE `orderstatus`  (
  `orderstatus_id` int(0) NOT NULL AUTO_INCREMENT,
  `orderstatus` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL DEFAULT '确认订单',
  PRIMARY KEY (`orderstatus_id`) USING BTREE,
  UNIQUE INDEX `orderstatus`(`orderstatus`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of orderstatus
-- ----------------------------
INSERT INTO `orderstatus` VALUES (4, '失效订单');
INSERT INTO `orderstatus` VALUES (3, '已发货订单');
INSERT INTO `orderstatus` VALUES (2, '已支付订单');
INSERT INTO `orderstatus` VALUES (5, '暂停订单');
INSERT INTO `orderstatus` VALUES (1, '确认订单');

-- ----------------------------
-- Table structure for product
-- ----------------------------
DROP TABLE IF EXISTS `product`;
CREATE TABLE `product`  (
  `vip_id` int(0) NOT NULL,
  `cart_id` int(0) NOT NULL,
  `commodity_id` int(0) NOT NULL,
  `grade` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `text` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `manager_id` int(0) NOT NULL,
  `flag` int(0) NOT NULL DEFAULT 0 COMMENT '0未通过，1通过',
  PRIMARY KEY (`commodity_id`, `cart_id`, `vip_id`) USING BTREE,
  INDEX `product_manager`(`manager_id`) USING BTREE,
  INDEX `vip_id`(`cart_id`) USING BTREE,
  CONSTRAINT `product_comm` FOREIGN KEY (`commodity_id`) REFERENCES `purchase` (`commodity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `product_ibfk_1` FOREIGN KEY (`cart_id`) REFERENCES `purchase` (`cart_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `product_manager` FOREIGN KEY (`manager_id`) REFERENCES `managers` (`manager_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of product
-- ----------------------------
INSERT INTO `product` VALUES (2, 2, 3, '一星', '真题很厚，但是题有错的', 2, 0);
INSERT INTO `product` VALUES (3, 2, 3, '一星', '真题很厚，但是题有错的', 2, 0);
INSERT INTO `product` VALUES (8, 2, 3, '一星', '真题很厚，但是题有错的', 2, 0);
INSERT INTO `product` VALUES (18, 2, 3, '一星', '真题很厚，但是题有错的', 2, 0);
INSERT INTO `product` VALUES (21, 2, 3, '一星', '真题很厚，但是题有错的', 2, 0);
INSERT INTO `product` VALUES (38, 2, 3, '一星', '真题很厚，但是题有错的', 2, 0);
INSERT INTO `product` VALUES (82, 2, 3, '一星', '真题很厚，但是题有错的', 2, 0);
INSERT INTO `product` VALUES (88, 2, 3, '一星', '真题很厚，但是题有错的', 2, 0);
INSERT INTO `product` VALUES (222, 2, 3, '一星', '真题很厚，但是题有错的', 2, 0);
INSERT INTO `product` VALUES (562, 2, 3, '一星', '真题很厚，但是题有错的', 2, 0);
INSERT INTO `product` VALUES (3, 3, 6, '一星', '手机壳太难用了，呕', 4, 0);
INSERT INTO `product` VALUES (4, 3, 6, '一星', '手机壳太难用了，呕', 4, 0);
INSERT INTO `product` VALUES (11, 3, 6, '一星', '手机壳太难用了，呕', 4, 0);
INSERT INTO `product` VALUES (20, 3, 6, '一星', '手机壳太难用了，呕', 4, 0);
INSERT INTO `product` VALUES (22, 3, 6, '一星', '手机壳太难用了，呕', 4, 0);
INSERT INTO `product` VALUES (33, 3, 6, '一星', '手机壳太难用了，呕', 4, 0);
INSERT INTO `product` VALUES (44, 3, 6, '一星', '手机壳太难用了，呕', 4, 0);
INSERT INTO `product` VALUES (80, 3, 6, '一星', '手机壳太难用了，呕', 4, 0);
INSERT INTO `product` VALUES (83, 3, 6, '一星', '手机壳太难用了，呕', 4, 0);
INSERT INTO `product` VALUES (333, 3, 6, '一星', '手机壳太难用了，呕', 4, 0);
INSERT INTO `product` VALUES (883, 3, 6, '一星', '手机壳太难用了，呕', 4, 0);
INSERT INTO `product` VALUES (5, 5, 8, '三星', '卫衣很棒，爱了爱了', 1, 1);
INSERT INTO `product` VALUES (15, 5, 8, '三星', '卫衣很棒，爱了爱了', 1, 1);
INSERT INTO `product` VALUES (24, 5, 8, '三星', '卫衣很棒，爱了爱了', 1, 1);
INSERT INTO `product` VALUES (25, 5, 8, '三星', '卫衣很棒，爱了爱了', 1, 1);
INSERT INTO `product` VALUES (35, 5, 8, '三星', '卫衣很棒，爱了爱了', 1, 1);
INSERT INTO `product` VALUES (51, 5, 8, '三星', '卫衣很棒，爱了爱了', 1, 1);
INSERT INTO `product` VALUES (55, 5, 8, '三星', '卫衣很棒，爱了爱了', 1, 1);
INSERT INTO `product` VALUES (415, 5, 8, '三星', '卫衣很棒，爱了爱了', 1, 1);
INSERT INTO `product` VALUES (865, 5, 8, '三星', '卫衣很棒，爱了爱了', 1, 1);
INSERT INTO `product` VALUES (885, 5, 8, '三星', '卫衣很棒，爱了爱了', 1, 1);
INSERT INTO `product` VALUES (4, 4, 9, '二星', '牛仔裤还可以，就是太厚了', 1, 1);
INSERT INTO `product` VALUES (7, 4, 9, '二星', '牛仔裤还可以，就是太厚了', 1, 1);
INSERT INTO `product` VALUES (14, 4, 9, '二星', '牛仔裤还可以，就是太厚了', 1, 1);
INSERT INTO `product` VALUES (24, 4, 9, '二星', '牛仔裤还可以，就是太厚了', 1, 1);
INSERT INTO `product` VALUES (34, 4, 9, '二星', '牛仔裤还可以，就是太厚了', 1, 1);
INSERT INTO `product` VALUES (37, 4, 9, '二星', '牛仔裤还可以，就是太厚了', 1, 1);
INSERT INTO `product` VALUES (44, 4, 9, '二星', '牛仔裤还可以，就是太厚了', 1, 1);
INSERT INTO `product` VALUES (70, 4, 9, '二星', '牛仔裤还可以，就是太厚了', 1, 1);
INSERT INTO `product` VALUES (87, 4, 9, '二星', '牛仔裤还可以，就是太厚了', 1, 1);
INSERT INTO `product` VALUES (94, 4, 9, '二星', '牛仔裤还可以，就是太厚了', 1, 1);
INSERT INTO `product` VALUES (224, 4, 9, '二星', '牛仔裤还可以，就是太厚了', 1, 1);

-- ----------------------------
-- Table structure for purchase
-- ----------------------------
DROP TABLE IF EXISTS `purchase`;
CREATE TABLE `purchase`  (
  `cart_id` int(0) NOT NULL,
  `commodity_id` int(0) NOT NULL,
  `good_nums` int(0) NOT NULL,
  PRIMARY KEY (`commodity_id`, `cart_id`) USING BTREE,
  INDEX `purch_cart`(`cart_id`) USING BTREE,
  CONSTRAINT `purch_cart` FOREIGN KEY (`cart_id`) REFERENCES `shopping_cart` (`cart_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `purch_comm` FOREIGN KEY (`commodity_id`) REFERENCES `commodity` (`commodity_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of purchase
-- ----------------------------
INSERT INTO `purchase` VALUES (1, 1, 17);
INSERT INTO `purchase` VALUES (1, 2, 1);
INSERT INTO `purchase` VALUES (2, 2, 1);
INSERT INTO `purchase` VALUES (3, 2, 1);
INSERT INTO `purchase` VALUES (1, 3, 1);
INSERT INTO `purchase` VALUES (3, 3, 3);
INSERT INTO `purchase` VALUES (5, 4, 3);
INSERT INTO `purchase` VALUES (2, 5, 2);
INSERT INTO `purchase` VALUES (3, 5, 2);
INSERT INTO `purchase` VALUES (3, 6, 1);
INSERT INTO `purchase` VALUES (4, 6, 2);
INSERT INTO `purchase` VALUES (1, 7, 1);
INSERT INTO `purchase` VALUES (3, 7, 2);
INSERT INTO `purchase` VALUES (5, 8, 2);
INSERT INTO `purchase` VALUES (3, 9, 3);
INSERT INTO `purchase` VALUES (4, 9, 2);

-- ----------------------------
-- Table structure for shopping_cart
-- ----------------------------
DROP TABLE IF EXISTS `shopping_cart`;
CREATE TABLE `shopping_cart`  (
  `cart_id` int(0) NOT NULL AUTO_INCREMENT,
  `capacity` int(0) NOT NULL DEFAULT 100,
  PRIMARY KEY (`cart_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 13 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of shopping_cart
-- ----------------------------
INSERT INTO `shopping_cart` VALUES (1, 100);
INSERT INTO `shopping_cart` VALUES (2, 200);
INSERT INTO `shopping_cart` VALUES (3, 100);
INSERT INTO `shopping_cart` VALUES (4, 100);
INSERT INTO `shopping_cart` VALUES (5, 100);
INSERT INTO `shopping_cart` VALUES (6, 100);
INSERT INTO `shopping_cart` VALUES (7, 100);
INSERT INTO `shopping_cart` VALUES (8, 100);
INSERT INTO `shopping_cart` VALUES (9, 100);
INSERT INTO `shopping_cart` VALUES (10, 100);
INSERT INTO `shopping_cart` VALUES (11, 100);
INSERT INTO `shopping_cart` VALUES (12, 100);
INSERT INTO `shopping_cart` VALUES (13, 100);

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user`  (
  `userid` int(0) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `realname` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `address` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `tel` varchar(11) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `cart_id` int(0) NULL DEFAULT NULL,
  `password` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL DEFAULT '123456',
  `money` float(10, 2) NULL DEFAULT 0.00 COMMENT '额度',
  PRIMARY KEY (`userid`) USING BTREE,
  UNIQUE INDEX `u_username`(`username`) USING BTREE,
  INDEX `user_cart`(`cart_id`) USING BTREE,
  CONSTRAINT `user_cart` FOREIGN KEY (`cart_id`) REFERENCES `shopping_cart` (`cart_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 522 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES (1, '123', '1', '港沟街道', '123456456', 1, '123456', 0.00);
INSERT INTO `user` VALUES (3, '王老二', '1', '港沟街道', '1315555555', 2, '123456', 0.00);
INSERT INTO `user` VALUES (4, '王老五', '1', '港沟街道', '1311111111', 4, '123456', 0.00);
INSERT INTO `user` VALUES (5, '王1', '1', '刚沟街道', '1111', 1, '123456', 0.00);
INSERT INTO `user` VALUES (6, '王五', '1', '他突然个人', '3434', 2, '123456', 0.00);
INSERT INTO `user` VALUES (7, '王菲', '1', '港沟街道', '11112345678', 1, '123456', 0.00);
INSERT INTO `user` VALUES (8, '五五五五', '1', '灌灌灌灌', '11112345679', 1, '123456', 0.00);
INSERT INTO `user` VALUES (9, '王大', '1', '高端市场广东省', '1123456789', 1, '123456', 0.00);
INSERT INTO `user` VALUES (10, '王大大', '1', '达到顶峰', '34', 1, '123456', 0.00);
INSERT INTO `user` VALUES (11, '黑龙', '1', '该法规规范', '1123456789', 1, '123456', 0.00);
INSERT INTO `user` VALUES (12, '王二', '1', '黑龙江', '1123456789', 1, '123456', 0.00);
INSERT INTO `user` VALUES (13, '王4', '1', '钢构阶段', '11', 1, '123456', 0.00);
INSERT INTO `user` VALUES (14, '王铎', '1', '钢构阶段', '11', 1, '123456', 0.00);
INSERT INTO `user` VALUES (15, '汪诗诗', '1', '港沟街道', '11', 2, '123456', 0.00);
INSERT INTO `user` VALUES (16, '王3', '1', '港沟街道', '11', 1, '123456', 0.00);
INSERT INTO `user` VALUES (17, '王6', '1', '港沟街道', '1111', 2, '123456', 0.00);
INSERT INTO `user` VALUES (19, '王8', '1', '港沟街道', '1234', 2, '123456', 0.00);
INSERT INTO `user` VALUES (20, '王汪汪', '1', '港沟街道', '1111', 2, '123456', 0.00);
INSERT INTO `user` VALUES (21, '汪汪汪', '1', '港沟街道', '11', 2, '123456', 0.00);
INSERT INTO `user` VALUES (22, '王2', '1', '对方的', '1123456789', 1, '123456', 0.00);
INSERT INTO `user` VALUES (24, '王梅', '1', '港沟街道', '1234567890', 2, '123456', 0.00);
INSERT INTO `user` VALUES (25, '王7', '1', '港沟街道', '1234567890', 3, '123456', 0.00);
INSERT INTO `user` VALUES (27, '王9', '1', '港沟街道', '1111', 2, '123456', 0.00);
INSERT INTO `user` VALUES (28, '王义', '1', '港沟街道', '11', 1, '123456', 0.00);
INSERT INTO `user` VALUES (122, '王孝', '1', '嘿嘿嘿', '11', 1, '123456', 0.00);
INSERT INTO `user` VALUES (152, '王狗', '1', '港沟街道', '11', 2, '123456', 0.00);
INSERT INTO `user` VALUES (177, '王柳', '1', '港沟街道', '1111', 1, '123456', 0.00);
INSERT INTO `user` VALUES (211, '往里', '1', '港沟街道', '11', 1, '123456', 0.00);
INSERT INTO `user` VALUES (216, '王美丽', '1', '港沟街道', '1111', 1, '123456', 0.00);
INSERT INTO `user` VALUES (242, '王丽', '1', '港沟街道', '33', 3, '123456', 0.00);
INSERT INTO `user` VALUES (321, '王后', '1', '港沟街道', '111', 3, '123456', 0.00);
INSERT INTO `user` VALUES (413, '王王', '1', '港沟街道', '1123', 2, '123456', 0.00);

-- ----------------------------
-- Table structure for vip
-- ----------------------------
DROP TABLE IF EXISTS `vip`;
CREATE TABLE `vip`  (
  `vip_id` int(0) NOT NULL AUTO_INCREMENT,
  `vgrade` int(0) NOT NULL DEFAULT 1 COMMENT '一级：五千 二级：两万  三级：五万',
  `userid` int(0) NOT NULL,
  `count` float(10, 2) NULL DEFAULT 1.00 COMMENT '折扣',
  PRIMARY KEY (`vip_id`) USING BTREE,
  INDEX `vip_user`(`userid`) USING BTREE,
  CONSTRAINT `vip_user` FOREIGN KEY (`userid`) REFERENCES `user` (`userid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of vip
-- ----------------------------
INSERT INTO `vip` VALUES (2, 1, 1, 1.00);
INSERT INTO `vip` VALUES (3, 2, 3, 0.80);
INSERT INTO `vip` VALUES (10, 1, 1, 1.00);
INSERT INTO `vip` VALUES (20, 1, 1, 1.00);

-- ----------------------------
-- View structure for hotgoods
-- ----------------------------
DROP VIEW IF EXISTS `hotgoods`;
CREATE ALGORITHM = UNDEFINED SQL SECURITY DEFINER VIEW `hotgoods` AS select `commodity`.`commodity_id` AS `commodity_id`,`commodity`.`commodity_name` AS `commodity_name`,`commodity`.`commodity_pic` AS `commodity_pic`,`commodity`.`commodity_num` AS `commodity_num`,`commodity`.`commodity_price` AS `commodity_price`,`commodity`.`commodity_sale` AS `commodity_sale`,`commodity`.`commodity_info` AS `commodity_info`,`commodity`.`manager_id` AS `manager_id` from `commodity` order by `commodity`.`commodity_sale` desc limit 10;

-- ----------------------------
-- View structure for onekind
-- ----------------------------
DROP VIEW IF EXISTS `onekind`;
CREATE ALGORITHM = UNDEFINED SQL SECURITY DEFINER VIEW `onekind` AS select `commodity`.`commodity_id` AS `commodity_id`,`commodity`.`commodity_name` AS `commodity_name`,`commodity`.`commodity_pic` AS `commodity_pic`,`commodity`.`commodity_num` AS `commodity_num`,`commodity`.`commodity_price` AS `commodity_price`,`commodity`.`commodity_sale` AS `commodity_sale`,`commodity`.`commodity_info` AS `commodity_info`,`commodity`.`manager_id` AS `manager_id` from ((`commodity` join `commodity_family`) join `classify`) where ((`commodity`.`commodity_id` = `classify`.`commodity_id`) and (`commodity_family`.`family_id` = `classify`.`family_id`) and (`commodity_family`.`family_name` = '衣物'))  WITH CASCADED CHECK OPTION;

-- ----------------------------
-- Procedure structure for InsertCommodity
-- ----------------------------
DROP PROCEDURE IF EXISTS `InsertCommodity`;
delimiter ;;
CREATE PROCEDURE `InsertCommodity`(IN `commodity_name` varchar(255),IN `commodity_num` int(10),IN `commodity_price` float(10,2),IN `commodity_info` varchar(255),IN `manager_id` int(10))
BEGIN
	#Routine body goes here...
	INSERT INTO `commodity`(`commodity_name`,`commodity_num`,`commodity_price`,`commodity_info`,`manager_id`)
	VALUES(commodity_name,commodity_num,commodity_price,commodity_info,manager_id);
END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for search
-- ----------------------------
DROP PROCEDURE IF EXISTS `search`;
delimiter ;;
CREATE PROCEDURE `search`(IN `searchkey` varchar(100))
BEGIN
	#Routine body goes here...
	SELECT * FROM `commodity`,`commodity_family`,`classify` WHERE commodity.commodity_id = classify.commodity_id AND commodity_family.family_id = classify.family_id AND (commodity_family.family_name LIKE "%searchkey%" OR commodity.commodity_name LIKE "%searchkey%") ORDER BY `commodity_sale` DESC,`commodity_price` ASC;
END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for searchgood
-- ----------------------------
DROP PROCEDURE IF EXISTS `searchgood`;
delimiter ;;
CREATE PROCEDURE `searchgood`(IN `searchkey` varchar(100),OUT `commodity_id` int(10),OUT `commodity_name` varchar(100),OUT `commodity_pic` varchar(100),OUT `commodity_num` int(10),OUT `commodity_price` float(10,2),OUT `commodity_sale` int(10),OUT `commodity_info` varchar(100),OUT `manager_id` int(10))
BEGIN
	#Routine body goes here...
	SELECT DISTINCT commodity.commodity_id INTO commodity_id FROM `commodity`,`commodity_family`,`classify` WHERE commodity.commodity_id = classify.commodity_id AND commodity_family.family_id = classify.family_id AND (commodity_family.family_name LIKE "%searchkey%" OR commodity.commodity_name LIKE "%searchkey%") ORDER BY `commodity_sale` DESC,`commodity_price` ASC;
	SELECT DISTINCT commodity.commodity_name INTO commodity_name FROM `commodity`,`commodity_family`,`classify` WHERE commodity.commodity_id = classify.commodity_id AND commodity_family.family_id = classify.family_id AND (commodity_family.family_name LIKE "%searchkey%" OR commodity.commodity_name LIKE "%searchkey%") ORDER BY `commodity_sale` DESC,`commodity_price` ASC;
	SELECT DISTINCT commodity.commodity_price INTO commodity_price FROM `commodity`,`commodity_family`,`classify` WHERE commodity.commodity_id = classify.commodity_id AND commodity_family.family_id = classify.family_id AND (commodity_family.family_name LIKE "%searchkey%" OR commodity.commodity_name LIKE "%searchkey%") ORDER BY `commodity_sale` DESC,`commodity_price` ASC;
	SELECT DISTINCT commodity.commodity_num INTO commodity_num FROM `commodity`,`commodity_family`,`classify` WHERE commodity.commodity_id = classify.commodity_id AND commodity_family.family_id = classify.family_id AND (commodity_family.family_name LIKE "%searchkey%" OR commodity.commodity_name LIKE "%searchkey%") ORDER BY `commodity_sale` DESC,`commodity_price` ASC;
	SELECT DISTINCT commodity.commodity_sale INTO commodity_sale FROM `commodity`,`commodity_family`,`classify` WHERE commodity.commodity_id = classify.commodity_id AND commodity_family.family_id = classify.family_id AND (commodity_family.family_name LIKE "%searchkey%" OR commodity.commodity_name LIKE "%searchkey%") ORDER BY `commodity_sale` DESC,`commodity_price` ASC;
	SELECT DISTINCT commodity.commodity_pic INTO commodity_pic FROM `commodity`,`commodity_family`,`classify` WHERE commodity.commodity_id = classify.commodity_id AND commodity_family.family_id = classify.family_id AND (commodity_family.family_name LIKE "%searchkey%" OR commodity.commodity_name LIKE "%searchkey%") ORDER BY `commodity_sale` DESC,`commodity_price` ASC;
	SELECT DISTINCT commodity.commodity_info INTO commodity_info FROM `commodity`,`commodity_family`,`classify` WHERE commodity.commodity_id = classify.commodity_id AND commodity_family.family_id = classify.family_id AND (commodity_family.family_name LIKE "%searchkey%" OR commodity.commodity_name LIKE "%searchkey%") ORDER BY `commodity_sale` DESC,`commodity_price` ASC;
	SELECT DISTINCT commodity.manager_id INTO manager_id FROM `commodity`,`commodity_family`,`classify` WHERE commodity.commodity_id = classify.commodity_id AND commodity_family.family_id = classify.family_id AND (commodity_family.family_name LIKE "%searchkey%" OR commodity.commodity_name LIKE "%searchkey%") ORDER BY `commodity_sale` DESC,`commodity_price` ASC;
END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for select_commodityFamily_key
-- ----------------------------
DROP PROCEDURE IF EXISTS `select_commodityFamily_key`;
delimiter ;;
CREATE PROCEDURE `select_commodityFamily_key`(IN `good_kind_key` varchar(255),OUT `commodity_name` varchar(255),OUT `commodity_price` float(10,2),OUT `commodity_sale` int(10),OUT `commodity_num` int(10),OUT `commodity_pic` varchar(255))
BEGIN
	#Routine body goes here...
	SELECT `commodity_name` INTO commodity_name FROM `commodity`,`commodity_family`,`classify` WHERE commodity.commodity_id = classify.commodity_id AND commodity_family.family_id = classify.family_id AND commodity_family.family_name LIKE "%good_kind_key%" ORDER BY `commodity_sale` DESC,`commodity_price` ASC;
	SELECT `commodity_price` INTO commodity_price FROM `commodity`,`commodity_family`,`classify` WHERE commodity.commodity_id = classify.commodity_id AND commodity_family.family_id = classify.family_id AND commodity_family.family_name LIKE "%good_kind_key%" ORDER BY `commodity_sale` DESC,`commodity_price` ASC;
	SELECT `commodity_num` INTO commodity_num FROM `commodity`,`commodity_family`,`classify` WHERE commodity.commodity_id = classify.commodity_id AND commodity_family.family_id = classify.family_id AND commodity_family.family_name LIKE "%good_kind_key%" ORDER BY `commodity_sale` DESC,`commodity_price` ASC;
	SELECT `commodity_sale` INTO commodity_sale FROM `commodity`,`commodity_family`,`classify` WHERE commodity.commodity_id = classify.commodity_id AND commodity_family.family_id = classify.family_id AND commodity_family.family_name LIKE "%good_kind_key%" ORDER BY `commodity_sale` DESC,`commodity_price` ASC;
	SELECT `commodity_pic` INTO commodity_pic FROM `commodity`,`commodity_family`,`classify` WHERE commodity.commodity_id = classify.commodity_id AND commodity_family.family_id = classify.family_id AND commodity_family.family_name LIKE "%good_kind_key%" ORDER BY `commodity_sale` DESC,`commodity_price` ASC;
END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for select_commodityName_key
-- ----------------------------
DROP PROCEDURE IF EXISTS `select_commodityName_key`;
delimiter ;;
CREATE PROCEDURE `select_commodityName_key`(IN `good_name_key` varchar(255),OUT `commodity_name` varchar(255),OUT `commodity_price` float(10,2),OUT `commodity_sale` int(10),OUT `commodity_num` int(10),OUT `commodity_pic` varchar(255))
BEGIN
	#Routine body goes here...
	SELECT `commodity_name` INTO commodity_name FROM `commodity` WHERE `commodity_name` LIKE "%good_name_key%" ORDER BY `commodity_sale` DESC,`commodity_price` ASC;
	SELECT `commodity_price` INTO commodity_price FROM `commodity` WHERE `commodity_name` LIKE "%good_name_key%" ORDER BY `commodity_sale` DESC,`commodity_price` ASC;
	SELECT `commodity_num` INTO commodity_num FROM `commodity` WHERE `commodity_name` LIKE "%good_name_key%" ORDER BY `commodity_sale` DESC,`commodity_price` ASC;
	SELECT `commodity_sale` INTO commodity_sale FROM `commodity` WHERE `commodity_name` LIKE "%good_name_key%" ORDER BY `commodity_sale` DESC,`commodity_price` ASC;
	SELECT `commodity_pic` INTO commodity_pic FROM `commodity` WHERE `commodity_name` LIKE "%good_name_key%" ORDER BY `commodity_sale` DESC,`commodity_price` ASC;
END
;;
delimiter ;

SET FOREIGN_KEY_CHECKS = 1;
