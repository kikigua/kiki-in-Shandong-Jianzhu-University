<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>我的信息</title>
</head>
<body>
<form class="form-horizontal " class="modal-content">
			<fieldset>
				<legend>Bootstrap 支持的控件</legend>
				<div class="control-group">
					<label class="control-label" for="input01">文本输入</label>
					<div class="controls">
						<input type="text" class="input-xlarge" id="input01">
						<p class="help-block">除了自由格式文本，一些HTML5基于文本的输入像这样呈现</p>
					</div>
				</div>
				<div class="control-group">
					<label class="control-label" for="optionsCheckbox">确认框</label>
				</div>
				<div class="control-group">
					<label class="control-label" for="select01">选择列表</label>
					<div class="controls">
						<select id="select01">
							<option>something</option>
							<option>2</option>
							<option>3</option>
							<option>4</option>
							<option>5</option>
						</select>
					</div>
				</div>
				<div class="control-group">
					<label class="control-label" for="textarea">文本区域</label>
					<div class="controls">
						<textarea class="input-xlarge" id="textarea" rows="3"></textarea>
					</div>
				</div>
				<div class="form-actions">
					<button type="submit" class="btn btn-primary">确定</button>
				</div>
			</fieldset>
		</form>
</body>
</html>