<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8" import="java.util.List,bean.*"%>
<%@taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>用户详情</title>
</head>
<!-- 新 Bootstrap4 核心 CSS 文件 -->
<link rel="stylesheet" href="https://cdn.staticfile.org/twitter-bootstrap/4.3.1/css/bootstrap.min.css">
 
<!-- jQuery文件。务必在bootstrap.min.js 之前引入 -->
<script src="https://cdn.staticfile.org/jquery/3.2.1/jquery.min.js"></script>
 
<!-- 用于弹窗、提示、下拉菜单，包含了 popper.min.js -->
<script src="https://cdn.staticfile.org/popper.js/1.15.0/umd/popper.min.js"></script>
 
<!-- 最新的 Bootstrap4 核心 JavaScript 文件 -->
<script src="https://cdn.staticfile.org/twitter-bootstrap/4.3.1/js/bootstrap.min.js"></script>
<body>
	<div class="container pb-5">
		<%
			UserBean user = (UserBean) request.getAttribute("userInfo");
			String path = request.getContextPath();
			String basePath = request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort()
					+ path;
		%>
		<div
			class="d-flex flex-row justify-content-between align-items-center">
			<h3 class="px-2 pt-5">用户信息</h3>
			<form action="/shopping/SearchUser" method="post" class="px-2 pt-5">
			</form>
		</div>
		<div class="row justify-content-between align-items-center px-2 pt-5">
			<div class="justify-content-center align-items-center col-md-6">
			</div>
		<div class="info1">
			<div class="col-md-6 pt-4">
				<h5>${userInfo.userid }</h5>
				<form action="" method="" 
					>
					<table class="table">
						<tr class="p-1">
							<td style="width: 8rem">用户id</td>
							<td>${userInfo.userid}</td>
						</tr>
						<tr class="p-1">
							<td style="width: 8rem">用户姓名</td>
							<td>${userInfo.username}</td>
						</tr>
						<tr class="p-1">
							<td style="width: 8rem">用户真实姓名</td>
							<td>${userInfo.realname}</td>
						</tr>
						<tr class="p-1">
							<td style="width: 8rem">用户地址</td>
							<td>${userInfo.address}</td>
						</tr>
						<tr class="p-1">
							<td style="width: 8rem">用户电话号码</td>
							<td>${userInfo.tel}</td>
						</tr>
						<tr class="p-1">
							<td style="width: 8rem">用户购物车编号</td>
							<td>${userInfo.cart_id}</td>
						</tr>
						<tr class="p-1">
							<td style="width: 8rem">用户密码</td>
							<td style="color: rgba(255, 0, 0, 0.8)">${userInfo.password}</td>
						</tr>
						<tr class="p-1">
							<td style="width: 8rem">用户额度</td>
							<td>${userInfo.money}</td>
						</tr>
												
					</table>
					<div class="justify-content-center align-items-center">
						<button  background-color:rgba(255, 0, 0, 0.8);"><a class="btn btn-default" href="/shopping/ListUsers">back</a></button>
					</div>
				</form>
			</div>
		</div>
		</div>
	</div>
</body>
<style>
body{
background-color:rgba(13,110,253,.25);
}
button {
	border: none;
}
.info1{
margin-left:3px;
}
.info1 tr{
border:#574d4d96 40px;}
.p-1{
border:#574d4d96 40px;
}
</style>
</html>