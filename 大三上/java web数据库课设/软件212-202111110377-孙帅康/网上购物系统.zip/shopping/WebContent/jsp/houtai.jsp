<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8" import="java.util.List,util.*"%>
<%@taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>后台界面</title>
<!-- 新 Bootstrap4 核心 CSS 文件 -->
<link rel="stylesheet" href="https://cdn.staticfile.org/twitter-bootstrap/4.3.1/css/bootstrap.min.css">
 
<!-- jQuery文件。务必在bootstrap.min.js 之前引入 -->
<script src="https://cdn.staticfile.org/jquery/3.2.1/jquery.min.js"></script>
 
<!-- 用于弹窗、提示、下拉菜单，包含了 popper.min.js -->
<script src="https://cdn.staticfile.org/popper.js/1.15.0/umd/popper.min.js"></script>
 
<!-- 最新的 Bootstrap4 核心 JavaScript 文件 -->
<script src="https://cdn.staticfile.org/twitter-bootstrap/4.3.1/js/bootstrap.min.js"></script>
<%-- 	<link rel="stylesheet" href="./css/reset.css" />
    <link rel="stylesheet" href="./css/content.css" />
    <link rel="stylesheet" href="./css/public.css" />
    --%>
     <link rel="stylesheet" href="./css/product.css" />
     
</head>

<body>
<div class="houtai1">
<ul>
  <li><a href="/shopping/ListProducts" >用户评论</a></li>
    <li><a href="/shopping/ListGoodsM" >商品管理</a></li>
  <li><a href="/shopping/listProductPass">通过评论</a></li>
  <li><a href="/shopping/ListUsers">用户信息</a></li>
  <%-- <li><a href="/shopping/ListUsersVip">会员信息</a></li> --%>
  
   <li><a href="/shopping/ListOrders">订单信息</a></li>
</ul>
</div>

<div id="bar-chart">
	<div class="graph">
		<ul class="x-axis">
			<li><span>商品</span></li>
			<li><span>用户</span></li>
			<li><span>评价</span></li>
			<li><span>会员</span></li>
			<li><span>订单</span></li>
		</ul>
		<ul class="y-axis">
			<li><span>20</span></li>
			<li><span>15</span></li>
			<li><span>10</span></li>
			<li><span>5</span></li>
			<li><span>0</span></li>
		</ul>
		<div class="bars">
			<div class="bar-group">
				<div class="bar bar-1 stat-1" style="height: 51%;">      
					<span>4080</span>
				</div>
				<div class="bar bar-2 stat-2" style="height: 71%;">
					<span>5680</span>
				</div>
				<div class="bar bar-3 stat-3" style="height: 13%;">
					<span>1040</span>
				</div>
			</div>
			
			<div class="bar-group">
				<div class="bar bar-4 stat-1" style="height: 76%;">
					<span>6080</span>
				</div>
				<div class="bar bar-5 stat-2" style="height: 86%;">
					<span>6880</span>
				</div>
				<div class="bar bar-6 stat-3" style="height: 22%;">
					<span>1760</span>
				</div>
			</div>
			
			<div class="bar-group">
				<div class="bar bar-7 stat-1" style="height: 78%;">
					<span>6240</span>
				</div>
				<div class="bar bar-8 stat-2" style="height: 72%;">
					<span>5760</span>
				</div>
				<div class="bar bar-9 stat-3" style="height: 36%;">
					<span>2880</span>
				</div>
			</div>
			
			<div class="bar-group">
				<div class="bar bar-10 stat-1" style="height: 44%;">
					<span>3520</span>
				</div>
				<div class="bar bar-11 stat-2" style="height: 64%;">
					<span>5120</span>
				</div>
				<div class="bar bar-12 stat-3" style="height: 59%">
					<span>4720</span>
				</div>
			</div>
			
			<div class="bar-group">
				<div class="bar bar-13 stat-1" style="height: 28%;">
					<span>2240</span>
				</div>
				<div class="bar bar-14 stat-2" style="height: 33%;">
					<span>2640</span>
				</div>
				<div class="bar bar-15 stat-3" style="height: 94%;">
					<span>7520</span>
				</div>
			</div>
		</div>
	</div>
</div> 


</body>
<style>
.houtai1{
text-align:center;
font-size:20px;

height:100px;
}
.houtai1 ul {
padding-left:100px;
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}

.houtai1 li {
    float: left;
}

.houtai1 li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

.houtai1 li a:hover {
      background-color: #f7e18b;
}
.houtai1 a {
	text-decoration: none;
	color: rgba(0, 0, 0, 0.6);
}

.houtai1 a:hover {
	color: rgba(0, 0, 0, 0.8);
}

body {
	background-color: rgba(135, 206, 250, 0.1);
	width: 100vw;
	text-center:
	height: 100vh;
	padding: 0;
	margin: 0
}

.container a{
	border:1px #a3a59csolid;
	background-color: #c0c0c0;


}
.container .tou{
	border-bottom:1px solid #bec2c1;
	margin-top: 30px;
	padding-bottom: 10px;
}




@-webkit-keyframes animate-width {
  0% {
    width: 0;
  }
  100% {
    visibility: visible;
  }
}
@-moz-keyframes animate-width {
  0% {
    width: 0;
  }
  100% {
    visibility: visible;
  }
}
@keyframes animate-width {
  0% {
    width: 0;
  }
  100% {
    visibility: visible;
  }
}
@-webkit-keyframes animate-height {
  0% {
    height: 0;
  }
  100% {
    visibility: visible;
  }
}
@-moz-keyframes animate-height {
  0% {
    height: 0;
  }
  100% {
    visibility: visible;
  }
}
@keyframes animate-height {
  0% {
    height: 0;
  }
  100% {
    visibility: visible;
  }
}
body {
  background-color: #3b4150;
  font-family: arial, sans-serif;
  color: #cdcdcd;
}

#bar-chart {
  height: 380px;
  width: 70%;
  position: relative;
  margin: 50px auto 0;
}
#bar-chart * {
  box-sizing: border-box;
}
#bar-chart .graph {
  height: 283px;
  position: relative;
}
#bar-chart .bars {
  height: 253px;
  padding: 0 2%;
  position: absolute;
  width: 100%;
  z-index: 10;
}
#bar-chart .bar-group {
  display: block;
  float: left;
  height: 100%;
  position: relative;
  width: 12%;
  margin-right: 10%;
}
#bar-chart .bar-group:last-child {
  margin-right: 0;
}
#bar-chart .bar-group .bar {
  visibility: hidden;
  height: 0;
  -webkit-animation: animate-height;
  -moz-animation: animate-height;
  animation: animate-height;
  animation-timing-function: cubic-bezier(0.35, 0.95, 0.67, 0.99);
  -webkit-animation-timing-function: cubic-bezier(0.35, 0.95, 0.67, 0.99);
  -moz-animation-timing-function: cubic-bezier(0.35, 0.95, 0.67, 0.99);
  animation-duration: 0.4s;
  -webkit-animation-duration: 0.4s;
  -moz-animation-duration: 0.4s;
  animation-fill-mode: forwards;
  -webkit-animation-fill-mode: forwards;
  box-shadow: 1px 0 2px rgba(0, 0, 0, 0.15);
  border: 1px solid #2d2d2d;
  border-radius: 3px 3px 0 0;
  bottom: 0;
  cursor: pointer;
  height: 0;
  position: absolute;
  text-align: center;
  width: 25%;
}
#bar-chart .bar-group .bar:nth-child(2) {
  left: 35%;
}
#bar-chart .bar-group .bar:nth-child(3) {
  left: 70%;
}
#bar-chart .bar-group .bar span {
  display: none;
}
#bar-chart .bar-group .bar-1 {
  animation-delay: 0.3s;
  -webkit-animation-delay: 0.3s;
}
#bar-chart .bar-group .bar-2 {
  animation-delay: 0.4s;
  -webkit-animation-delay: 0.4s;
}
#bar-chart .bar-group .bar-3 {
  animation-delay: 0.5s;
  -webkit-animation-delay: 0.5s;
}
#bar-chart .bar-group .bar-4 {
  animation-delay: 0.6s;
  -webkit-animation-delay: 0.6s;
}
#bar-chart .bar-group .bar-5 {
  animation-delay: 0.7s;
  -webkit-animation-delay: 0.7s;
}
#bar-chart .bar-group .bar-6 {
  animation-delay: 0.8s;
  -webkit-animation-delay: 0.8s;
}
#bar-chart .bar-group .bar-7 {
  animation-delay: 0.9s;
  -webkit-animation-delay: 0.9s;
}
#bar-chart .bar-group .bar-8 {
  animation-delay: 1s;
  -webkit-animation-delay: 1s;
}
#bar-chart .bar-group .bar-9 {
  animation-delay: 1.1s;
  -webkit-animation-delay: 1.1s;
}
#bar-chart .bar-group .bar-10 {
  animation-delay: 1.2s;
  -webkit-animation-delay: 1.2s;
}
#bar-chart .bar-group .bar-11 {
  animation-delay: 1.3s;
  -webkit-animation-delay: 1.3s;
}
#bar-chart .bar-group .bar-12 {
  animation-delay: 1.4s;
  -webkit-animation-delay: 1.4s;
}
#bar-chart .bar-group .bar-13 {
  animation-delay: 1.5s;
  -webkit-animation-delay: 1.5s;
}
#bar-chart .bar-group .bar-14 {
  animation-delay: 1.6s;
  -webkit-animation-delay: 1.6s;
}
#bar-chart .bar-group .bar-15 {
  animation-delay: 1.7s;
  -webkit-animation-delay: 1.7s;
}
#bar-chart ul {
  list-style: none;
  margin: 0;
  padding: 0;
}
#bar-chart .x-axis {
  bottom: 0;
  position: absolute;
  text-align: center;
  width: 100%;
}
#bar-chart .x-axis li {
  float: left;
  margin-right: 10.5%;
  font-size: 11px;
  width: 11.5%;
}
#bar-chart .x-axis li:last-child {
  margin-right: 0;
}
#bar-chart .y-axis {
  position: absolute;
  text-align: right;
  width: 100%;
}
#bar-chart .y-axis li {
  border-top: 1px solid #4e5464;
  display: block;
  height: 63.25px;
  width: 100%;
}
#bar-chart .y-axis li span {
  display: block;
  font-size: 11px;
  margin: -10px 0 0 -60px;
  padding: 0 10px;
  width: 40px;
}
#bar-chart .stat-1 {
  background-image: -webkit-linear-gradient(left, #ff4500 0%, #ff4500 47%, #cf3a02 50%, #cf3a02 100%);
  background-image: linear-gradient(to right, #ff4500 0%, #ff4500 47%, #cf3a02 50%, #cf3a02 100%);
}
#bar-chart .stat-2 {
  background-image: -webkit-linear-gradient(left, #b8f123 0%, #b8f123 47%, #79a602 50%, #79a602 100%);
  background-image: linear-gradient(to right, #b8f123 0%, #b8f123 47%, #79a602 50%, #79a602 100%);
}
#bar-chart .stat-3 {
  background-image: -webkit-linear-gradient(left, #00c5ff 0%, #00c5ff 47%, #0383a9 50%, #0383a9 100%);
  background-image: linear-gradient(to right, #00c5ff 0%, #00c5ff 47%, #0383a9 50%, #0383a9 100%);
}

</style>
</html>