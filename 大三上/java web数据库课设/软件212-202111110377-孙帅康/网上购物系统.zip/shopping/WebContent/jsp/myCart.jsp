<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8" import="java.util.List,bean.CartBean"%>
<%@taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>我的购物车</title>
</head>
<link
	href="https://cdn.bootcss.com/bootstrap/3.3.7/css/bootstrap.min.css"
	rel="stylesheet">
<script src="https://cdn.bootcss.com/jquery/2.1.1/jquery.min.js"></script>
<script
	src="https://cdn.bootcss.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script type="text/javascript">
	function deletecart(id) {
		if (confirm("确认要删除吗？")) {

			window.location.href = '/shopping/CartServlet?cartID='
					+ cartID.value + '&commID=' + commID.value;
		}
	}
	function clearcart(cartID) {
		if (confirm("确认要删除吗？")) {
			window.location.href = '/shopping/ClearCartServlet?cartID='
					+ cartID;
		}
	}
</script>
<body>
	<div class="container m-5">
		<%
			List<CartBean> cart = (List<CartBean>) request.getAttribute("cart");
			String totalsum = request.getParameter("totalsum");
		%>
		<div class="row clearfix">
			<div class="col-md-12 column">
				<nav class="navbar navbar-default" role="navigation">
				<div class="collapse navbar-collapse"
					id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav navbar-right">
						<li><a onclick="clearcart(${cart_id})"
							id="cartID" style='color: blue'>清空购物车</a></li>
						<li class="dropdown"><a href="#" class="dropdown-toggle"
							data-toggle="dropdown">设置<strong class="caret"></strong></a>
							<ul class="dropdown-menu">
								<li><a href="/shopping/ListProducts">查看我的评价</a></li>
								<li><a href="#"></a></li>
								<li class="divider"></li>
								<li><a href="LoginOutServlet">退出登录</a></li>
							</ul></li>
						 <li><a href="/shopping/jsp/index.jsp">返回主页</a></li>  
					</ul>
				</div>

				</nav>
			</div>
		</div>


		<form>
			<table
				class="table table-hover table-responsive table-striped table-bordered">
				<thead>
					<tr>
						<td></td>
						<td>商品</td>
						<td>商品名称</td>
						<td>商品id</td>
						<td>单价</td>
						<td>数量</td>
						<td>操作</td>
					</tr>
				</thead>
				<tbody>
					<div>
						<%
							String path = request.getContextPath();
							String basePath = request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort()
									+ path;
						%>
						<c:forEach items="${cart }" var="cart">
							<tr>
								<td style="width: 30px; height: 120px"><input
									type="checkbox" name="reading" checked="false"></td>
								<td value="${cart.commodity_id }" id="commID"
									style="width: 120px; height: 120px"><a
									href="product_info.htm"> <img
										src="<%=basePath%>${cart.commodity_pic}" width="100"
										height="100" style="display: inline-block;">
								</a></td>
								<td style="width: 120px; height: 120px">
									<p style='padding: 40px 0px'>${cart.commodity_name }</p>
								</td>
								<td style="width: 120px; height: 120px">
									<p style="padding: 40px 0px" id="commID">${cart.commodity_id}</p>
								</td>
								<td style="width: 120px; height: 120px">
									<p style="padding: 40px 0px; color: #FF0000" id="onemoney">¥${cart.commodity_price}</p>
								</td>
								<td style="width: 120px; height: 120px" class="row"><input
									type="number" id="b" value="${cart.good_nums}"></td>

								<td style="width: 120px; height: 120px" class="row"><button
										value="${cart.cart_id}" id="cartID"
										onclick="deletecart(value)">删除</button></td>

							</tr>

						</c:forEach>

					</div>

				</tbody>
			</table>
		</form>
		<div class="text-right ">
			 <h3>
				总价:<strong>${totalsum}</strong>元
			</h3> 


		</div>
		<div class="text-right">
			<a href="#" class="btn btn-default justify-content-right">去结算</a>

		</div>
</body>
</html>