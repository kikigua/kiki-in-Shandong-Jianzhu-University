<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8" import="java.util.List,bean.*"%>
<%@taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>商品详情</title>
</head>
<!-- 新 Bootstrap4 核心 CSS 文件 -->
<link rel="stylesheet" href="https://cdn.staticfile.org/twitter-bootstrap/4.3.1/css/bootstrap.min.css">
 
<!-- jQuery文件。务必在bootstrap.min.js 之前引入 -->
<script src="https://cdn.staticfile.org/jquery/3.2.1/jquery.min.js"></script>
 
<!-- 用于弹窗、提示、下拉菜单，包含了 popper.min.js -->
<script src="https://cdn.staticfile.org/popper.js/1.15.0/umd/popper.min.js"></script>
 
<!-- 最新的 Bootstrap4 核心 JavaScript 文件 -->
<script src="https://cdn.staticfile.org/twitter-bootstrap/4.3.1/js/bootstrap.min.js"></script>
<body>
	<div class="container pb-5">
		<%
			GoodBean good = (GoodBean) request.getAttribute("goodInfo");
			String path = request.getContextPath();
			String basePath = request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort()
					+ path;
		%>
		<div
			class="d-flex flex-row justify-content-between align-items-center">
			<h3 class="px-2 pt-5">商品详情</h3>
			<form action="/shopping/SearchGood" method="post" class="px-2 pt-5">
				<input class="p-1" type="search" name="searchKey" placeholder="请输入要搜索的商品">
				<button class="px-3 py-2"
					style="background-color: rgba(30, 144, 255, 0.6); color: white;">
					<svg t="1609859727839" class="icon" viewBox="0 0 1024 1024"
						version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="2689"
						data-spm-anchor-id="a313x.7781069.0.i1" width="1.2rem" height="1.2rem">
					<path
						d="M902.4 889.6l-156.8-156.8c156.8-147.2 166.4-393.6 22.4-553.6S371.2 12.8 211.2 160C51.2 307.2 44.8 553.6 192 713.6c131.2 140.8 342.4 166.4 502.4 60.8l160 163.2c12.8 12.8 32 12.8 44.8 0 12.8-12.8 16-35.2 3.2-48z m-755.2-448c0-182.4 147.2-329.6 329.6-329.6 182.4 0 329.6 147.2 329.6 329.6 0 182.4-147.2 329.6-329.6 329.6C294.4 774.4 147.2 624 147.2 441.6z"
						p-id="2690" fill="#ffffff"></path></svg>
				</button>
			</form>
		</div>
		<div class="row justify-content-between align-items-center px-2 pt-5">
			<div class="justify-content-center align-items-center col-md-6">
				<img alt="商品图片" src="<%=basePath%>${goodInfo.commodity_pic}"
					class="img-fluid py-2" style="width: 28rem;">
			</div>
			<div class="col-md-6 pt-4">
				<h5>${goodInfo.commodity_name }</h5>
				<form action="/shopping/AddCart" method="POST" class="justify-content-center align-items-center"
					oninput="x.value=parseFloat(${goodInfo.commodity_price})*parseInt(b.value)">
					<table class="table" style="color: rgba(0, 0, 0, 0.6);">
						<tr class="p-1">
							<td style="width: 8rem">简介</td>
							<td>${goodInfo.commodity_info}</td>
						</tr>
						<tr class="p-1">
							<td style="width: 8rem">价格</td>
							<td style="color: rgba(255, 0, 0, 0.8)">￥${goodInfo.commodity_price}</td>
						</tr>
						<tr class="p-1">
							<td style="width: 8rem">库存</td>
							<td>${goodInfo.commodity_num}</td>
						</tr>
						<tr class="p-1">
							<td style="width: 8rem">销售量</td>
							<td>${goodInfo.commodity_sale}</td>
						</tr>

						<tr class="p-1">
							<td style="width: 8rem">数量</td>
							<td><input type="number" id="b" value="1"
								style="width: 4rem; color: rgba(0, 0, 0, 0.6);" class="mr-2" name="nums">件</td>
						</tr>
						<tr class="p-1">
							<td style="width: 8rem">总价</td>
							<td><output name="x" for="${goodInfo.commodity_price} b"></output></td>
						</tr>
					</table>
					<div class="justify-content-center align-items-center">
						<button name="commid" value="${goodInfo.commodity_id}" type="submit" class="py-2 px-4" style="color:white; background-color:rgba(255, 0, 0, 0.8);">加入购物车</button>
					</div>
				</form>
			</div>
		</div>
	</div>
</body>
<style>
button {
	border: none;
}
</style>
</html>