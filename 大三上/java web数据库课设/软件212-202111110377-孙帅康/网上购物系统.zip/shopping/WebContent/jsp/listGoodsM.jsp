<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8" import="java.util.List,bean.*"%>
<%@taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>商品信息管理</title>
<!-- 新 Bootstrap4 核心 CSS 文件 -->
<link rel="stylesheet" href="https://cdn.staticfile.org/twitter-bootstrap/4.3.1/css/bootstrap.min.css">
 
<!-- jQuery文件。务必在bootstrap.min.js 之前引入 -->
<script src="https://cdn.staticfile.org/jquery/3.2.1/jquery.min.js"></script>
 
<!-- 用于弹窗、提示、下拉菜单，包含了 popper.min.js -->
<script src="https://cdn.staticfile.org/popper.js/1.15.0/umd/popper.min.js"></script>
 
<!-- 最新的 Bootstrap4 核心 JavaScript 文件 -->
<script src="https://cdn.staticfile.org/twitter-bootstrap/4.3.1/js/bootstrap.min.js"></script>
<script type="text/javascript">
	function deleteGood(id) {
		if (confirm("确认要删除吗？")) {
			window.location.href = '/shopping/ListGoodsM?deleteId=' + id;
		}
	}
</script>
</head>
<body>
	<div class="container pt-3 pb-3">
		<%
			List<GoodBean> allGoodM = (List<GoodBean>) request.getAttribute("allGoodM");
			List<GoodKindBean> allKind = (List<GoodKindBean>) request.getAttribute("allKind");
			List<ManagerBean> managerlist = (List<ManagerBean>) request.getAttribute("managerlist");
			GoodBean editgood = (GoodBean) request.getAttribute("editgood");
			String deleteflag = request.getParameter("deleteflag");
			String path = request.getContextPath();
			String basePath = request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort()
					+ path;
		%>
		<div
			class="d-flex flex-row justify-content-between align-items-center">
			<div
				class="d-flex flex-row justify-content-center align-items-center">
				<button class="mb-2" style="background-color:transparent">
					<a href="/shopping/jsp/houtai.jsp"><svg t="1610047072232"
							class="icon" viewBox="0 0 1024 1024" version="1.1"
							xmlns="http://www.w3.org/2000/svg" p-id="7758" width="2rem"
							height="2rem">
						<path
							d="M615.4 284.3c-17-13.6-41.7-10.8-55.4 6.2L402.5 487.4c-11.5 14.4-11.5 34.8 0 49.2L560 733.5c7.8 9.7 19.2 14.8 30.8 14.8 8.6 0 17.3-2.8 24.6-8.6 17-13.6 19.7-38.4 6.2-55.3L483.6 512l137.9-172.3c13.6-17 10.8-41.8-6.1-55.4z"
							p-id="7759" fill="rgba(0,0,0,0.5)"></path>
						<path
							d="M512 0C229.2 0 0 229.2 0 512s229.2 512 512 512 512-229.2 512-512S794.8 0 512 0z m0 945.2C273.1 945.2 78.8 750.9 78.8 512S273.1 78.8 512 78.8 945.2 273.1 945.2 512 750.9 945.2 512 945.2z"
							p-id="7760" fill="rgba(0,0,0,0.5)"></path></svg></a>
				</button>
				<h3 class="p-3">商品信息管理</h3>
			</div>
			<a href="${pageContext.request.contextPath}/jsp/AddGo.jsp">
			<button class="px-3 py-1"
				style="background-color: rgba(30, 144, 255, 0.6); color: white; font-size: 0.9rem">添加</button></a>
				
	<!-- data-toggle="modal"
				data-target="#addGoodModal" -->
			
		</div>
		
		<!-- 列出所有商品信息 -->
		<table class="table text-center table-striped"
			style="vertical-align: middle;">
			<thead>
				<tr class="p-2 justify-content-center align-items-center">
					<th>商品图片</th>
					<th>商品名称</th>
					<th>商品类别</th>
					<th>商品简介</th>
					<th>商品价格</th>
					<th>商品库存</th>
					<th>商品销售量</th>
					<th>操作</th>
				</tr>
			</thead>
			<tbody>
				<c:forEach var="good" items="${allGoodM}">
					<tr class="p-2 justify-content-center align-items-center">
						<td>
							<div
								class="d-flex flex-column justify-content-center align-items-center">
								<img alt="商品图片" src="<%=basePath%>${good.commodity_pic}"
									class="img-fluid py-2" style="width: 5rem;">
								<button class="p-1">上传文件</button>
							</div>
						</td>
						<td>${good.commodity_name}</td>
						<td>${good.family_name}</td>
						<td style="width: 25%">${good.commodity_info}</td>
						<td>￥${good.commodity_price}</td>
						<td>${good.commodity_num}</td>
						<td>${good.commodity_sale}</td>
						<td>
							<div
								class="d-flex flex-row justify-content-center align-items-center">
								<form action="/shopping/ListGoodsM" method="post">
									<button name="editgoodid" value="${good.commodity_id}"
										class="px-2 py-1 mr-1"
										style="background-color: rgba(255, 127, 80, 0.6); color: white;">编辑</button>
								</form>
								<button value="${good.commodity_id}" onclick="editgood(value)"
									data-toggle="modal" data-target="#editGoodModal"
									class="px-2 py-1 mr-1"
									style="background-color: rgba(30, 144, 255, 0.6); color: white;">确认编辑</button>
								<button value="${good.commodity_id}" class="px-2 py-1"
									style="background-color: rgba(255, 0, 0, 0.6); color: white;"
									onclick="deleteGood(value)">删除</button>
							</div>
						</td>
					</tr>
				</c:forEach>
			</tbody>
		</table>

		<!-- 模态框添加商品 -->
		<div class="modal fade" id="addGoodModal" tabindex="-1" role="dialog"
			aria-labelledby="addGoodModalLabel" aria-hidden="true">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<h4 class="modal-title" id="addGoodModalLabel">添加商品</h4>
						<button type="button" class="close" data-dismiss="modal"
							aria-hidden="true">&times;</button>

					</div>
					<form action="/shopping/AddGood" method="post">
						<div class="modal-body">
							<div class="p-2 d-flex flex-row"
								style="color: rgba(0, 0, 0, 0.7);">
								<label class="pr-2">商品名称</label><input class="form-control"
									type="text" name="addgoodname">
							</div>
							<div class="p-2 d-flex flex-row"
								style="color: rgba(0, 0, 0, 0.7);">
								<label class="pr-2">商品价格</label><input class="form-control"
									type="text" name="addgoodprice"><span class="pl-2">元</span>
							</div>
							<div class="p-2 d-flex flex-row"
								style="color: rgba(0, 0, 0, 0.7);">
								<label class="pr-2">商品库存</label><input class="form-control"
									type="number" name="addgoodnum"><span class="pl-2">件</span>
							</div>
							<div class="p-2 d-flex flex-row"
								style="color: rgba(0, 0, 0, 0.7);">
								<label class="pr-2">商品简介</label>
								<textarea class="form-control" name="addgoodinfo"></textarea>
							</div>
							<div class="p-2 d-flex flex-row"
								style="color: rgba(0, 0, 0, 0.7);">
								<label class="pr-2">商品类别</label> <input class="form-control"
									list="goodkinds" name="goodkinds">
								<datalist id="goodkinds" multiple> <c:forEach
									var="kind" items="${allKind}">
									<option value="${kind.family_name}">${kind.family_name }</option>
								</c:forEach> </datalist>
								<button type="button" class="ml-2 btn btn-primary"
									data-toggle="modal" data-target="#addGoodKindModal">添加类别</button>
							</div>
							<div class="p-2 d-flex flex-row"
								style="color: rgba(0, 0, 0, 0.7);">
								<label class="pr-2">管理员ID</label> <input class="form-control"
									list="manager" name="managerid">
								<datalist id="manager" multiple> <c:forEach
									var="manager" items="${managerlist}">
									<option value="${manager.manager_id}">${manager.username}</option>
								</c:forEach> </datalist>
							</div>
						</div>
						<div class="modal-footer">
							<button type="button" class="btn btn-default"
								data-dismiss="modal">关闭</button>
							<button type="submit" class="btn btn-primary">添加</button>
						</div>
					</form>
				</div>
				<!-- /.modal-content -->
			</div>
			<!-- /.modal -->
		</div>

		<!-- 模态框编辑商品信息 -->
		<div class="modal fade" id="editGoodModal" tabindex="-1" role="dialog"
			aria-labelledby="editGoodModalLabel" aria-hidden="true">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<h4 class="modal-title" id="editGoodModalLabel">编辑商品信息</h4>
						<button type="button" class="close" data-dismiss="modal"
							aria-hidden="true">&times;</button>
					</div>
					<form action="/shopping/EditGood" method="post">
						<div class="modal-body">
							<div class="p-2 d-flex flex-row"
								style="color: rgba(0, 0, 0, 0.7);">
								<label class="pr-2">商品名称</label><input class="form-control"
									type="text" name="editgoodname"
									value="${editgood.commodity_name}">
							</div>
							<div class="p-2 d-flex flex-row"
								style="color: rgba(0, 0, 0, 0.7);">
								<label class="pr-2">商品价格</label><input class="form-control"
									type="text" name="editgoodprice"
									value="${editgood.commodity_price}"><span class="pl-2">元</span>
							</div>
							<div class="p-2 d-flex flex-row"
								style="color: rgba(0, 0, 0, 0.7);">
								<label class="pr-2">商品库存</label><input class="form-control"
									type="number" name="editgoodnum"
									value="${editgood.commodity_num}"><span class="pl-2">件</span>
							</div>
							<div class="p-2 d-flex flex-row"
								style="color: rgba(0, 0, 0, 0.7);">
								<label class="pr-2">商品简介</label> <input class="form-control"
									name="editgoodinfo" value="${editgood.commodity_info}">
							</div>
							<div class="p-2 d-flex flex-row"
								style="color: rgba(0, 0, 0, 0.7);">
								<label class="pr-2">商品类别</label> <input class="form-control"
									list="goodkinds" name="editkinds"
									value="${editgood.family_name}">
								<datalist id="goodkinds" multiple> <c:forEach
									var="kind" items="${allKind}">
									<option value="${kind.family_name}">${kind.family_name }</option>
								</c:forEach> </datalist>
							</div>
						</div>
						<div class="modal-footer">
							<button type="button" class="btn btn-default"
								data-dismiss="modal">关闭</button>
							<button type="submit" class="btn btn-primary">保存</button>
						</div>
					</form>
				</div>
				<!-- /.modal-content -->
			</div>
			<!-- /.modal -->
		</div>

		<!-- 模态框添加商品类别 -->
		<div class="modal fade" id="addGoodKindModal" tabindex="-1"
			role="dialog" aria-labelledby="addGoodKindModalLabel"
			aria-hidden="true">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<h4 class="modal-title" id="addGoodKindModalLabel">添加商品类别</h4>
						<button type="button" class="close" data-dismiss="modal"
							aria-hidden="true">&times;</button>
					</div>
					<form action="/shopping/AddGoodKind" method="post">
						<div class="modal-body">
							<div class="p-2 d-flex flex-row"
								style="color: rgba(0, 0, 0, 0.7);">
								<label class="pr-2">商品类别名称</label><input class="form-control"
									type="text" name="addgoodkindname">
							</div>
						</div>
						<div class="modal-footer">
							<button type="button" class="btn btn-default"
								data-dismiss="modal">关闭</button>
							<button type="submit" class="btn btn-primary">添加</button>
						</div>
					</form>
				</div>
				<!-- /.modal-content -->
			</div>
			<!-- /.modal -->
		</div>
	</div>
</body>
<style>
button {
	border: none;
	outline: none;
	font-size: 0.8rem;
}
</style>
</html>