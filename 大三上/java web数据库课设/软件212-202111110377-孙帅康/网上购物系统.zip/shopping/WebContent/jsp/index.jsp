<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8" import="java.util.List,bean.*"%>
<%@taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>首页</title>

<!-- 新 Bootstrap4 核心 CSS 文件 -->
<link rel="stylesheet" href="https://cdn.staticfile.org/twitter-bootstrap/4.3.1/css/bootstrap.min.css">
 
<!-- jQuery文件。务必在bootstrap.min.js 之前引入 -->
<script src="https://cdn.staticfile.org/jquery/3.2.1/jquery.min.js"></script>
 
<!-- 用于弹窗、提示、下拉菜单，包含了 popper.min.js -->
<script src="https://cdn.staticfile.org/popper.js/1.15.0/umd/popper.min.js"></script>
 
<!-- 最新的 Bootstrap4 核心 JavaScript 文件 -->
<script src="https://cdn.staticfile.org/twitter-bootstrap/4.3.1/js/bootstrap.min.js"></script>

</head>
<body>
	<div>
		<%
			UserBean loginuser = (UserBean) request.getAttribute("loginuser");
			List<GoodBean> hotGood = (List<GoodBean>) request.getAttribute("hotGood");
		%>

		<div>
			<nav
				class="d-flex flex-row justify-content-between align-items-center"
				style="background-color: rgba(0, 0, 0, 0.8)">
				<span class="py-3 px-5"
					style="color: rgba(255, 250, 240, 0.8); font-size: 1.5rem;">网上购物系统</span>
				<ul
					class="d-flex flex-row justify-content-between align-items-center">
					<li class="navli"><a href="#">首页</a></li>
					<li class="navli"><a href="/shopping/CartServlet">我的购物车</a></li>
					<li class="dropdown navli"><a class="dropdown-toggle"
						data-toggle="dropdown"style="color: #d6d2ca;"> 个人中心 <b class="caret"></b>
					</a>
						<ul class="dropdown-menu">
							<li class="navli"><a href="/shopping/vipOrder"
								style="color: #212529;">我的订单</a></li>
							<li class="navli"><a href="/shopping/listProductPass" style="color: #212529;">我的评论</a></li>
							<li class="navli"><a style="color: #212529;"
								data-toggle="modal" data-target="#myModal">个人信息</a></li>
						</ul></li>
				</ul>
			</nav>
		</div>
		<%--个人信息弹框 --%>
		<div class="modal fade" id="myModal" tabindex="-1" role="dialog"
			aria-labelledby="myModalLabel" aria-hidden="true">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<h4 class="modal-title" id="myModalLabel">个人信息</h4>
					</div>
					<form action="" method="post">
						<div class="modal-body">
							<div class="p-2 d-flex flex-row"
								style="color: rgba(0, 0, 0, 0.7);">
								<label class="pr-2">用户名</label><input class="form-control"
									type="text" name="loginusername" value="${loginuser.username}" disabled>
							</div>
							<div class="p-2 d-flex flex-row"
								style="color: rgba(0, 0, 0, 0.7);">
								<label class="pr-2">真实姓名</label><input class="form-control"
									type="text" name="loginuserrealname" value="${loginuser.realname}">
							</div>
							<div class="p-2 d-flex flex-row"
								style="color: rgba(0, 0, 0, 0.7);">
								<label class="pr-2">地址</label><input class="form-control"
									type="text" name="loginuseraddress" value="${loginuser.address}">
							</div>
							<div class="p-2 d-flex flex-row"
								style="color: rgba(0, 0, 0, 0.7);">
								<label class="pr-2">电话号码</label>
								<input class="form-control" name="loginusertel" value="${loginuser.tel}">
							</div>
						</div>
						<div class="modal-footer">
							<button type="button" class="btn btn-default"
								data-dismiss="modal">关闭</button>
							<button type="submit" class="btn btn-primary" data-dismiss="modal">提交</button>
						</div>
					</form>
				</div>
				<!-- /.modal-content -->
			</div>
			<!-- /.modal -->
		</div>

	</div>
	<%
		String path = request.getContextPath();
		String basePath = request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort()
				+ path;
	%>

	<!-- Example row of columns -->
	<div class="container pt-5">
		<div id="carouselExampleSlides" class="carousel slide"
			data-ride="carousel">
			<ol class="carousel-indicators">
				<li data-target="#carouselExampleSlides" data-slide-to="0"
					class="active"></li>
				<li data-target="#carouselExampleSlides" data-slide-to="1"></li>
				<li data-target="#carouselExampleSlides" data-slide-to="2"></li>
			</ol>
			<div class="carousel-inner">
				<div class="carousel-item active">
					<img src="<%=basePath%>/img/geli.jpg" class="d-block w-100 img-fluid"
						style="width: 100%; height: 40rem;" alt="...">
				</div>
				<div class="carousel-item">
					<img src="<%=basePath%>/img/hm60.jpg" class="d-block w-100 img-fluid"
						style="width: 100%; height: 40rem;" alt="...">
				</div>
				<div class="carousel-item">
					<img src="<%=basePath%>/img/2.jpg" class="d-block w-100 img-fluid"
						style="width: 100%; height: 40rem;" alt="...">
				</div>
			</div>
			<a class="carousel-control-prev" href="#carouselExampleSlides"
				role="button" data-slide="prev"> <span
				class="carousel-control-prev-icon" aria-hidden="true"></span> <span
				class="sr-only">Previous</span>
			</a> <a class="carousel-control-next" href="#carouselExampleSlides"
				role="button" data-slide="next"> <span
				class="carousel-control-next-icon" aria-hidden="true"></span> <span
				class="sr-only">Next</span>
			</a>
		</div>
	</div>

	<div class="container pb-5">
		<div class="d-flex flex-row justify-content-between">
			<%
				List<GoodKindBean> allKind = (List<GoodKindBean>) request.getAttribute("allKind");
				String kindName = (String) request.getAttribute("kindName");
				String kindGoodId = (String) request.getAttribute("kindGoodId");
			%>
			<div class="d-flex flex-row">
				<h2 class="px-2 pt-5">商品信息</h2>
				<div class="px-2 pt-5 mt-1">
					<select class="d-flex flex-column p-1"
						onchange="window.location.href='/shopping/KindGood?goodkind='+this.value">
						<option selected value="${kindGoodId}">${kindName}</option>
						<c:forEach var="kind" items="${allKind}">
							<option value="${kind.family_id}">${kind.family_name }</option>
						</c:forEach>
					</select>
				</div>
			</div>
			<form action="/shopping/SearchGood" method="post" class="px-2 pt-5">
				<input class="p-1" type="search" name="searchKey"
					placeholder="请输入要搜索的商品">
				<button class="px-3 py-2"
					style="background-color: rgba(30, 144, 255, 0.6); color: white;">
					<svg t="1609859727839" class="icon" viewBox="0 0 1024 1024"
						version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="2689"
						data-spm-anchor-id="a313x.7781069.0.i1" width="1.2rem"
						height="1.2rem"> <path
							d="M902.4 889.6l-156.8-156.8c156.8-147.2 166.4-393.6 22.4-553.6S371.2 12.8 211.2 160C51.2 307.2 44.8 553.6 192 713.6c131.2 140.8 342.4 166.4 502.4 60.8l160 163.2c12.8 12.8 32 12.8 44.8 0 12.8-12.8 16-35.2 3.2-48z m-755.2-448c0-182.4 147.2-329.6 329.6-329.6 182.4 0 329.6 147.2 329.6 329.6 0 182.4-147.2 329.6-329.6 329.6C294.4 774.4 147.2 624 147.2 441.6z"
							p-id="2690" fill="#ffffff"></path></svg>
				</button>
			</form>
		</div>
		<%
			List<GoodBean> allGood = (List<GoodBean>) request.getAttribute("allGood");
		%>
		<div class="row justify-content-center align-items-center">
			<c:forEach var="good" items="${allGood }">
				<div
					class="d-flex flex-column col-sm-6 col-md-4 col-xl-3 p-3 justify-content-center align-items-center">
					<form action="/shopping/InfoGood" method="post">
						<button name="commodity_id" value="${good.commodity_id }"
							class="m-1 p-3 bg-white justify-content-center align-items-center a"
							style="height: 20rem">
							<img alt="商品图片" src="<%=basePath%>${good.commodity_pic}"
								class="img-fluid py-2" style="width: 15rem;">
							<div class="d-flex flex-column">
								<span class="p-1" style="font-size: 1rem; color: black;">${good.commodity_name}</span>
								<span class="p-1" style="font-size: 0.8rem;">${good.commodity_info}</span>
								<span class="px-1 pt-2" style="font-size: 0.8rem; color: red;">￥${good.commodity_price}</span>
							</div>
						</button>
					</form>
				</div>
			</c:forEach>
		</div>
	</div>

	<hr>
	<footer>
		<p class="text-center">&copy; Copyright© 2023-2024 Java web 7组版权所有</p>
	</footer>
	<!-- /container -->

</body>
<style>
.navli {
	list-style: none;
	padding: 1.5rem 1rem;
}

ul {
	margin: 0;
}

a {
	text-decoration: none;
	color: rgba(255, 250, 240, 0.8);
}

a:hover {
	text-decoration: none;
	color: #ffffff;
}

button {
	border: none;
}

.a {
	text-decoration: none;
	color: rgba(0, 0, 0, 0.6);
}

.a:hover {
	color: rgba(0, 0, 0, 0.8);
	transform: scale(1.07);
}

body {
	background-color: rgba(135, 206, 250, 0.1);
}
</style>
</html>