<%@ page language="java" contentType="text/html; charset=utf-8"
	pageEncoding="utf-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>
<%@ page import="java.util.List" %>
<%@ page import="bean.*" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>首页</title>
</head>

<!-- 新 Bootstrap4 核心 CSS 文件 -->
<link rel="stylesheet" href="https://cdn.staticfile.org/twitter-bootstrap/4.3.1/css/bootstrap.min.css">
 
<!-- jQuery文件。务必在bootstrap.min.js 之前引入 -->
<script src="https://cdn.staticfile.org/jquery/3.2.1/jquery.min.js"></script>
 
<!-- 用于弹窗、提示、下拉菜单，包含了 popper.min.js -->
<script src="https://cdn.staticfile.org/popper.js/1.15.0/umd/popper.min.js"></script>
 
<!-- 最新的 Bootstrap4 核心 JavaScript 文件 -->
<script src="https://cdn.staticfile.org/twitter-bootstrap/4.3.1/js/bootstrap.min.js"></script>


<script type="text/javascript">
	function us() {
		alert("客服qq:12312341234")
	}
</script>
<body>
<div>
	<div class="container">
		<div class="row clearfix">
			<div class="col-md-12 column">
				<ul class="breadcrumb">
					<li><a href="index.jsp">返回首页</a></li>/
					<li><a onclick="us()"style="color: #007bff;">联系我们</a></li>/
					<li class="active">登录</li>
				</ul>
				<div class="jumbotron">
					<h1>欢迎来到网上购物商城</h1>
					<h2>Welcome</h2>
					<p>请先登录系统!</p>
					<p>
						<a class="btn btn-primary btn-large" class="modal-title"
							data-toggle="modal" data-target="#myModal">>>>注册>>></a>
					</p>
				</div>
				<!-- 模态框用户注冊 -->
				<div class="modal fade" id="myModal" tabindex="-1" role="dialog"
					aria-labelledby="myModalLabel" aria-hidden="true">
					<div class="modal-dialog">
						<div class="modal-content">
							<div class="modal-header">
								<h4 class="modal-title" id="myModalLabel">用户注册</h4>
								<button type="button" class="close" data-dismiss="modal"
									aria-hidden="true">&times;</button>
							</div>
							<form action="/shopping/Register" method="post">
								<div class="modal-body">
									<div class="p-2 d-flex flex-row"
										style="color: rgba(0, 0, 0, 0.7);">
										<label class="pr-2">用户名</label><input class="form-control"
											type="text" name="registerusername" required>
									</div>
									<div class="p-2 d-flex flex-row"
										style="color: rgba(0, 0, 0, 0.7);">
										<label class="pr-2">密码</label><input class="form-control"
											type="text" name="registerpassword" required>
									</div>
									<div class="p-2 d-flex flex-row"
										style="color: rgba(0, 0, 0, 0.7);">
										<label class="pr-2">真实姓名</label><input class="form-control"
											type="text" name="registerrealname">
									</div>
									<div class="p-2 d-flex flex-row"
										style="color: rgba(0, 0, 0, 0.7);">
										<label class="pr-2">地址</label> <input class="form-control"
											name="registeraddress">
									</div>
									<div class="p-2 d-flex flex-row"
										style="color: rgba(0, 0, 0, 0.7);">
										<label class="pr-2">电话</label> <input class="form-control"
											type="text" name="registertel">
									</div>
								</div>
								<div class="modal-footer">
									<button type="button" class="btn btn-default"
										data-dismiss="modal">关闭</button>
									<button type="submit" class="btn btn-primary">注册</button>
								</div>
							</form>
						</div>
						<!-- /.modal-content -->
					</div>
					<!-- /.modal -->
				</div>
			</div>
		</div>
	</div>

	<div class="row clearfix">
		<div class="col-md-2 column"></div>
		<div class="col-md-6 column">
			<form class="form-horizontal" role="form"
				action="/shopping/LoginServlet">
				<div class="form-group">
					<label for="inputEmail3" class="col-sm-2 control-label">用户名</label>
					<div class="col-sm-10">
						<input type="text" class="form-control" id="inputEmail3"
							name="username" />
					</div>
				</div>
				<div class="form-group">
					<label for="inputPassword3" class="col-sm-2 control-label">密码</label>
					<div class="col-sm-10">
						<input type="password" class="form-control" id="inputPassword3"
							name="password" />
					</div>
				</div>

				<div class="form-group">
					<div class="col-sm-offset-2 col-sm-10">
						<button class="btn btn-primary">登录</button>
					</div>
				</div>
			</form>
		</div>


	</div>

	</div>

</body>
</html>