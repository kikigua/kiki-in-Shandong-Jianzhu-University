<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8" import="java.util.List,bean.*"%>
<%@taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>订单信息</title>

<link
	href="https://cdn.bootcdn.net/ajax/libs/twitter-bootstrap/5.0.0-alpha1/css/bootstrap.min.css"
	rel="stylesheet">
<script
	src="https://cdn.bootcdn.net/ajax/libs/twitter-bootstrap/5.0.0-alpha1/js/bootstrap.bundle.min.js"></script>
<script
	src="https://cdn.bootcdn.net/ajax/libs/jquery/3.5.1/jquery.slim.min.js"></script>

<%-- 	<link rel="stylesheet" href="./css/reset.css" />
    <link rel="stylesheet" href="./css/content.css" />
    <link rel="stylesheet" href="./css/public.css" />
    --%>
     <script type="text/javascript">
	function deleteOrder(id) {
		if (confirm("确认要删除吗？")){
			window.location.href = '/shopping/ListOrders?deleteId=' + id;
		}
	}
</script>
</head>

<body>
    
	<div class="container pt-3 pb-3">
		<%	
		    List<orderBean> allOrder = (List<orderBean>) request.getAttribute("allOrder");
			String deleteflag = request.getParameter("deleteflag");
			String path = request.getContextPath();
			String basePath = request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort()
					+ path;
		%>
			<div
			class="d-flex flex-row justify-content-between align-items-center">
				    <h2>订单信息</h2>
					<button class="px-3 py-1" data-toggle="modal"
				data-target="#addOrderModal" style="background-color: #F5FFFA; color: black; border: 2px solid Gray"; font-size:0.9rem>添加订单</button>
			</div>
			<form action="/shopping/SearchOrderAll" method="post" class="px-1 pt-1">
			<th style="width: 100%">搜索想要查询的订单：</th> <input type="search"
				name="searchKey" placeholder="请输入查询条件">		 
			<button style="width: 1.9rem; height: 1.7rem;">
				<svg t="1609761073820" class="icon" viewBox="0 0 1024 1024"
					version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="1219"
					width="1.1rem" height="1.1rem"> <path
					d="M902.4 889.6l-156.8-156.8c156.8-147.2 166.4-393.6 22.4-553.6S371.2 12.8 211.2 160C51.2 307.2 44.8 553.6 192 713.6c131.2 140.8 342.4 166.4 502.4 60.8l160 163.2c12.8 12.8 32 12.8 44.8 0 12.8-12.8 16-35.2 3.2-48z m-755.2-448c0-182.4 147.2-329.6 329.6-329.6 182.4 0 329.6 147.2 329.6 329.6 0 182.4-147.2 329.6-329.6 329.6C294.4 774.4 147.2 624 147.2 441.6z"
					p-id="1220"></path></svg>
			</button>
			<br><br>
		</form>
		<%-- 
			<input type="text" name="order_id" value="" /> <button type="submit"
				name="get">查询</button>
				--%>
		<div class="d-flex flex-row justify-content-between">
			<div class="row justify-content-center align-items-center">
			<table class="table table-hover table-responsive table-striped table-bordered">
			<tr>
                         
                        <th style="width:10%">订单ID</th>
                        <th style="width:10%">订单日期</th>
                        <th style="width:10%">订单状态</th>
                         <th style="width:10%">会员ID</th>
                           <th style="width:10%">会员名称</th>   
                         <th style="width: 10%">消费总额</th> 
                         <th style="width:10%">订单详情</th>
                         <th style="width:10%">对订单的操作</th>                    
                    </tr>
			  
		          <c:forEach var="order" items="${allOrder}">
				<tr>
						
								<td>${order.order_id}</td>
								<td>${order.orderdate} </td>
								<td>${order.orderstatus} </td>
								<td>${order.vip_id}</td>
								<td>${order.username}</td>
									<td>${order.countmoney}<span class="pl-2">元</span></td>
								<form action="/shopping/InfoOrder" method="post">
				   <th>	    <button  style="background-color: #F5FFFA; color: black;border-radius: 12px; border: 2px solid Gray" name="order_id" value="${order.order_id}">		
					           详情</button></form></th>
								<td>
						             <div  style="width:100%;box-sizing:border-box;" class="anan1">
								         <button class="px-2 py-1 mr-1" data-toggle="modal" data-target="#editOrderModal"
								class="px-2 py-1 mr-1"
								         style="background-color: #F5FFFA; color: black;border-radius: 12px; border: 2px solid Gray">编辑</button>
							             <button value="${order.order_id}" class="px-2 py-1" style="background-color:#FF3333 ; color: white;border-radius: 12px; border:1px solid white"
								      onclick="deleteOrder(value)"><a href="/shopping/ListOrders">删除</a></button></td>
							</div>
							</tr>
						</div>
					</div>
					</button>
					</form>
				</c:forEach>
				  </table>	
				  <div class="tou2">
		<button style="background-color:#F5FFFA ; color: black;border-radius: 12px; border: 2px solid Gray" ><a class="btn btn-default" href="/shopping/jsp/houtai.jsp">返回</a></button>
			</div>
				  <!-- 模态框添订单 -->
		<div class="modal fade" id="addOrderModal" tabindex="-1" role="dialog"
			aria-labelledby="addOrderModalLabel" aria-hidden="true">
			<div class="modal-dialog" >
				<div class="modal-content">
					<div class="modal-header" style="background-color: #F5FFFA">
						<h4 class="modal-title" id="addOrderModalLabel">添加订单</h4>
						<button type="button" class="close" data-dismiss="modal"
							aria-hidden="true">&times;</button>

					</div>
						<div class="modal-body" style="background-color: #F5FFFA">
							<div class="p-2 d-flex flex-row"
								style="color: rgba(0, 0, 0, 0.7);">
								<label class="pr-2">订单ID</label><input class="form-control"
									type="text" name="addorder_id">
							</div>
							<div class="p-2 d-flex flex-row"
								style="color: rgba(0, 0, 0, 0.7);" >
								<label class="pr-2">订单状态</label><input class="form-control"
									type="text" name="addorderstatus">
							</div>
							<div class="p-2 d-flex flex-row"
								style="color: rgba(0, 0, 0, 0.7);" >
								<label class="pr-2">会员ID</label><input class="form-control"
									type="text" name="addvip_id">
							</div>
							<div class="p-2 d-flex flex-row"
								style="color: rgba(0, 0, 0, 0.7);" >
								<label class="pr-2">会员名称</label><input class="form-control"
									type="text" name="addusername">
							</div>	
														<div class="p-2 d-flex flex-row"
								style="color: rgba(0, 0, 0, 0.7);" >
								<label class="pr-2">消费总额</label><input class="form-control"
									type="text" name="addcountmoney"><span class="pl-2">元</span>
							</div>						
						</div>
						<div class="modal-footer" style="background-color: #F5FFFA">
							<button type="button" style="background-color: #F5FFFA; color: black;border-radius: 12px; border: 2px solid Gray" class="btn btn-default"
								data-dismiss="modal">关闭</button>
							<button type="submit" style="background-color: #F5FFFA; color: black;border-radius: 12px; border: 2px solid Gray" class="btn btn-default"
							data-dismiss="modal">添加</button>
						</div>
					</form>
				</div>
				<!-- /.modal-content -->
			</div>
			<!-- /.modal -->
		</div>
		<!-- 模态框编辑订单 -->
		<div class="modal fade" id="editOrderModal" tabindex="-1" role="dialog"
			aria-labelledby="editOrderModalLabel" aria-hidden="true">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header" style="background-color: #F5FFFA">
						<h4 class="modal-title" id="editOrderModalLabel">编辑订单信息</h4>
						<button type="button" class="close" data-dismiss="modal"
							aria-hidden="true">&times;</button>
					</div>
					<form action="/shopping/AddOrder" method="post">
					<div class="modal-body" style="background-color: #F5FFFA">
							<div class="p-2 d-flex flex-row"
								style="color: rgba(0, 0, 0, 0.7);">
								<label class="pr-2">订单日期</label><input class="form-control"
									type="text" name="editorderdate">
							</div>
							<div class="p-2 d-flex flex-row"
								style="color: rgba(0, 0, 0, 0.7);">
								<label class="pr-2">订单状态</label><input class="form-control"
									type="text" name="editorderstatus">
							</div>
						<div class="p-2 d-flex flex-row"
								style="color: rgba(0, 0, 0, 0.7);" >
								<label class="pr-2">会员ID</label><input class="form-control"
									type="text" name="addvip_id">
							</div>
							<div class="p-2 d-flex flex-row"
								style="color: rgba(0, 0, 0, 0.7);" >
								<label class="pr-2">会员名称</label><input class="form-control"
									type="text" name="addusername">
							</div>	
														<div class="p-2 d-flex flex-row"
								style="color: rgba(0, 0, 0, 0.7);" >
								<label class="pr-2">消费总额</label><input class="form-control"
									type="text" name="addcountmoney"><span class="pl-2">元</span>
							</div>	
						</div>
					<div class="modal-footer" style="background-color: #F5FFFA">
						<button type="button" style="background-color: #F5FFFA; color: black;border-radius: 12px; border: 2px solid Gray" class="btn btn-default" data-dismiss="modal">关闭
						</button>
						<button type="submit"  style="background-color: #F5FFFA; color: black;border-radius: 12px; border: 2px solid Gray" class="btn btn-default" data-dismiss="modal">更新</button>
					</div>
				</div>
				<!-- /.modal-content -->
			</div>
			<!-- /.modal -->
		</div>
			</div>
		</div>
</body>
<style>
a {
	text-decoration: none;
	color: rgba(0, 0, 0, 0.6);
}

a:hover {
	color: rgba(0, 0, 0, 0.8);
}
body {
	background-image: linear-gradient(to right,#F0FFF0 ,#F0FFF0 );
	width: 100vw;
	height: 100vh;
	padding: 0;
	margin: 0
}
.tou2{
     padding-right: 10px;
	padding-bottom: 10px;
	text-align: center;
}
</style>
</html>