<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8" import="java.util.List,bean.*"%>
<%@taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>订单详情</title>
</head>
<link
	href="https://cdn.bootcdn.net/ajax/libs/twitter-bootstrap/5.0.0-alpha1/css/bootstrap.min.css"
	rel="stylesheet">
<script
	src="https://cdn.bootcdn.net/ajax/libs/twitter-bootstrap/5.0.0-alpha1/js/bootstrap.bundle.min.js"></script>
<script
	src="https://cdn.bootcdn.net/ajax/libs/jquery/3.5.1/jquery.slim.min.js"></script>

<body>
<div class="container pb-5">
		<%
			orderBean order = (orderBean) request.getAttribute("orderInfo");
			String path = request.getContextPath();
			String basePath = request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort()
					+ path;
		%>
		<div
			class="  ">
			<h3 class="px-2 pt-5">订单信息</h3>
			<form action="/shopping/SearchOrder" method="post" class="px-2 pt-5">
			</form>
		</div>
		<div class="row justify-content-between align-items-center px-2 pt-5">
			<div class="justify-content-center align-items-center col-md-6">
			</div>
		<div class="info1">
			<div class="col-md-3 pt-1">
				<form action="" method="" 
					>
					<table class="table">
						<tr class="p-1">
							<td style="width: 8rem">订单ID</td>
							<td>${orderInfo.order_id}</td>
						</tr>
						<tr class="p-1">
							<td style="width: 8rem">订单日期</td>
							<td>${orderInfo.orderdate}</td>
						</tr>
						<tr class="p-1">
							<td style="width: 8rem">订单状态</td>
							<td>${orderInfo.orderstatus}</td>
						</tr>
						<tr class="p-1">
							<td style="width: 8rem">会员ID</td>
							<td>${orderInfo.vip_id}</td>
						</tr>
						<tr class="p-1">
							<td style="width: 8rem">会员名称</td>
							<td>${orderInfo.username}</td>
						</tr>
						<tr class="p-1">
							<td style="width: 8rem">消费总额</td>
							<td>${orderInfo.countmoney}</td>
						</tr>
												
					</table>
					<div class="justify-content-center align-items-center">
						<button  background-color:rgba(255, 0, 0, 0.8);"><a class="btn btn-default" href="/shopping/ListOrders">返回</a></button>
					</div>
				</form>
			</div>
		</div>
		</div>
	</div>
</body>
<style>
body{
background-image: linear-gradient(to right,#F0FFF0 ,#F0FFF0 );
}
button {
	border: none;
}
.info1{
margin-left:3px;
}
.info1 tr{
border:#574d4d96 40px;}
.p-1{
border:#574d4d96 40px;
}
</style>
</html>