<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8" import="java.util.List,bean.*"%>
<%@taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>用户管理</title>
  
<!-- 新 Bootstrap4 核心 CSS 文件 -->
<link rel="stylesheet" href="https://cdn.staticfile.org/twitter-bootstrap/4.3.1/css/bootstrap.min.css">
 
<!-- jQuery文件。务必在bootstrap.min.js 之前引入 -->
<script src="https://cdn.staticfile.org/jquery/3.2.1/jquery.min.js"></script>
 
<!-- 用于弹窗、提示、下拉菜单，包含了 popper.min.js -->
<script src="https://cdn.staticfile.org/popper.js/1.15.0/umd/popper.min.js"></script>
 
<!-- 最新的 Bootstrap4 核心 JavaScript 文件 -->
<script src="https://cdn.staticfile.org/twitter-bootstrap/4.3.1/js/bootstrap.min.js"></script>
<%-- 	<link rel="stylesheet" href="./css/reset.css" />
    <link rel="stylesheet" href="./css/content.css" />
    <link rel="stylesheet" href="./css/public.css" />
    --%>
 <script type="text/javascript">
	function deleteUser(id,flag) {
		//alert('学生信息已保存');
		console.log(flag);
		if (confirm("确认要删除吗？")){
			window.location.href = '/shopping/ListUsers?deleteId=' + id;
		}
		if(flag == "true"){
			alert("删除成功");
		}else if(flag == "false"){
			alert("删除失败");
		}
	}
</script>
</head>

<body>
    
	<div class="container">
	<%
		List<UserBean> ListUser = (List<UserBean>) request.getAttribute("listUsers");
		String deleteflag = request.getParameter("deleteflag");
	//	List<Shopping_cartBean> shopping_cartlist = (List<Shopping_cartBean>) request.getAttribute("shopping_cartlist");
		String path = request.getContextPath();
		String basePath = request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort()
				+ path;    
			%>
	<div class="tou1">
	     <div style=""> <h2>用户信息</h2>
	    <th> <button class="tuichu"  style="background-color:rgba(13,110,253,.25); color: white;"
			)"><a  href="jsp/houtai.jsp" >返回首页</a></button></th>
	     
	     </div> 
	    
	 
		<th style="width: 100%"></th> 
			<form action="/shopping/SearchUser" method="post" class="px-2 pt-5">
				<input type="search" name="searchKey" placeholder="请输入要搜索的用户">
				<button style="width: 1.9rem; height: 1.9rem;">
					<svg t="1609761073820" class="icon" viewBox="0 0 1024 1024"
						version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="1219"
						width="1.1rem" height="1.1rem">
					<path
						d="M902.4 889.6l-156.8-156.8c156.8-147.2 166.4-393.6 22.4-553.6S371.2 12.8 211.2 160C51.2 307.2 44.8 553.6 192 713.6c131.2 140.8 342.4 166.4 502.4 60.8l160 163.2c12.8 12.8 32 12.8 44.8 0 12.8-12.8 16-35.2 3.2-48z m-755.2-448c0-182.4 147.2-329.6 329.6-329.6 182.4 0 329.6 147.2 329.6 329.6 0 182.4-147.2 329.6-329.6 329.6C294.4 774.4 147.2 624 147.2 441.6z"
						p-id="1220"></path></svg>
				</button>
			</form>	
			<a href="${pageContext.request.contextPath}/jsp/AddUs.jsp"><button class="user1" 
				style="background-color: rgba(30, 144, 255, 0.6); color: white; font-size: 0.9rem">添加
				<!-- data-toggle="modal"
				data-target="#addGoodModal" -->
		</button></a>
			 
			<%-- 
			<input type="text" name="userid" value="" /> <button type="submit"
				name="get">查询</button>
				--%>
			</div>
		<div class="d-flex flex-row justify-content-between">
		
			
			<div class="row justify-content-center align-items-center">
			<table class="table table-hover table-responsive table-striped table-bordered">
			<table class="table table-hover table-responsive table-striped table-bordered">
			<tr>
                         <th style="width:7%"> 详细信息</th>
                        <th style="width:7%">用户ID</th>
                       
                        <th style="width:7%">用户名字</th>
                         <th style="width:10%">用户真实姓名</th>  
                         <th style="width: 7%">用户地址</th> 
                         <th style="width:10%">用户电话</th>  
                        
                         <th style="width:7%">用户购物车id</th>  
                          <th style="width: 10%">用户密码</th> 
                         <th style="width:7%">用户额度</th>  
                         <th style="width:7%">重置密码</th>
                          
                           <th>操作</th>                  
                    </tr>
			  
				<c:forEach var="user" items="${allUser}">
				
					
					<div class="">

						<div class="">
					
						<!-- 	<img alt="" src="<%=basePath%>${user.username}"
								class="img-fluid py-2" style="width: 15rem;">
							<div class="d-flex flex-column">
								<span class="p-1" style="font-size: 1rem; color: black;">${user.realname}</span>
								<span class="p-1" style="font-size: 0.8rem;">${user.address}</span>
								<span class="p-1" style="font-size: 1rem; color: black;">${user.tel}</span>
								<span class="p-1" style="font-size: 0.8rem;">${user.cart_id}</span>
								<span class="p-1" style="font-size: 1rem; color: black;">${user.password}</span>
								<span class="p-1" style="font-size: 0.8rem;">${user.money}</span>
								
							</div>
						
					</form> -->
						
						<tr>
						
						<form action="/shopping/InfoUser" method="post">
				   <th>	    <button name="userid" value="${user.userid }">		
					            <td>${user.userid}</td> </button></form></th>
					             
								<td>${user.username} </td>
								<td>${user.realname} </td>								
								<td>${user.address} </td>
								<td>${user.tel}</td>
								<td>${user.cart_id} </td>
								<td>${user.password} </td>								
								<td>${user.money} </td>	
								<td>
								<button data-toggle="modal" data-target="#editUser"
								class="px-2 py-1 mr-1"
								style="background-color:  rgba(13,110,253,.25); color: white;">重置密码</button>
								</td>
						
								<td>
						             <div  style="width:100%;box-sizing:border-box;" class="anan1">
								 <!--      
								 <div
								class="d-flex flex-row justify-content-center align-items-center">
								<form action="/shopping/ListGoodsM" method="post">
									<button name="editgoodid" value="${good.commodity_id}"
										class="px-2 py-1 mr-1"
										style="background-color: rgba(255, 127, 80, 0.6); color: white;">编辑</button>
								</form>
								<button value="${good.commodity_id}" onclick="editgood(value)"
									data-toggle="modal" data-target="#editGoodModal"
									class="px-2 py-1 mr-1"
									style="background-color: rgba(30, 144, 255, 0.6); color: white;">确认编辑</button>
								<button value="${good.commodity_id}" class="px-2 py-1"
									style="background-color: rgba(255, 0, 0, 0.6); color: white;"
									onclick="deleteGood(value)">删除</button>
							</div>
							-->  

									<button name="edituserid" value="${user.userid}"
										class="px-2 py-1 mr-1"
										style="background-color: rgba(255, 127, 80, 0.6); color: white;">编辑</button>
								
							        <button value="${user.userid}" onclick="edituser(value)" data-toggle="modal" data-target="#editUserModal"
								class="px-2 py-1 mr-1"
								style="background-color:  rgba(13,110,253,.25); color: white;">确认编辑</button>
							         <button value="${user.userid}" class="px-2 py-1"
								style="background-color:rgba(13,110,253,.25); color: white;"
								onclick="deleteUser(value,${deleteflag})">删除</button></td>
							             	</div>
							</td>
							
																											
							</tr>
						</div>
					</div>
					</button>
					</form>
				</c:forEach>
				  </table>
				  
<!-- 模态框添加商品 -->
		<div class="modal fade" id="addGoodModal" tabindex="-1" role="dialog"
			aria-labelledby="addGoodModalLabel" aria-hidden="true">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<h4 class="modal-title" id="addGoodModalLabel">添加用户</h4>
						<button type="button" class="close" data-dismiss="modal"
							aria-hidden="true">&times;</button>

					</div>
					<form action="/shoppingcc/AddUser" method="post">
						<div class="modal-body">
							<div class="p-2 d-flex flex-row"
								style="color: rgba(0, 0, 0, 0.7);">
								<label class="pr-2">用户id</label><input class="form-control"
									type="text" name="adduserid">
							</div>
							<div class="p-2 d-flex flex-row"
								style="color: rgba(0, 0, 0, 0.7);">
								<label class="pr-2">用户名</label><input class="form-control"
									type="text" name="addusername">
							</div>
							<div class="p-2 d-flex flex-row"
								style="color: rgba(0, 0, 0, 0.7);">
								<label class="pr-2">用户真实姓名</label><input class="form-control"
									type="text" name="addrealname">
							</div>
							<div class="p-2 d-flex flex-row"
								style="color: rgba(0, 0, 0, 0.7);">
								<label class="pr-2">用户地址</label>
								<textarea class="form-control" name="addaddress"></textarea>
							</div>
							<div class="p-2 d-flex flex-row"
								style="color: rgba(0, 0, 0, 0.7);">
								<label class="pr-2">用户电话号码</label>
								<textarea class="form-control" name="addtel"></textarea>
							</div>
							<div class="p-2 d-flex flex-row"
								style="color: rgba(0, 0, 0, 0.7);">
								<label class="pr-2">用户密码</label>
								<textarea class="form-control" name="addpassword"></textarea>
							</div>
							<div class="p-2 d-flex flex-row"
								style="color: rgba(0, 0, 0, 0.7);">
								<label class="pr-2">用户额度</label>
								<textarea class="form-control" name="addmoney"></textarea>
							</div>
						</div>
						<div class="modal-footer">
							<button type="button" class="btn btn-default"
								data-dismiss="modal">关闭</button>
								<button type="button" class="btn btn-default"
								data-dismiss="modal">确定</button>
						</div>
					</form>
				</div>
				<!-- /.modal-content -->
			</div>
			<!-- /.modal -->
		</div>
<!-- 模态框编辑用户信息 -->
	<div class="">
		<div class="modal fade" id="editUserModal" tabindex="-1" role="dialog"
			aria-labelledby="editGoodModalLabel" aria-hidden="true">
			<div class="modal-dialog">
				<div class="modal-content" >
					<div class="modal-header" style="background-color: #f4de853d">
						<h4 class="modal-title" id="editGoodModalLabel">编辑用户信息</h4>
						<button type="button" class="close" data-dismiss="modal"
							aria-hidden="true">&times;</button>

					</div>
					<form action="/shopping/EditGood" method="post">
						<div class="modal-body">
							<div class="p-2 d-flex flex-row"
								style="color: rgba(0, 0, 0, 0.7);">
								<label class="pr-2">商品名称</label><input class="form-control"
									type="text" name="editgoodname"
									value="${editgood.commodity_name}">
							</div>
							<div class="p-2 d-flex flex-row"
								style="color: rgba(0, 0, 0, 0.7);">
								<label class="pr-2">用户id</label><input class="form-control"
									type="text" name="edituserid"
									value="${edituser.userid}">
							</div>
							<div class="p-2 d-flex flex-row"
								style="color: rgba(0, 0, 0, 0.7);">
								<label class="pr-2">用户姓名</label><input class="form-control"
									type="text" name="editusername"
									value="${edituser.username}">
							</div>
							<div class="p-2 d-flex flex-row"
								style="color: rgba(0, 0, 0, 0.7);">
								<label class="pr-2">用户真实姓名</label> <input class="form-control"
									name="editrealname" value="${edituser.realname}">
							</div>
							<div class="p-2 d-flex flex-row"
								style="color: rgba(0, 0, 0, 0.7);">
								<label class="pr-2">用户地址</label> <input class="form-control"
									name="edituseraddress" value="${edituser.address}">
							</div>
							<div class="p-2 d-flex flex-row"
								style="color: rgba(0, 0, 0, 0.7);">
								<label class="pr-2">用户电话</label> <input class="form-control"
									name="editusertel" value="${edituser.tel}">
							</div>
							<div class="p-2 d-flex flex-row"
								style="color: rgba(0, 0, 0, 0.7);">
								<label class="pr-2">用户密码</label> <input class="form-control"
									name="editpassword" value="${edituser.password}">
							</div>
							<div class="p-2 d-flex flex-row"
								style="color: rgba(0, 0, 0, 0.7);">
								<label class="pr-2">用户额度</label> <input class="form-control"
									name="editmoney" value="${editmoney.money}">
							</div>
						</div>
					</form>
					<div class="modal-footer">
						<button type="button" class="btn btn-default" data-dismiss="modal">关闭
						</button>
						<button type="button" class="btn btn-default" data-dismiss="modal">确定
						</button>
						
					</div>
				</div>
				<!-- /.modal-content -->
			</div>
			<!-- /.modal -->
		</div>
			</div>
		
	
		<div class="modal fade" id="editUser" tabindex="-1" role="dialog"
			aria-labelledby="editUser" aria-hidden="true">
			<div class="modal-dialog">
				<div class="modal-content" >
					<div class="modal-header" style="background-color: #f4de853d">
						<h4 class="modal-title" id="editUserid">重置密码</h4>
						<button type="button" class="close" data-dismiss="modal"
							aria-hidden="true">&times;</button>

					</div>
					<div class="modal-body">						
						<div class="p-2 d-flex flex-row"
							style="color: rgba(0, 0, 0, 0.7);">
							<label class="pr-2">用户密码</label>
							<textarea class="form-control" name="editgoodinfo">123456</textarea>
						</div>
											
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-default" data-dismiss="modal">关闭
						</button>
						<button type="submit" class="btn btn-default" data-dismiss="modal">确定
						</button>
						
					</div>
				</div>
				<!-- /.modal-content -->
			</div>
			<!-- /.modal -->
</body>
<style>
button{
border-radius:20%}
a {
	text-decoration: none;
	color: rgba(0, 0, 0, 0.6);
}

a:hover {
	color: rgba(0, 0, 0, 0.8);
}

body {
	background-color: rgba(135, 206, 250, 0.1);
	width: 100vw;
	height: 100vh;
	padding: 0;
	margin: 0
}
.container h2{
	text-align: center;
	
	
}
td{
text-align: center;
}
.tou1{
	margin-top:30px;
	border-bottom:1px solid #bec2c1;
	margin-top: 30px;
	padding-bottom: 10px;
	text-align: center;
}
.anan1{
text-align: center;}
.anan1  a{
border:1px #a3a59csolid;
	background-color: #bfb7b7de;;
	color:white;
	
	border-radius:30%;
	padding:5px;
}
th{
text-align: center;
}
.tuichu{
margin-top: 30px;
padding: 10px;
float:right;
margin-bottom: -90px;
	}
.user1{
margin-top: -45px;
padding: 10px;
float: left;
	
	}
.modal-content {
    position: relative;
    display: flex;
    flex-direction: column;
    width: 100%;
    pointer-events: auto;
    background-color: #f7e18b;
    background-clip: padding-box;
    border: 1px solid rgba(0,0,0,.2);
    border-radius: .3rem;
    outline: 0;
}
</style>
</html>