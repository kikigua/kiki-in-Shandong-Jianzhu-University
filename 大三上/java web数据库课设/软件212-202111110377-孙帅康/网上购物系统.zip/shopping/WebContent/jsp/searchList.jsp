<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8" import="java.util.List,bean.*"%>
<%@taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>搜索结果</title>
<!-- 新 Bootstrap4 核心 CSS 文件 -->
<link rel="stylesheet" href="https://cdn.staticfile.org/twitter-bootstrap/4.3.1/css/bootstrap.min.css">
 
<!-- jQuery文件。务必在bootstrap.min.js 之前引入 -->
<script src="https://cdn.staticfile.org/jquery/3.2.1/jquery.min.js"></script>
 
<!-- 用于弹窗、提示、下拉菜单，包含了 popper.min.js -->
<script src="https://cdn.staticfile.org/popper.js/1.15.0/umd/popper.min.js"></script>
 
<!-- 最新的 Bootstrap4 核心 JavaScript 文件 -->
<script src="https://cdn.staticfile.org/twitter-bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>
<body>
	<div class="container pb-5">
		<div
			class="d-flex flex-row justify-content-between align-items-center">
			<h3 class="px-2 pt-5">热销商品</h3>
			<%
				List<GoodBean> searchGood = (List<GoodBean>) request.getAttribute("searchGood");
				List<GoodBean> hotGood = (List<GoodBean>) request.getAttribute("hotGood");
			%>
			<form action="/shopping/SearchGood" method="post" class="px-2 pt-5">
				<input class="p-1" type="search" name="searchKey"
					placeholder="请输入要搜索的商品">
				<button class="px-3 py-2"
					style="background-color: rgba(30, 144, 255, 0.6); color: white;">
					<svg t="1609859727839" class="icon" viewBox="0 0 1024 1024"
						version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="2689"
						data-spm-anchor-id="a313x.7781069.0.i1" width="1.2rem"
						height="1.2rem"> <path
						d="M902.4 889.6l-156.8-156.8c156.8-147.2 166.4-393.6 22.4-553.6S371.2 12.8 211.2 160C51.2 307.2 44.8 553.6 192 713.6c131.2 140.8 342.4 166.4 502.4 60.8l160 163.2c12.8 12.8 32 12.8 44.8 0 12.8-12.8 16-35.2 3.2-48z m-755.2-448c0-182.4 147.2-329.6 329.6-329.6 182.4 0 329.6 147.2 329.6 329.6 0 182.4-147.2 329.6-329.6 329.6C294.4 774.4 147.2 624 147.2 441.6z"
						p-id="2690" fill="#ffffff"></path></svg>
				</button>
			</form>
		</div>
		<div class="row  pt-2">
			<c:forEach var="hotgood" items="${hotGood }">
				<div class="d-flex flex-column col-sm-6 col-md-4 col-xl-3 p-3">
					<form action="/shopping/InfoGood" method="post">
						<button name="commodity_id" value="${hotgood.commodity_id }"
							class="m-1 p-3 justify-content-start align-items-center a"
							style="background-color: transparent">
							<div class="d-flex flex-row">
								<span><svg t="1609926496254" class="icon"
										viewBox="0 0 1024 1024" version="1.1"
										xmlns="http://www.w3.org/2000/svg" p-id="4735" width="1.2rem"
										height="1.2rem"> <path
										d="M352.124 962c-59.598-125.442-28.224-197.568 18.81-263.412 50.166-75.276 62.712-147.384 62.712-147.384s40.77 50.166 25.092 131.706c68.994-78.39 81.54-203.832 72.126-250.884C687.644 541.79 756.656 783.26 665.702 958.868c482.922-275.958 119.16-686.754 56.448-730.656 21.96 47.034 25.092 125.424-18.828 163.062C631.214 115.316 452.456 62 452.456 62c21.942 141.12-75.276 294.768-169.344 410.814-3.132-56.448-6.282-94.086-37.638-150.534-6.264 103.5-84.672 185.022-106.614 288.504C110.636 751.904 160.82 852.236 352.124 962z"
										p-id="4736" fill="#FF7F50"></path></svg></span> <span class="px-2 py-1"
									style="font-size: 0.9rem; color: rgba(0, 0, 0, 0.8)">${hotgood.commodity_name}</span>
							</div>
							<div class="d-flex flex-row">
								<span class="px-4 py-1" style="font-size: 0.7rem">${hotgood.commodity_info}</span>
							</div>
						</button>
					</form>

				</div>
			</c:forEach>
		</div>
		<h3 class="px-2 pt-5">搜索结果</h3>
		<div class="row justify-content-center align-items-center pt-2">
			<c:forEach var="good" items="${searchGood }">
				<%
					String path = request.getContextPath();
						String basePath = request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort()
								+ path;
				%>
				<div
					class="d-flex flex-column col-sm-6 col-md-4 col-xl-3 p-3 justify-content-center align-items-center">
					<form action="/shopping/InfoGood" method="post">
						<button name="commodity_id" value="${good.commodity_id }"
							class="m-1 p-3 bg-grey justify-content-center align-items-center a"
							style="height: 20rem">
							<img alt="商品图片" src="<%=basePath%>${good.commodity_pic}"
								class="img-fluid py-2" style="width: 15rem; margin: 0 auto;">
							<div class="d-flex flex-column">
								<div
									class="d-flex flex-row justify-content-center align-items-center">
									<span class="p-1" style="font-size: 1rem; color: black;">${good.commodity_name}</span>
									<span class="mt-1 p-1" style="font-size: 0.8rem;">（${good.family_name}）</span>
								</div>
								<span class="p-1" style="font-size: 0.8rem;">${good.commodity_info}</span>
								<span class="px-1 pt-2" style="font-size: 0.8rem; color: red;">￥${good.commodity_price}</span>
							</div>
						</button>
					</form>
				</div>
			</c:forEach>
		</div>
	</div>
</body>
<style>
button {
	border: none;
	outline: none;
	border-color: transparent;
}

.a {
	text-decoration: none;
	color: rgba(0, 0, 0, 0.6);
}

.a:hover {
	color: rgba(0, 0, 0, 0.8);
	transform: scale(1.07);
}

.bg-grey {
	background-color: rgba(135, 206, 250, 0.1);
}

li {
	list-style: none;
}

a {
	text-decoration: none;
}
</style>
</html>