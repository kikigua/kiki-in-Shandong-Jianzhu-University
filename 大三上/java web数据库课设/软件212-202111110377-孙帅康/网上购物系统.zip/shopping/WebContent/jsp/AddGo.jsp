<%@ page language="java" contentType="text/html; charset=utf-8"  pageEncoding="utf-8" errorPage="/error.jsp"  %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>


<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<title>增加商品信息</title>

	</head>
	<body>
		<!-- content -->
		<div class="content">
			<form action="${pageContext.request.contextPath}/AddGoodServlet" method="post">
				<table class="mtable3" align=center>
					<caption>增加商品信息</caption>
					
					<tr><td>商品名:</td><td><input type="text" name="commodity_name" value="${newgood.commodity_name}"/></td></tr>
					<tr><td>库存</td><td><input type="text" name="commodity_num" value="${newgood.commodity_num}"/></td></tr>
					<tr><td>价格</td><td><input type="text" name="commodity_price" value="${newgood.commodity_price}"/></td></tr>
					<tr><td>简介</td><td><input type="text" name="commodity_info" value="${newgood.commodity_info}"/></td></tr>
					<tr><td><input type="reset" value="重置"/><input type="submit" value="提交"/></td></tr>
				</table>
			</form>
		</div>
		
	</body>
</html>