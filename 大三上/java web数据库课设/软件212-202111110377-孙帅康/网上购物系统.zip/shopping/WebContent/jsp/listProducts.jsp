<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8" import="java.util.List,bean.*"%>
<%@taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>评论管理</title>
<!-- 新 Bootstrap4 核心 CSS 文件 -->
<link rel="stylesheet" href="https://cdn.staticfile.org/twitter-bootstrap/4.3.1/css/bootstrap.min.css">
 
<!-- jQuery文件。务必在bootstrap.min.js 之前引入 -->
<script src="https://cdn.staticfile.org/jquery/3.2.1/jquery.min.js"></script>
 
<!-- 用于弹窗、提示、下拉菜单，包含了 popper.min.js -->
<script src="https://cdn.staticfile.org/popper.js/1.15.0/umd/popper.min.js"></script>
 
<!-- 最新的 Bootstrap4 核心 JavaScript 文件 -->
<script src="https://cdn.staticfile.org/twitter-bootstrap/4.3.1/js/bootstrap.min.js"></script>
<%-- 	<link rel="stylesheet" href="./css/reset.css" />
    <link rel="stylesheet" href="./css/content.css" />
    <link rel="stylesheet" href="./css/public.css" />
    --%>
     <link rel="stylesheet" href="./css/product.css" />
</head>

<body>
    
	
<div class="houtai1">
<ul>
  <li><a href="/shopping/ListProducts" >用户评论</a></li>
    <li><a href="/shopping/ListGoodsM" >商品管理</a></li>
  <li><a href="/shopping/listProductPass">通过评论</a></li>
  <li><a href="/shopping/ListUsers">用户信息</a></li>
  <li><a href="/shopping/ListUsers">会员信息</a></li>
   <li><a href="/shopping/ListOrders">订单信息</a></li>
    <li><a href="/shopping/jsp/login.jsp">退出登录</a></li>
 
</ul>
</div>
<div class="container">
	
	     <div class="tou" style="float:center"> <h2>评论信息</h2>  
	     <a href="jsp/houtai.jsp" class="btn btn-default">返回后台首页</a>	
	     </div>
		<br>		
		<div class=" flex-row justify-content-between">
			<%
				List<ProductBean> ListOrder = (List<ProductBean>) request.getAttribute("allproduct");
			%>
			<div class="row justify-content-center align-items-center">
			<table class="table table-hover table-responsive table-striped table-bordered">
			<table class="table table-hover table-responsive table-striped table-bordered">
			<tr class="biao">
                        <th style="width:10%">会员ID</th>                    
                        <th style="width:10%">商品id</th>
                         <th style="width:10%">评价等级</th>  
                         <th style="width: 40%;">文字评价</th>                        
                          <th style="width: 10%">审核状态</th>
                           <th style="width: 30%">操作</th>                  
                    </tr>
			  
				<c:forEach var="product" items="${allProduct}">
					<div class="">

						<div class="">
						
							<tr>
								<td>${product.vip_id}</td>
								<td>${product.commodity_id} </td>
								<td>${product.grade} </td>								
								<td>${product.text} </td>
								<td>${product.flag== 1?'通过':'待审核'}</td>
                            <td><a class="btn btn-default" href="/shopping/listProductPass">通过</a>
                            <a class="btn btn-default" href="/shopping/listProductPass" >不通过</a></td>                                       								
								
							</tr>
						</div>
					</div>
				</c:forEach>
				  </table>
				  </table>
			</div>
		</div>
		</div>
</body>
<style>

a {
	text-decoration: none;
	color: rgba(0, 0, 0, 0.6);
}

a:hover {
	color: rgba(0, 0, 0, 0.8);
}

body {
	background-color: rgba(135, 206, 250, 0.1);
	width: 100vw;
	height: 100vh;
	padding: 0;
	margin: 0
}

.container a{
	border:1px #a3a59csolid;
	background-color: #c0c0c0;


}
.container .tou{
	border-bottom:1px solid #bec2c1;
	margin-top: 30px;
	padding-bottom: 10px;
}
.houtai1{

width:100%;
text-align:center;
font-size:20px;

height:100px;
}
.houtai1 ul {

padding-right:100px;
    list-style-type: none;
    margin: 0;
 
    overflow: hidden;
    background-color: #333;
}

.houtai1 li {
    float: left;
}

.houtai1 li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

.houtai1 li a:hover {
    background-color:rgba(13,110,253,.25);
}
.houtai1 a {
	text-decoration: none;
	color: rgba(0, 0, 0, 0.6);
	  
}

.houtai1 a:hover {
	color: rgba(0, 0, 0, 0.8);
}
tr td{
text-align:center}
.biao{

}
</style>
</html>