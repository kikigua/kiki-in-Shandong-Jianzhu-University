<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8" import="java.util.List,bean.*"%>
<%@taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>用户搜索结果</title>
<!-- 新 Bootstrap4 核心 CSS 文件 -->
<link rel="stylesheet" href="https://cdn.staticfile.org/twitter-bootstrap/4.3.1/css/bootstrap.min.css">
 
<!-- jQuery文件。务必在bootstrap.min.js 之前引入 -->
<script src="https://cdn.staticfile.org/jquery/3.2.1/jquery.min.js"></script>
 
<!-- 用于弹窗、提示、下拉菜单，包含了 popper.min.js -->
<script src="https://cdn.staticfile.org/popper.js/1.15.0/umd/popper.min.js"></script>
 
<!-- 最新的 Bootstrap4 核心 JavaScript 文件 -->
<script src="https://cdn.staticfile.org/twitter-bootstrap/4.3.1/js/bootstrap.min.js"></script>
	<script type="text/javascript">
	function deleteUser(id,flag) {
		//alert('学生信息已保存');
		console.log(flag);
		if (confirm("确认要删除吗？")){
			window.location.href = '/shopping/SearchUser?deleteId=' + id;
		}
		if(flag == "true"){
			alert("删除成功");
		}else if(flag == "false"){
			alert("删除失败");
		}
	}
</script>
</head>
<body>
	<div class="container">
		<h3>用户搜索结果</h3>
			<button class="tuichu" style="background-color:rgba(13,110,253,.25); color: white;"><a  href="/shopping/ListUsers">back</a></button>
				
		<%
			List<UserBean> searchUser = (List<UserBean>) request.getAttribute("searchUser");
	     	String deleteflag = request.getParameter("deleteflag");
		%>
		<div class="row justify-content-center align-items-center">
				<table
					class="table table-hover table-responsive table-striped table-bordered">
					<tr>
						<th style="width:10%">用户ID</th>
                        
                        <th style="width:10%">用户名字</th>
                         <th style="width:10%">用户真实姓名</th>  
                         <th style="width: 10%">用户地址</th> 
                         <th style="width:10%">用户电话</th>  
                        
                         <th style="width:10%">用户购物车id</th>  
                          <th style="width: 10%">用户密码</th> 
                         <th style="width:10%">用户额度</th>  
                          
                            <th>操作</th> 
					</tr>

					<c:forEach var="user" items="${searchUser}">
				<%
					String path = request.getContextPath();
						String basePath = request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort()
								+ path;
				%>
								<tr>
									<<td>${user.userid}</td>
								<td>${user.username} </td>
								<td>${user.realname} </td>								
								<td>${user.address} </td>
								<td>${user.tel}</td>
								<td>${user.cart_id} </td>
								<td>${user.password} </td>								
								<td>${user.money} </td>	
									<td>
						             <div  style="width:100%;box-sizing:border-box;" class="anan1">
								 <!--       <button class="px-2 py-1 mr-1" style="background-color: rgba(13,110,253,.25); color: white;">编辑</button> -->  
							        <button data-toggle="modal" data-target="#editGoodModal"
								class="px-2 py-1 mr-1"
								style="background-color:  rgba(13,110,253,.25); color: white;">编辑</button>
							         <button value="${user.userid}" class="px-2 py-1"
								style="background-color:rgba(13,110,253,.25); color: white;"
								onclick="deleteUser(value,${deleteflag})">删除</button></td>
							             	</div>
							</td>
								</tr>
					</c:forEach>
				</table>
				<div class="">
		<div class="modal fade" id="editGoodModal" tabindex="-1" role="dialog"
			aria-labelledby="editGoodModalLabel" aria-hidden="true">
			<div class="modal-dialog">
				<div class="modal-content" >
					<div class="modal-header" style="background-color: #f4de853d">
						<h4 class="modal-title" id="editGoodModalLabel">编辑用户信息</h4>
						<button type="button" class="close" data-dismiss="modal"
							aria-hidden="true">&times;</button>

					</div>
					<div class="modal-body">
						<div class="p-2 d-flex flex-row"
							style="color: rgba(0, 0, 0, 0.7);">
							<label class="pr-2">用户id</label><input class="form-control"
								type="text" name="editgoodname" value="">
						</div>
						<div class="p-2 d-flex flex-row"
							style="color: rgba(0, 0, 0, 0.7);">
							<label class="pr-2">用户姓名</label><input class="form-control"
								type="text" name="editgoodprice">
						</div>
						<div class="p-2 d-flex flex-row"
							style="color: rgba(0, 0, 0, 0.7);">
							<label class="pr-2">用户真实姓名</label><input class="form-control"
								type="text" name="editgoodprice">
						</div>
						<div class="p-2 d-flex flex-row"
							style="color: rgba(0, 0, 0, 0.7);">
							<label class="pr-2">用户地址</label>
							<textarea class="form-control" name="editgoodinfo"></textarea>
						</div>
						<div class="p-2 d-flex flex-row"
							style="color: rgba(0, 0, 0, 0.7);">
							<label class="pr-2">用户电话</label>
							<textarea class="form-control" name="editgoodinfo"></textarea>
						</div>
						<div class="p-2 d-flex flex-row"
							style="color: rgba(0, 0, 0, 0.7);">
							<label class="pr-2">用户密码</label>
							<textarea class="form-control" name="editgoodinfo"></textarea>
						</div>
						<div class="p-2 d-flex flex-row"
							style="color: rgba(0, 0, 0, 0.7);">
							<label class="pr-2">用户额度</label>
							<textarea class="form-control" name="editgoodinfo"></textarea>
						</div>						
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-default" data-dismiss="modal">关闭
						</button>
						<button type="button" class="btn btn-default" data-dismiss="modal">确定
						</button>
						
					</div>
				</div>
				<!-- /.modal-content -->
			</div>
			<!-- /.modal -->
		</div>
	</div>
</body>
<style>
a {
	text-decoration: none;
	color: rgba(0, 0, 0, 0.6);
}

a:hover {
	color: rgba(0, 0, 0, 0.8);
	height: 102%;
	width: 102%;
}

.bg-grey {
	background-color: rgba(135, 206, 250, 0.1);
}
body{
  background-color: #f7e18b;}
  .tuichu{
margin-top: -80px;
padding: 10px;
float: right;
border-radius:20%;
	}
.container{
margin-top:40px;}
h3{
padding-bottom:40px;
}
</style>
</html>