<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8" import="java.util.List,util.*"%>
<%@taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>添加订单</title>
<!-- 新 Bootstrap4 核心 CSS 文件 -->
<link rel="stylesheet" href="https://cdn.staticfile.org/twitter-bootstrap/4.3.1/css/bootstrap.min.css">
 
<!-- jQuery文件。务必在bootstrap.min.js 之前引入 -->
<script src="https://cdn.staticfile.org/jquery/3.2.1/jquery.min.js"></script>
 
<!-- 用于弹窗、提示、下拉菜单，包含了 popper.min.js -->
<script src="https://cdn.staticfile.org/popper.js/1.15.0/umd/popper.min.js"></script>
 
<!-- 最新的 Bootstrap4 核心 JavaScript 文件 -->
<script src="https://cdn.staticfile.org/twitter-bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>
<body>
<body>
	<h2>添加订单</h2>
	<div style="width: 100%;" align="center">
		<form action="/shopping/AddOrder" method="post">
			<label>订单ID：</label><input type="text" name="Order_id"><br>
			<label>订单日期：</label><input type="text" name="OrderDate"><br>
			<label>订单状态：</label><input type="text" name="Orderstatus"><br>
			<lable>会员ID：</lable>
			<input type="text" name="Vip_id"><br>
			<lable>会员名称：</lable>
			<input type="text" name="Username"><br>
			<lable>消费总额：</lable>
			<input type="text" name="Countmoney"><br>
			<input type="submit" value="提交">
			<input type="reset" value="重置">
		</form>
	</div>
</body>
<style type="text/css">
h2 {
	text-align: center;
	font-weight: bold;
	font-size: 35px;
}
input{
    width:100px;
    height:30px;
    line-height:10px; 

}
body {
	background-image: linear-gradient(to right,#F0FFF0 ,#F0FFF0 );
	width: 100vw;
	height: 100vh;
	padding: 0;
	margin: 0
}
</style>
</html>