<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8" import="java.util.List,util.*"%>
<%@taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<div style="float: center">
<title>订单搜索结果</title>
<br><br>
<!-- 新 Bootstrap4 核心 CSS 文件 -->
<link rel="stylesheet" href="https://cdn.staticfile.org/twitter-bootstrap/4.3.1/css/bootstrap.min.css">
 
<!-- jQuery文件。务必在bootstrap.min.js 之前引入 -->
<script src="https://cdn.staticfile.org/jquery/3.2.1/jquery.min.js"></script>
 
<!-- 用于弹窗、提示、下拉菜单，包含了 popper.min.js -->
<script src="https://cdn.staticfile.org/popper.js/1.15.0/umd/popper.min.js"></script>
 
<!-- 最新的 Bootstrap4 核心 JavaScript 文件 -->
<script src="https://cdn.staticfile.org/twitter-bootstrap/4.3.1/js/bootstrap.min.js"></script>
	 <script type="text/javascript">
	function deleteOrder(id) {
		if (confirm("确认要删除吗？")){
			window.location.href = '/shopping/ListOrders?deleteId=' + id;
		}
	}
</script>
</head>
<body>
<div class="container">
			<%	
			String deleteflag = request.getParameter("deleteflag");
			String path = request.getContextPath();
			String basePath = request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort()
					+ path;
		%>
	
		<h3>订单搜索结果</h3>
		<br>
	
	
		<div class="row justify-content-center align-items-center">
				<table
					class="table table-hover table-responsive table-striped table-bordered">
					<tr>
						<th style="width:10%">订单ID</th>
                        <th style="width:10%">订单日期</th>
                        <th style="width:10%">订单状态</th>
                         <th style="width:10%">会员ID</th>
                           <th style="width:10%">会员名称</th>   
                         <th style="width: 10%">消费总额</th> 
                         <th style="width:15%">对订单的操作</th>    
					</tr>
					<c:forEach var="order" items="${searchOrderAll }">
								<tr>
									<td>${order.order_id}</td>
								<td>${order.orderdate} </td>
								<td>${order.orderstatus} </td>
								<td>${order.vip_id}</td>
								<td>${order.username}</td>
								<td>${order.countmoney}</td>
								<td>
						             <div  style="width:100%;box-sizing:border-box;" class="anan1">
								         <button class="px-2 py-1 mr-1" data-toggle="modal" data-target="#editOrderModal"
								class="px-2 py-1 mr-1"
								         style="background-color:#FFFAF0 ; color: black;border-radius: 12px; border: 2px solid Gray">编辑</button>
							             <button value="${order.order_id}" class="px-2 py-1" style="background-color:#FF3333 ; color: white;border-radius: 12px; border: 2px solid white"
								      onclick="deleteOrder(value)">删除</button></td>
							</div>
								</td>
								</tr>
					</c:forEach>
				</table>
		<!-- 模态框编辑订单 -->
		<div class="modal fade" id="editOrderModal" tabindex="-1" role="dialog"
			aria-labelledby="editOrderModalLabel" aria-hidden="true">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header" style="background-color: #FFFFF0">
						<h4 class="modal-title" id="editOrderModalLabel">编辑订单信息</h4>
						<button type="button" class="close" data-dismiss="modal"
							aria-hidden="true">&times;</button>
					</div>
					<form action="/shopping/AddOrder" method="post">
					<div class="modal-body" style="background-color: #FFFFF0">
							<div class="p-2 d-flex flex-row"
								style="color: rgba(0, 0, 0, 0.7);">
								<label class="pr-2">订单日期</label><input class="form-control"
									type="text" name="editorderdate">
							</div>
							<div class="p-2 d-flex flex-row"
								style="color: rgba(0, 0, 0, 0.7);">
								<label class="pr-2">订单状态</label><input class="form-control"
									type="text" name="editorderstatus">
							</div>
							<div class="p-2 d-flex flex-row"
								style="color: rgba(0, 0, 0, 0.7);" >
								<label class="pr-2">会员ID</label><input class="form-control"
									type="text" name="addvip_id">
							</div>
							<div class="p-2 d-flex flex-row"
								style="color: rgba(0, 0, 0, 0.7);" >
								<label class="pr-2">会员名称</label><input class="form-control"
									type="text" name="addusername">
							</div>	
														<div class="p-2 d-flex flex-row"
								style="color: rgba(0, 0, 0, 0.7);" >
								<label class="pr-2">消费总额</label><input class="form-control"
									type="text" name="addcountmoney">
							</div>	
						</div>
					<div class="modal-footer" style="background-color: #FFFFF0">
						<button type="button" style="background-color: #FFFAF0; color: black;border-radius: 12px; border: 2px solid Gray" class="btn btn-default" data-dismiss="modal">关闭
						</button>
						<button type="submit"  style="background-color: #FFFAF0; color: black;border-radius: 12px; border: 2px solid Gray" class="btn btn-default"
							data-dismiss="modal">更新</button>
					</div>
				</div>
				<!-- /.modal-content -->
			</div>
			<!-- /.modal -->
		</div>
		<div class="tou2">
		<button style="background-color:#FFFAF0 ; color: black;border-radius: 12px; border: 2px solid Gray" float: right><a class="btn btn-default" href="/shopping/ListOrders">返回</a></button>
		</div>
		</div>
	</div>
</body>
<style>
a {
	text-decoration: none;
	color: rgba(0, 0, 0, 0.6);
}

a:hover {
	color: rgba(0, 0, 0, 0.8);
}

body {
    background-image: linear-gradient(to right,	#FFFFF0 ,#FFFFF0 );
	width: 100vw;
	height: 100vh;
	padding: 0;
	margin: 0
}
.tou2{
  margin-right: 5px;
	padding-bottom: 10px;
	text-align: center;
}
</style>
</html>