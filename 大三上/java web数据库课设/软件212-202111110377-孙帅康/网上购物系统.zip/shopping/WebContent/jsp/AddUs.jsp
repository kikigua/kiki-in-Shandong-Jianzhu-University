<%@ page language="java" contentType="text/html; charset=utf-8"  pageEncoding="utf-8" errorPage="/error.jsp"  %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>


<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<title>增加用户信息</title>

	</head>
	<body>
		<!-- content -->
		<div class="content">
			<form action="${pageContext.request.contextPath}/AddUserServlet" method="post">
				<table class="mtable3" align=center>
					<caption>增加用户信息</caption>
					
					<tr><td>用户id:</td><td><input type="text" name="userid" value="${newuser.userid}"/></td></tr>
					<tr><td>姓名</td><td><input type="text" name="username" value="${newuser.username}"/></td></tr>
					<tr><td>真实姓名</td><td><input type="text" name="realname" value="${newuser.realname}"/></td></tr>
					<tr><td>住址</td><td><input type="text" name="address" value="${newuser.address}"/></td></tr>
					<tr><td>电话</td><td><input type="text" name="tel" value="${newuser.tel}"/></td></tr>
					<tr><td>密码</td><td><input type="text" name="password" value="${newuser.password}"/></td></tr>
					<tr><td>金额</td><td><input type="text" name="money" value="${newuser.money}"/></td></tr>
					<tr><td><input type="reset" value="重置"/><input type="submit" value="提交"/></td></tr>
				</table>
			</form>
		</div>
		
	</body>
</html>