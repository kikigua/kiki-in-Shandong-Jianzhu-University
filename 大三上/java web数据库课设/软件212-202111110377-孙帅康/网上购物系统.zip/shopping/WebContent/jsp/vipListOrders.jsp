<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8" import="java.util.List,bean.*"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>会员订单信息</title>
<!-- 新 Bootstrap4 核心 CSS 文件 -->
<link rel="stylesheet" href="https://cdn.staticfile.org/twitter-bootstrap/4.3.1/css/bootstrap.min.css">
 
<!-- jQuery文件。务必在bootstrap.min.js 之前引入 -->
<script src="https://cdn.staticfile.org/jquery/3.2.1/jquery.min.js"></script>
 
<!-- 用于弹窗、提示、下拉菜单，包含了 popper.min.js -->
<script src="https://cdn.staticfile.org/popper.js/1.15.0/umd/popper.min.js"></script>
 
<!-- 最新的 Bootstrap4 核心 JavaScript 文件 -->
<script src="https://cdn.staticfile.org/twitter-bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <script type="text/javascript">
	function deleteOrder(id) {
		if (confirm("确认要删除吗？")){
			window.location.href = '/shopping/ListOrders?deleteId=' + id;
		}
	}
</script>
</head>
<body >
	<div class="container">
		<form action="/shopping/SearchOrder" method="post" class="px-2 pt-5">
			<div class="tou1">
				<h2>会员订单信息</h2>
			<button style="width: 1.9rem; height: 1.9rem;float: right">
				<svg t="1609761073820" class="icon" viewBox="0 0 1024 1024"
					version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="1219"
					width="1.1rem" height="1.1rem"> <path
					d="M902.4 889.6l-156.8-156.8c156.8-147.2 166.4-393.6 22.4-553.6S371.2 12.8 211.2 160C51.2 307.2 44.8 553.6 192 713.6c131.2 140.8 342.4 166.4 502.4 60.8l160 163.2c12.8 12.8 32 12.8 44.8 0 12.8-12.8 16-35.2 3.2-48z m-755.2-448c0-182.4 147.2-329.6 329.6-329.6 182.4 0 329.6 147.2 329.6 329.6 0 182.4-147.2 329.6-329.6 329.6C294.4 774.4 147.2 624 147.2 441.6z"
					p-id="1220"></path></svg>
			</button>
			 <input type="search"
				name="searchKey" style="float: right" placeholder="请输入订单状态或日期">
			
			<br><br>
			</div>
		</form>
		<%-- 
			<input type="text" name="order_id" value="" /> <button type="submit"
				name="get">查询</button>
				--%>
		<div class=" flex-row justify-content-between">
			<%
				List<orderBean> ListOrder = (List<orderBean>) request.getAttribute("allOrder");
			%>
			<div class="row justify-content-center align-items-center">
				<table
					class="table table-hover table-responsive table-striped table-bordered">
					<tr>
						<th style="width: 5%">订单ID</th>
						<th style="width: 8%">订单日期</th>
						<th style="width: 8%">订单状态</th>
						<th style="width: 8%">消费总额</th>
						<th style="width: 5%">对订单的操作</th>
					</tr>

					<c:forEach var="order" items="${allOrder}">
					  <form action="/shopping/InfoOrder" method="post">		
			  <td name="order_id" value="${order.order_id}"></td>
			  </form>
								<tr>
									<td>${order.order_id}</td>
									<td>${order.orderdate}</td>
									<td>${order.orderstatus}</td>
									<td>${order.countmoney}<span class="pl-2">元</span></td>
									<td>
						             <div  style="width:100%;box-sizing:border-box;" class="anan1">
								         <button class="px-2 py-1 mr-1" data-toggle="modal" data-target="#editOrderModal"
								class="px-2 py-1 mr-1"
								         style="background-color: #F5FFFA; color: black;border-radius: 12px; border: 2px solid Gray">编辑</button>
							             <button value="${order.order_id}" class="px-2 py-1" style="background-color:#FF3333 ; color: white;border-radius: 12px; border: 1px solid white"
								      onclick="deleteOrder(value)"><a href="/shopping/vipOrder">删除</a></button></td>
							</div>
							</td>	
								</tr>
							</div>
						</div>
					</c:forEach>
				</table>
				<div class="tou2">
		<button style="background-color:#F5FFFA ; color: black;border-radius: 12px; border: 2px solid Gray" ><a class="btn btn-default" href="/shopping/jsp/index.jsp">返回</a></button>
			</div>
				<!-- 模态框编辑订单 -->
		<div class="modal fade" id="editOrderModal" tabindex="-1" role="dialog"
			aria-labelledby="editOrderModalLabel" aria-hidden="true">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header" style="background-color: #F5FFFA">
						<h4 class="modal-title" id="editOrderModalLabel">编辑订单信息</h4>
						<button type="button" class="close" data-dismiss="modal"
							aria-hidden="true">&times;</button>
					</div>
					<form action="/shopping/AddOrder" method="post">
					<div class="modal-body" style="background-color: #F5FFFA">
							<div class="p-2 d-flex flex-row"
								style="color: rgba(0, 0, 0, 0.7);">
								<label class="pr-2">订单日期</label><input class="form-control"
									type="text" name="editorderdate">
							</div>
							<div class="p-2 d-flex flex-row"
								style="color: rgba(0, 0, 0, 0.7);">
								<label class="pr-2">订单状态</label><input class="form-control"
									type="text" name="editorderstatus">
							</div>
							<div class="p-2 d-flex flex-row"
								style="color: rgba(0, 0, 0, 0.7);" >
								<label class="pr-2">会员ID</label><input class="form-control"
									type="text" name="addvip_id">
							</div>
							<div class="p-2 d-flex flex-row"
								style="color: rgba(0, 0, 0, 0.7);" >
								<label class="pr-2">会员名称</label><input class="form-control"
									type="text" name="addusername">
							</div>	
														<div class="p-2 d-flex flex-row"
								style="color: rgba(0, 0, 0, 0.7);" >
								<label class="pr-2">消费总额</label><input class="form-control"
									type="text" name="addcountmoney"><span class="pl-2">元</span>
							</div>	
						</div>
					<div class="modal-footer" style="background-color: #F5FFFA">
						<button type="button" style="background-color: #F5FFFA; color: black;border-radius: 12px; border: 2px solid Gray" class="btn btn-default" data-dismiss="modal">关闭
						</button>
						<button type="submit"  style="background-color: #F5FFFA; color: black;border-radius: 12px; border: 2px solid Gray" class="btn btn-default"
							data-dismiss="modal">更新</button>
					</div>
				</div>
				<!-- /.modal-content -->
			</div>
			<!-- /.modal -->
		</div>
		</div>
	</div>
</body>
<style>
a {
	text-decoration: none;
	color: rgba(0, 0, 0, 0.6);
}

a:hover {
	color: rgba(0, 0, 0, 0.8);
}

body {
	background-color: rgba(135, 206, 250, 0.1);
	background-image: linear-gradient(to right,#F0FFF0 ,#F0FFF0 );
	<%--background:url(/img/1.jpg);
	background-size:800px 600px;
	background-repeat:no-repeat;
	padding-top:40px;	--%>
	width: 100vw;
	height: 100vh;
	padding: 0;
	}
.tou1{
	margin-top: 3px;
	padding-bottom: 10px;
	text-align: center;
}
.tou2{
     padding-right: 10px;
	padding-bottom: 10px;
	text-align: center;
}
</style>
</html>