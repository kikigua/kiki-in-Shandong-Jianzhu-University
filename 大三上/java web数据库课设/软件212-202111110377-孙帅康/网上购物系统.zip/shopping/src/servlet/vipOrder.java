package servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.orderBean;

@WebServlet("/vipOrder")
public class vipOrder extends HttpServlet {     
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String deleteId = (String)request.getParameter("deleteId");
		orderBean order = new orderBean();
		List<orderBean> allorder = order.listvipOrder();
		boolean deleteflag = order.deleteOrder(deleteId);
		// PrintWriter out = response.getWriter();
		// out.print(allorder);
		request.setAttribute("deleteflag", deleteflag);	
		request.setAttribute("allOrder", allorder);
		System.out.println(deleteflag);
		request.getRequestDispatcher("/jsp/vipListOrders.jsp").forward(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
