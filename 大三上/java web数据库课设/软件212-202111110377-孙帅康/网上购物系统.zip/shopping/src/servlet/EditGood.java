package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.GoodBean;

@WebServlet("/EditGood")
public class EditGood extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String editgoodname = request.getParameter("editgoodname");
		String editgoodprice = request.getParameter("editgoodprice");
		String editgoodnum = request.getParameter("editgoodnum");
		String editgoodinfo = request.getParameter("editgoodinfo");
		
		System.out.println("editgoodname*******"+editgoodname);
		System.out.println("editgoodprice*******"+editgoodprice);
		System.out.println("editgoodnum*******"+editgoodnum);
		System.out.println("editgoodinfo*******"+editgoodinfo);
		
		HttpSession session = request.getSession();
		String Seditgoodid = (String)session.getAttribute("editgoodid");
		int editgoodid = Integer.parseInt(Seditgoodid);
		
		GoodBean editgood = new GoodBean();
		editgood.setCommodity_name(editgoodname);
		editgood.setCommodity_price(Float.parseFloat(editgoodprice));
		editgood.setCommodity_num(Integer.parseInt(editgoodnum));
		editgood.setCommodity_info(editgoodinfo);
		
		System.out.println("editgoodname###################"+editgood.getCommodity_name());
		System.out.println("editgoodprice###################"+editgood.getCommodity_price());
		System.out.println("editgoodnum###################"+editgood.getCommodity_num());
		System.out.println("editgoodinfo###################"+editgood.getCommodity_info());
		
		GoodBean good = new GoodBean();
		boolean editgoodflag = good.editGood(editgood, editgoodid);
		
		System.out.println("editgood--"+editgood);
		System.out.println("editgoodid--"+editgoodid);
		System.out.println("editgoodflag--"+editgoodflag);
		
		request.getRequestDispatcher("/ListGoodsM").forward(request, response);
		
		
	}
}

