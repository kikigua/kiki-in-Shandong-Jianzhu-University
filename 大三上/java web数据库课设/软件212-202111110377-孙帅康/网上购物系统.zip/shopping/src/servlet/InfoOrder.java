package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//import util.UserBean;
import bean.orderBean;


@WebServlet("/InfoOrder")
public class InfoOrder extends HttpServlet {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int id = Integer.parseInt(request.getParameter("order_id"));
		orderBean order = new orderBean();
		orderBean orderInfo = order.listUserorderById(id);
		request.setAttribute("orderInfo", orderInfo);
		request.getRequestDispatcher("/jsp/OrderInfo.jsp").forward(request, response);
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
	public static void main(String[] args) {
		
	}

}
