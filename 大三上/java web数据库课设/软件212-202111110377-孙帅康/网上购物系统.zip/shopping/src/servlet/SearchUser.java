package servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.UserBean;

/**
 * Servlet implementation class SearchUser
 */
@WebServlet("/SearchUser")
public class SearchUser extends HttpServlet {	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String deleteId = (String)request.getParameter("deleteId");
		 UserBean user = new UserBean();
		 
		
		boolean deleteflag = user.deleteUser(deleteId);	
		String key = request.getParameter("searchKey");
		System.out.println(deleteflag);
		List<UserBean> searchUser = user.searchUser(key);		
		request.setAttribute("searchUser", searchUser);
		 request.setAttribute("deleteflag", deleteflag);
		request.getRequestDispatcher("/jsp/searchUser.jsp").forward(request,response);
	}
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	

}
