package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.GoodBean;

/**
 * Servlet implementation class AddUserServlet
 */
@WebServlet("/AddGoodServlet")
public class AddGoodServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddGoodServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		
		GoodBean newgood=new GoodBean();
		newgood.setCommodity_name(request.getParameter("commodity_name"));
		//���
		String commodityNumStr = request.getParameter("commodity_num");
		if (commodityNumStr != null) {
			int commodityNum = Integer.parseInt(commodityNumStr);
			newgood.setCommodity_num(commodityNum);
		} else {
		    // ��������Ϊnull���������������Ĭ��ֵ�����������Ϣ
		}
		//�۸�
		String commodityPriceStr = request.getParameter("commodity_price");
		float commodityPrice = Float.parseFloat(commodityPriceStr);
		newgood.setCommodity_price(commodityPrice);
		
		//���
		newgood.setCommodity_info(request.getParameter("commodity_info"));
//		//����Աid
//		String managerIdStr = request.getParameter("manager_id");
//		int managerId = Integer.parseInt(managerIdStr);
//		newgood.setManager_id(managerId);
		
		try {
			newgood.addGood1();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		request.getRequestDispatcher("/jsp/AddGo.jsp").forward(request, response);

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

