package servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//import util.Shopping_cartBean;
import bean.UserBean;

@WebServlet("/ListUsersVip")
public class ListUsersVip extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    UserBean user = new UserBean();
		List<UserBean> alluservip = user.listUserVip();
		

		for(UserBean good1 : alluservip){
			System.out.println(good1.getUsername());
//			System.out.println("\n");
			System.out.println(good1.getVgrade());
//			System.out.println("\n");
//			System.out.println(good1.getVip_id());
//			System.out.println("\n");
//			System.out.println(good1.getCommodity_info());
//			System.out.println("\n");
		}
		

//		out.print(all);
		
		request.setAttribute("alluservip", alluservip);
        request.getRequestDispatcher("/jsp/listvip.jsp").forward(request,response);       
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
	
}
