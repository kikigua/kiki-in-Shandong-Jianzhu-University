package servlet;

import java.io.IOException;
//import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.CartBean;
//import util.GoodBean;
//import util.GoodKindBean;

/**
 * Servlet implementation class DelCartGood
 */
@WebServlet("/DelCartGood")
public class DelCartGood extends HttpServlet
{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		String cartGID = (String)request.getParameter("cartGID");
		String commID = (String)request.getParameter("commID");

		CartBean commcart = new CartBean();
		
		boolean deletecart = commcart.deleteCart(cartGID,commID);
		request.setAttribute("deletecart", deletecart);

		System.out.println("cartID"+cartGID+"commID"+commID);
		System.out.println("deletecart");
		
		request.getRequestDispatcher("/jsp/myCart.jsp").forward(request, response);
		
//		String cartGID = (String)request.getParameter("cartGID");
//
//		CartBean commcart = new CartBean();
//		
//		boolean deletecart = commcart.ClearCart(cartGID);
//		request.setAttribute("deletecart", deletecart);
//
//		System.out.println("deletecart");
//		
//		request.getRequestDispatcher("/jsp/myCart.jsp").forward(request, response);
//		
	}

}
