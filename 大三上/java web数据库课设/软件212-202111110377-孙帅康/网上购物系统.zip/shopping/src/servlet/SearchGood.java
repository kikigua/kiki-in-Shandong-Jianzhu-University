package servlet;

import java.io.IOException;
//import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.GoodBean;
//import util.GoodKindBean;

@WebServlet("/SearchGood")
public class SearchGood extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String key = request.getParameter("searchKey");
//		String key = "��";
		GoodBean good = new GoodBean();
		List<GoodBean> searchGood = good.searchGood(key);
		List<GoodBean> hotGood = good.hotGood();
		
//		PrintWriter out = response.getWriter();
//		for(GoodBean good1 : searchGood){
//			out.print(good1.getCommodity_name());
//			out.print("\n");
//			out.print(good1.getCommodity_price());
//			out.print("\n");
//			out.print(good1.getCommodity_pic());
//			out.print("\n");
//			out.print(good1.getCommodity_info());
//			out.print("\n");
//			out.print(good1.getFamily_name());
//			out.print("\n");
//		}
		
//		PrintWriter out = response.getWriter();
//		out.print(searchGood);
		request.setAttribute("searchGood", searchGood);
		request.setAttribute("hotGood", hotGood);
		
		request.getRequestDispatcher("/jsp/searchList.jsp").forward(request,response);
	}
}
