package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.UserBean;

@WebServlet("/Register")
public class Register extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		UserBean user = new UserBean();
		int cart_id = user.addcart();
		
		String registerusername = request.getParameter("registerusername");
		String registerpassword = request.getParameter("registerpassword");
		String registerrealname = request.getParameter("registerrealname");
		String registeraddress = request.getParameter("registeraddress");
		String registertel = request.getParameter("registertel");

		UserBean registerUser = new UserBean();
		registerUser.setUsername(registerusername);
		registerUser.setPassword(registerpassword);
		registerUser.setRealname(registerrealname);
		registerUser.setAddress(registeraddress);
		registerUser.setTel(registertel);
		registerUser.setCart_id(cart_id);
		
		int registerUserId = registerUser.register(registerUser);
		
		if(registerUserId > 0){
			request.getRequestDispatcher("/jsp/login.jsp").forward(request, response);
		}else{
			request.getRequestDispatcher("/jsp/error.jsp").forward(request, response);
		}
	}
}
