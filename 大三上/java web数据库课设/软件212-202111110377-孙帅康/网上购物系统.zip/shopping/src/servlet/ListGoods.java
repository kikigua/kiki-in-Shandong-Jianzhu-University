package servlet;

import java.io.IOException;
//import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.GoodBean;
import bean.GoodKindBean;

@WebServlet("/listGoods")
public class ListGoods extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		GoodBean good = new GoodBean();
		GoodKindBean kind = new GoodKindBean();
		List<GoodBean> allGood = good.listGood();
		List<GoodKindBean> allKind = kind.listGoodKind();
		
//		PrintWriter out = response.getWriter();
//		for(GoodBean good1 : all){
//			out.print(good1.getCommodity_name());
//			out.print("\n");
//			out.print(good1.getCommodity_price());
//			out.print("\n");
//			out.print(good1.getCommodity_pic());
//			out.print("\n");
//			out.print(good1.getCommodity_info());
//			out.print("\n");
//		}
		
//		PrintWriter out = response.getWriter();
//		out.print(all);
		request.setAttribute("allGood", allGood);
		request.setAttribute("allKind", allKind);
		
		request.getRequestDispatcher("/jsp/index.jsp").forward(request,response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
}
