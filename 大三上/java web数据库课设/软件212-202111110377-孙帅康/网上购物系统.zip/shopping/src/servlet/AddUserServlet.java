package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.UserBean;

/**
 * Servlet implementation class AddUserServlet
 */
@WebServlet("/AddUserServlet")
public class AddUserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddUserServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		
		UserBean newuser=new UserBean();
		String useridStr = request.getParameter("userid");
		if (useridStr != null) {
			int userid = Integer.parseInt(useridStr);
			newuser.setUserid(userid);
		} else {
		    // ��������Ϊnull���������������Ĭ��ֵ�����������Ϣ
		}
		newuser.setUsername(request.getParameter("username"));
		newuser.setRealname(request.getParameter("realname"));
		newuser.setAddress(request.getParameter("address"));
		newuser.setTel(request.getParameter("tel"));
		newuser.setPassword(request.getParameter("password"));
		String moneyStr = request.getParameter("money");
		float money = Float.parseFloat(moneyStr);
		newuser.setMoney(money);
		
		try {
			newuser.addUser1();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		request.getRequestDispatcher("/jsp/AddUs.jsp").forward(request, response);

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}