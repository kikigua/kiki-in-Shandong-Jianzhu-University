package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.GoodBean;

//������Ʒ
@WebServlet("/AddGood")
public class AddGood extends HttpServlet {

	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String addgoodname = (String)request.getParameter("addgoodname");//��Ʒ����
		String addgoodprice = (String)request.getParameter("addgoodprice");//��Ʒ�۸�
		String addgoodnum = (String)request.getParameter("addgoodnum");//��Ʒ����
		String addgoodinfo = (String)request.getParameter("addgoodinfo");//��Ʒ���
		String managerid = (String)request.getParameter("managerid");//��Ʒid
		
		GoodBean addgood = new GoodBean();
		addgood.setCommodity_name(addgoodname);
		addgood.setCommodity_price(Float.parseFloat(addgoodprice));
		addgood.setCommodity_num(Integer.parseInt(addgoodnum));
		addgood.setCommodity_info(addgoodinfo);
		addgood.setManager_id(Integer.parseInt(managerid));
		request.getRequestDispatcher("/ListGoodsM").forward(request, response);
		
		
	}
}
