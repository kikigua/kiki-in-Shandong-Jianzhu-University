package servlet;

import java.io.IOException;
import java.io.PrintWriter;
//import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//import util.GoodBean;
import bean.GoodKindBean;

//������Ʒ����
@WebServlet("/AddGoodKind")
public class AddGoodKind extends HttpServlet {

	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String addkindname = request.getParameter("addgoodkindname");
		GoodKindBean goodkind = new GoodKindBean();
		boolean addkindflag = goodkind.addGoodKind(addkindname); 
		
		PrintWriter out = response.getWriter();
		out.print(addkindname);
		out.print(addkindflag);
		
		if(addkindflag){
			request.setAttribute("addkindmessage", "������Ʒ���ɹ���");
		}else{
			request.setAttribute("addkindmessage", "������Ʒ���ʧ�ܣ�");
		}
		request.getRequestDispatcher("/ListGoodsM").forward(request, response);
	}
}
