package servlet;

import java.io.IOException;
//import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

//import util.GoodBean;
//import util.ManagerBean;
import bean.Shopping_cartBean;
import bean.UserBean;

@WebServlet("/ListUsers")
public class ListUsers extends HttpServlet {
  /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    String deleteId = (String)request.getParameter("deleteId");
	    UserBean user = new UserBean();
	    String edituserid = request.getParameter("edituserid");
	    
	    HttpSession session = request.getSession();
		session.setAttribute("edituserid", edituserid);
		List<UserBean> alluser = user.listUser();
		boolean deleteflag = user.deleteUser(deleteId);	
		//UserBean edituser = user.editUser(editid);
		
		Shopping_cartBean shopping_cart = new Shopping_cartBean();
		List<Shopping_cartBean> shopping_cartlist = shopping_cart.listShopping_cart();
		
		request.setAttribute("deleteflag", deleteflag);
		request.setAttribute("allUser", alluser);
		request.setAttribute("shopping_cartlist", shopping_cartlist);
	//	request.setAttribute("edituser", edituser);

		
		System.out.println(deleteflag);
        request.getRequestDispatcher("/jsp/listUsers.jsp").forward(request,response);       
       
		
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
