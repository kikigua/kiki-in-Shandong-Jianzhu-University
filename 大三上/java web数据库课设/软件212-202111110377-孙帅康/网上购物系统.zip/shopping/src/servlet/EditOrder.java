package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
//import javax.servlet.http.HttpSession;

//import util.GoodBean;
import bean.orderBean;

/**
 * Servlet implementation class EditOrder
 */
@WebServlet("/EditOrder")
public class EditOrder extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException  {
		String editorder_id = request.getParameter("editorder_id");
		String editorderstatus = request.getParameter("editorderstatus");
		String editvip_id = request.getParameter("editvip_id");
		String editcountmoney = request.getParameter("editcountmoney");
		
		System.out.println("editorder_id*******"+editorder_id);
		System.out.println("editorderstatus*******"+editorderstatus);
		System.out.println("editvip_id*******"+editvip_id);
		System.out.println("editcountmoney*******"+editcountmoney);
		
//		HttpSession session = request.getSession();
//		String Seditorder_id = (String)session.getAttribute("editorder_id");
//		int editorder_id1 = Integer.parseInt(Seditorder_id);
		
		orderBean editorder = new orderBean();
		editorder.setOrder_id(Integer.parseInt(editorder_id));
		editorder.setOrderstatus(editorderstatus);
		editorder.setVip_id(Integer.parseInt(editvip_id));
		editorder.setCountmoney(Float.parseFloat(editcountmoney));
		
//		System.out.println("editorder_id###################"+editorder_id.getOrder_id());
		System.out.println("editorderstatus###################"+editorder.getOrderstatus());
		System.out.println("editvip_id###################"+editorder.getVip_id());
		System.out.println("editcountmoney###################"+editorder.getCountmoney());
		
//		GoodBean good = new GoodBean();
//		boolean editgoodflag = good.editGood(editgood, editgoodid);
//		
//		System.out.println("editgood--"+editgood);
//		System.out.println("editgoodid--"+editgoodid);
//		System.out.println("editgoodflag--"+editgoodflag);

	}



}
