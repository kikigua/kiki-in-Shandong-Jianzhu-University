package servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.GoodBean;
import bean.GoodKindBean;
import bean.UserBean;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		
		System.out.println("username+++++++++&&&&&"+username);
		System.out.println("password+++++++++&&&&&"+password);
		UserBean user = new UserBean();
		UserBean loginuser =  user.login(username,password);
		request.setAttribute("loginuser", loginuser);
		
		System.out.println("username+++++++++&&&&&"+loginuser.getUsername());
		int usercartid = user.logincartid(username,password);
		
		System.out.println("usercartid+++++++++"+usercartid);
		
		HttpSession session = request.getSession();
		session.setAttribute("usercartid", usercartid);
		
		int susercartid11 = (int) session.getAttribute("usercartid");
//		int usercartid11 = Integer.parseInt(susercartid11);
		System.out.println("susercartid11+++++++++*******"+susercartid11);
//		System.out.println("usercartid11+++++++++*******"+usercartid11);
		
		GoodBean good = new GoodBean();
		GoodKindBean kind = new GoodKindBean();
		List<GoodBean> allGood = good.listGood();
		List<GoodKindBean> allKind = kind.listGoodKind();

		request.setAttribute("allGood", allGood);
		request.setAttribute("allKind", allKind);
		System.out.println(loginuser.getUsername());
		System.out.println(username);
		String Uname = (String) loginuser.getUsername();
		
		if( Uname.equals(username)  ){
			System.out.println("true");
			request.getRequestDispatcher("/jsp/index.jsp").forward(request,response);	
		}else{
			System.out.println("false");
			response.sendRedirect("/shopping/jsp/login.jsp");
		}
        
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
}
