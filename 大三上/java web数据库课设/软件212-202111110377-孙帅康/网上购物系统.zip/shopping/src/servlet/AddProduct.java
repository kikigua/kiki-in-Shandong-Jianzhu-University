package servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.GoodBean;

/**
 * Servlet implementation class AddProdutc
 */
@WebServlet("/AddProduct")
public class AddProduct extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		GoodBean addGood = (GoodBean)request.getAttribute("addGood");
		GoodBean good = new GoodBean();
		boolean b = good.addGood(addGood);

		
		 PrintWriter out = response.getWriter();
		 out.print(b);
		request.setAttribute("b", b);

	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}

