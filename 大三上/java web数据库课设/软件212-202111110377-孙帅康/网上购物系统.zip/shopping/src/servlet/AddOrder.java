package servlet;

import java.io.IOException;
import java.io.PrintWriter;
//import java.util.Date;
//import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.orderBean;

@WebServlet("/AddOrder")
public class AddOrder extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		String addorder_id = (String)request.getParameter("addorder_id");
		String addorderstatus = (String)request.getParameter("orderstatus");
		String addvip_id = (String)request.getParameter("aaddvip_id");
		String addcountmoney = (String)request.getParameter("addcountmoney");
		orderBean addorder = new orderBean();
		addorder.setOrder_id(Integer.parseInt(addorder_id));
		addorder.setOrderstatus(addorderstatus);
		addorder.setVip_id(Integer.parseInt(addvip_id));
		addorder.setCountmoney(Float.parseFloat(addcountmoney));
		orderBean order = new orderBean();
//		boolean addorderflag = order.addOrder(addorder);
		PrintWriter out = response.getWriter();
        out.print(addorder);
//		 PrintWriter out = response.getWriter();
//		 out.print(allorder);
		int Order_id = Integer.parseInt("order_id");
		String Orderstatus_id = request.getParameter(request.getParameter("orderstatus_id"));
		int Vip_id = Integer.parseInt(request.getParameter("vip_id"));
		int Manager_id = Integer.parseInt(request.getParameter("manager_id"));
//		String ck_time = request.getParameter("Ck_time");
		String Username = request.getParameter("username");				
		String Orderstatus = request.getParameter("orderstatus");
		order.setOrder_id(Order_id);
		order.setOrderstatus_id(Orderstatus_id);
		order.setVip_id(Vip_id);
		order.setManager_id(Manager_id);
		order.setUsername(Username);
		order.setOrderstatus(Orderstatus);	
		//order.addorder(order);
		request.setAttribute("Order", order);
   	request.getRequestDispatcher("/ListOrders").forward(request, response);
	}


}
