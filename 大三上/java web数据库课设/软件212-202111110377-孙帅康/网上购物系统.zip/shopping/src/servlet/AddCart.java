package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.CartBean;

@WebServlet("/AddCart")
public class AddCart extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		int usercartid = (int) session.getAttribute("usercartid");
		
		
		System.out.print("susercartid%%%%%%%%"+usercartid);
//		System.out.print("usercartid%%%%%%%%"+usercartid);
		
		int commid = Integer.parseInt(request.getParameter("commid"));
		int nums = Integer.parseInt(request.getParameter("nums"));
		
		
		CartBean cartgood = new CartBean();
		cartgood.setCommodity_id(commid);
		cartgood.setCart_id(usercartid);
		cartgood.setGood_nums(nums);
		
		CartBean cart = new CartBean();
		cart.addCart(cartgood);

		request.getRequestDispatcher("/CartServlet").forward(request, response);
		
		
	}

}
