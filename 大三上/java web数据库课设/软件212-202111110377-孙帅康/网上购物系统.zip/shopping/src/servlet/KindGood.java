package servlet;

import java.io.IOException;
//import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.GoodBean;
//import util.GoodKindBean;

@WebServlet("/KindGood")
public class KindGood extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String kindId = (String)request.getParameter("goodkind");
		GoodBean good = new GoodBean();
		List<GoodBean> allGood = good.KindGood(kindId);
		String kindName = new String();
		String kindGoodId = new String();
		for(GoodBean good1 : allGood){
			kindName = good1.getFamily_name();
			kindGoodId = good1.getFamily_id();
		}
		
//		PrintWriter out = response.getWriter();
//		for(GoodBean good1 : allGood){
//			out.print(good1.getCommodity_name());
//			out.print("\n");
//			out.print(good1.getCommodity_price());
//			out.print("\n");
//			out.print(good1.getCommodity_pic());
//			out.print("\n");
//			out.print(good1.getCommodity_info());
//			out.print("\n");
//		}
		
//		PrintWriter out = response.getWriter();
//		out.print(allGood);
//		out.print(kindId);
		request.setAttribute("allGood", allGood);
		request.setAttribute("kindName", kindName);
		request.setAttribute("kindGoodId", kindGoodId);
		request.getRequestDispatcher("/jsp/listGoods.jsp").forward(request,response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
}
