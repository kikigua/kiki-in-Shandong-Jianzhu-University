package servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
//import javax.servlet.http.HttpSession;

import bean.CartBean;

@WebServlet("/CartServlet")
public class CartServlet extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String cartGID = (String)request.getParameter("cartGID");
		String commID = (String)request.getParameter("commID");
		CartBean commcart = new CartBean();
		List<CartBean> cart = commcart.listMycart(); 
		boolean deletecart = commcart.deleteCart(cartGID,commID);
		Float totalsum = commcart.sum();
		request.setAttribute("totalsum", totalsum);
		request.setAttribute("deletecart", deletecart);
		request.setAttribute("cart", cart);
		request.getRequestDispatcher("/jsp/myCart.jsp").forward(request,response);
	
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
}
