package servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.CartBean;

/**
 * Servlet implementation class ClearCartServlet
 */
@WebServlet("/ClearCartServlet")
public class ClearCartServlet extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		��ȡ���ﳵ	
		CartBean commcart = new CartBean();
			List<CartBean> cart = commcart.listMycart(); 
			request.setAttribute("cart", cart);

			// ���ù��ﳵ�ϵ���չ��ﳵ����
			cart.clear();
			// ���¶���/jsp/cart.jsp
			request.getRequestDispatcher("/jsp/myCart.jsp").forward(request,response);
			return;
		
	}

}
