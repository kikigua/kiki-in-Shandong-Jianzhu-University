package servlet;

import java.io.IOException;
//import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.GoodBean;
import bean.GoodKindBean;
import bean.ManagerBean;

@WebServlet("/ListGoodsM")
public class ListGoodsM extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String deleteId = request.getParameter("deleteId");
		String editgoodid = request.getParameter("editgoodid");
		
		HttpSession session = request.getSession();
		session.setAttribute("editgoodid", editgoodid);
		
		GoodBean good = new GoodBean();
		GoodKindBean kind = new GoodKindBean();
		
		List<GoodBean> allGood = good.listGood();
		List<GoodKindBean> allKind = kind.listGoodKind();
		List<GoodBean> allGoodM = good.listGoodM();
		
		boolean deleteflag = good.deleteGood(deleteId);
		GoodBean editgood = good.listOneGoodM(editgoodid);
		
		
			System.out.println("Name$$$$$$$$$"+editgood.getCommodity_name());
			System.out.println();
			System.out.println("Price$$$$$$$$$"+editgood.getCommodity_price());
			System.out.println();
			System.out.println("Num$$$$$$$$$"+editgood.getCommodity_num());
			System.out.println();
			System.out.println("Info$$$$$$$$$"+editgood.getCommodity_info());
			System.out.println();
		
		
		ManagerBean manager = new ManagerBean();
		List<ManagerBean> managerlist = manager.listManager();
		
		request.setAttribute("allGood", allGood);
		request.setAttribute("allKind", allKind);
		request.setAttribute("allGoodM", allGoodM);
		request.setAttribute("deleteflag", deleteflag);
		request.setAttribute("managerlist", managerlist);
		request.setAttribute("editgood", editgood);

//		System.out.println("deleteflag"+deleteflag);
		System.out.println("editgoodid??"+editgoodid);
		System.out.println("editgood??"+editgood);
		
		request.getRequestDispatcher("/jsp/listGoodsM.jsp").forward(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
}
