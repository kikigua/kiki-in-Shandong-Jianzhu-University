package servlet;

import java.io.IOException;
//import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//import util.GoodBean;
import bean.orderBean;

/**
 * Servlet implementation class SearchOrder
 */
@WebServlet("/SearchOrder")
public class SearchOrder extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String key = request.getParameter("searchKey");
		orderBean order = new orderBean();
		List<orderBean> searchOrder = order.searchOrder(key);

//		PrintWriter out = response.getWriter();
//		for(GoodBean good1 : all){
//			out.print(good1.getCommodity_name());
//			out.print("\n");
//			out.print(good1.getCommodity_price());
//			out.print("\n");
//			out.print(good1.getCommodity_pic());
//			out.print("\n");
//			out.print(good1.getCommodity_info());
//			out.print("\n");
//		}
		
//		PrintWriter out = response.getWriter();
//	    out.print(key);
//		out.print(searchOrder);
		request.setAttribute("searchOrder", searchOrder);
	request.getRequestDispatcher("/jsp/searchOrderList.jsp").forward(request,response);
	}

}
