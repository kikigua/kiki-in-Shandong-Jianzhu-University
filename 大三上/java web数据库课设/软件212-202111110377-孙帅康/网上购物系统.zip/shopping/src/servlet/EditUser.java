package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


import bean.UserBean;

/**
 * Servlet implementation class EditUser
 */
@WebServlet("/EditUser")
public class EditUser extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String editusername = request.getParameter("editusername");
		String edittel = request.getParameter("edittel");
		String editrealname = request.getParameter("editrealname");
		String editaddress = request.getParameter("editaddress");
		String editpassword = request.getParameter("eeditpassword");
		String editmoney = request.getParameter("money");		
		System.out.println("editusername*******"+editusername);
		System.out.println("edittel*******"+edittel);
		System.out.println("editrealname*******"+editrealname);
		System.out.println("editaddress*******"+editaddress);
		System.out.println("editpassword*******"+editpassword);
		System.out.println("editmoney*******"+editmoney);		
		HttpSession session = request.getSession();
		String Sedituserid = (String)session.getAttribute("edituserid");
		int edituserid = Integer.parseInt(Sedituserid);		
		UserBean edituser = new UserBean();
		edituser.setUsername(editusername);
		edituser.setRealname(editrealname);
		edituser.setAddress(editaddress);
		edituser.setTel(edittel);
		edituser.setMoney(Float.parseFloat(editmoney));
		edituser.setPassword(editpassword);	
		System.out.println("editusername###################"+edituser.getUsername());
		System.out.println("editrealname###################"+edituser.getRealname());
		System.out.println("editaddress###################"+edituser.getAddress());
		System.out.println("edittel###################"+edituser.getTel());
		System.out.println("editmoney###################"+edituser.getMoney());
		System.out.println("editpassword###################"+edituser.getPassword());	
		UserBean user = new UserBean();
		boolean edituserflag = user.editUser(edituser, edituserid);	
		System.out.println("edituser--"+edituser);
		System.out.println("edituserid--"+edituserid);
		System.out.println("edituserflag--"+edituserflag);		
		request.getRequestDispatcher("/ListUsers").forward(request, response);				
	}
}
