package servlet;

import java.io.IOException;
//import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//import util.Shopping_cartBean;
import bean.UserBean;

/**
 * Servlet implementation class AddUser
 */

@WebServlet("/AddUser")
public class AddUser extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String adduserid = (String)request.getParameter("adduserid");
		String addusername = (String)request.getParameter("addusername");
		String addrealname = (String)request.getParameter("addrealname");
		String addaddress = (String)request.getParameter("addaddress");
		String addtel = (String)request.getParameter("addtel");
		String cart_id = (String)request.getParameter("cart_id");
		String addpassword = (String)request.getParameter("addpassword");
		String addmoney = (String)request.getParameter("addmoney");
		
		UserBean adduser = new UserBean();
		adduser.setUserid(Integer.parseInt(adduserid));
		adduser.setUsername(addusername);
		adduser.setRealname(addrealname);
		adduser.setAddress(addaddress);
		adduser.setTel(addtel);
		adduser.setPassword(addpassword);
		adduser.setMoney(Float.parseFloat(addmoney));
		adduser.setCart_id(Integer.parseInt(cart_id));				
//		UserBean user = new UserBean();
		

		
		request.getRequestDispatcher("/ListUsers").forward(request, response);
	}

}
