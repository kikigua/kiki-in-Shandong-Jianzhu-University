package servlet;

import java.io.IOException;
//import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//import util.GoodBean;
//import util.ProductBean;
import bean.UserBean;

/**
 * Servlet implementation class UserInfo
 */
@WebServlet("/InfoUser")
public class InfoUser extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int id = Integer.parseInt(request.getParameter("userid"));
		UserBean user = new UserBean();
		UserBean userInfo = user.listUserById(id);
		request.setAttribute("userInfo", userInfo);
		request.getRequestDispatcher("/jsp/UserInfo.jsp").forward(request, response);
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
	public static void main(String[] args) {
		
	}
}


