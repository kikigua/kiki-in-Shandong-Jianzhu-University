package bean;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import util.DBConnection;

public class UserBean {

	private int userid;
	private String username;
	private String realname;
	private String address;
	private String password;
	private String tel;
	private int cart_id;
	private int vgrade;

	public int getVgrade() {
		return vgrade;
	}

	private float money;
	private float count;
	private int id;

	// vip
	public int getUserid() {
		return userid;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public float getCount() {
		return count;
	}

	public void setUserid(int userid) {
		this.userid = userid;
	}
	// cart_id

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	// commodity_id
	public String getRealname() {
		return realname;
	}

	public void setRealname(String realname) {
		this.realname = realname;
	}

	// address
	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	// tel
	public String getTel() {
		return tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}

	// cart_id
	public int getCart_id() {
		return cart_id;
	}

	public void setCart_id(int cart_id) {
		this.cart_id = cart_id;
	}

	// password
	public String getPassword() {
		return password;
	}

	private void setVgrade(int int1) {
		// TODO Auto-generated method stub

	}

	private void setCount(float float1) {
		// TODO Auto-generated method stub

	}

	public void setPassword(String password) {
		this.password = password;
	}

	// money
	public float getMoney() {
		return money;
	}

	public void setMoney(float money) {
		this.money = money;
	}

	// �����û�
	// public List<UserBean> listUser() {
	// Connection conn = null;
	// PreparedStatement ps = null;
	// ResultSet rs = null;
	// List<UserBean> alluser = new ArrayList<UserBean>();
	// try {
	// conn = DBConnection.getConnection();
	// String sql = "select * from user";
	// ps = conn.prepareStatement(sql);
	// rs = ps.executeQuery();
	// while (rs.next()) {
	// UserBean user = new UserBean();
	// user.setUserid(rs.getInt("userid"));
	// user.setUsername(rs.getString("username"));
	// user.setRealname(rs.getString("realname"));
	// user.setAddress(rs.getString("address"));
	// user.setTel(rs.getString("tel"));
	// user.setCart_id(rs.getInt("cart_id"));
	// user.setPassword(rs.getString("password"));
	// user.setMoney(rs.getFloat("money"));
	// alluser.add(user);
	// }
	// } catch (SQLException e) {
	// e.printStackTrace();
	// } finally {
	// DBConnection.close(rs, ps, conn);
	// }
	// return alluser;
	// }

	// ������Ա
	public List<UserBean> searchUserVip(String key) {
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		List<UserBean> all = new ArrayList<UserBean>();
		try {
			conn = DBConnection.getConnection();
			String sql = "SELECT * FROM	`user`,	`vip` WHERE	`vip`.userid = `user`.userid AND `username` LIKE \"%\"?\"%\" OR `address` LIKE \"%\"?\"%\" OR `tel` LIKE \"%\"?\"%\";";
			ps = conn.prepareStatement(sql);
			ps.setString(1, key);
			ps.setString(2, key);
			ps.setString(3, key);
			rs = ps.executeQuery();
			while (rs.next()) {
				UserBean user = new UserBean();
				user.setUserid(rs.getInt("userid"));
				user.setUsername(rs.getString("username"));
				user.setRealname(rs.getString("realname"));
				user.setAddress(rs.getString("address"));
				user.setTel(rs.getString("tel"));
				user.setCart_id(rs.getInt("cart_id"));
				user.setCount(rs.getFloat("count"));
				user.setMoney(rs.getFloat("money"));
				user.setVgrade(rs.getInt("vgrade"));
				all.add(user);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConnection.close(rs, ps, conn);
		}
		return all;
	}

	// ��¼
	public UserBean login(String username, String password) {
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		UserBean loginuser = new UserBean();
		try {
			conn = DBConnection.getConnection();
			String sql = "select * from user where username = ? and password = ?";
			ps = conn.prepareStatement(sql);
			ps.setString(1, username);
			ps.setString(2, password);
			rs = ps.executeQuery();
			if (rs.next()) {
				loginuser.setUserid(rs.getInt("userid"));
				loginuser.setUsername(rs.getString("username"));
				loginuser.setRealname(rs.getString("realname"));
				loginuser.setAddress(rs.getString("address"));
				loginuser.setTel(rs.getString("tel"));
				loginuser.setCart_id(rs.getInt("cart_id"));
				System.out.println("rs.getInt(cart_id)999999999999" + rs.getInt("cart_id"));
				loginuser.setMoney(rs.getFloat("money"));
				
				System.out.println("rs.getString(username)----%%%" + rs.getString("username"));
			}
			System.out.println("loginuser.getUsername()----" + loginuser.getUsername());
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConnection.close(rs, ps, conn);
		}
		return loginuser;
	}

	// ��ȡ��¼�û��Ĺ��ﳵID
	public int logincartid(String username, String password) {
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		int logincartid = 0;
		try {
			conn = DBConnection.getConnection();
			String sql = "select * from user where username=? and password=?";
			ps = conn.prepareStatement(sql);
			ps.setString(1, username);
			ps.setString(2, password);
			rs = ps.executeQuery();
			if (rs.next()) {
				logincartid = rs.getInt("cart_id");
				System.out.println("rs.getInt(cart_id)@@@@@@@@@" + rs.getInt("cart_id"));
				System.out.println("logincartid@@@@@@@@@***" + logincartid);
				return logincartid;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConnection.close(rs, ps, conn);
		}
		return logincartid;
	}

	public int addcart() {
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			conn = DBConnection.getConnection();
			String sql = "insert into shopping_cart values()";
			ps = conn.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);
			ps.executeUpdate();
			rs = ps.getGeneratedKeys();
			if (rs != null && rs.next()) {
				int id = rs.getInt(1);
				return id;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConnection.close(rs, ps, conn);
		}
		return -1;
	}

	// ����ע��ɹ��ļ�¼��id
	public int register(UserBean registerUser) {
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			conn = DBConnection.getConnection();
			String sql = "insert into user(username,password,realname,address,tel,cart_id) values(?,?,?,?,?,?)";
			ps = conn.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);
			ps.setString(1, registerUser.getUsername());
			ps.setString(2, registerUser.getPassword());
			ps.setString(3, registerUser.getRealname());
			ps.setString(4, registerUser.getAddress());
			ps.setString(5, registerUser.getTel());
			ps.setInt(6, registerUser.getCart_id());
			ps.executeUpdate();
			rs = ps.getGeneratedKeys();
			if (rs != null && rs.next()) {
				int id = rs.getInt(1);
				return id;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConnection.close(rs, ps, conn);
		}
		return -1;
	}

	public List<UserBean> listUser() {
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		List<UserBean> allMyUser = new ArrayList<UserBean>();
		try {
			conn = DBConnection.getConnection();
			String sql = "select * from user order by userid desc";
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			while (rs.next()) {

				UserBean user = new UserBean();
				user.setUserid(rs.getInt("userid"));
				user.setUsername(rs.getString("username"));
				user.setRealname(rs.getString("realname"));
				user.setAddress(rs.getString("address"));
				user.setTel(rs.getString("tel"));
				user.setCart_id(rs.getInt("cart_id"));
				user.setPassword(rs.getString("password"));
				user.setMoney(rs.getFloat("money"));

				allMyUser.add(user);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConnection.close(rs, ps, conn);
		}
		return allMyUser;
	}
	
	public List<UserBean> listUserVip() {
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		List<UserBean> allMyUser = new ArrayList<UserBean>();
		try {
			conn = DBConnection.getConnection();
			String sql = "SELECT * FROM	`user` , `vip` WHERE `vip`.userid = `user`.userid;";
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			while (rs.next()) {

				UserBean user = new UserBean();
				user.setUserid(rs.getInt("user.userid"));
				user.setUsername(rs.getString("username"));
				user.setRealname(rs.getString("realname"));
				user.setAddress(rs.getString("address"));
				user.setTel(rs.getString("tel"));
				user.setCart_id(rs.getInt("cart_id"));
				user.setPassword(rs.getString("password"));
				user.setMoney(rs.getFloat("money"));
				user.setCart_id(rs.getInt("vip_id"));
				user.setVgrade(rs.getInt("vgrade"));

				allMyUser.add(user);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConnection.close(rs, ps, conn);
		}
		return allMyUser;
	}

	public UserBean listUserById(int id) {
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		UserBean user = new UserBean();
		try {
			conn = DBConnection.getConnection();
			String sql = "select * from user where userid = ?";
			ps = conn.prepareStatement(sql);
			ps.setInt(1, id);
			rs = ps.executeQuery();
			if (rs.next()) {
				user.setUserid(rs.getInt("userid"));
				user.setUsername(rs.getString("username"));
				user.setRealname(rs.getString("realname"));
				user.setAddress(rs.getString("address"));
				user.setTel(rs.getString("tel"));
				user.setCart_id(rs.getInt("cart_id"));
				user.setPassword(rs.getString("password"));
				user.setMoney(rs.getFloat("money"));

			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConnection.close(rs, ps, conn);
		}
		return user;
	}

	// search
	public List<UserBean> searchUser(String key) {
		Connection conn = null;
		// CallableStatement cs = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		List<UserBean> all = new ArrayList<UserBean>();
		try {
			conn = DBConnection.getConnection();
			String sql = "SELECT * FROM	`user` WHERE `username` LIKE \"%\"?\"%\" OR `address` LIKE \"%\"?\"%\" OR `tel` LIKE \"%\"?\"%\";";
			ps = conn.prepareStatement(sql);
			ps.setString(1, key);
			ps.setString(2, key);
			ps.setString(3, key);

			rs = ps.executeQuery();
			while (rs.next()) {
				UserBean user = new UserBean();
				user.setUserid(rs.getInt("userid"));
				user.setUsername(rs.getString("username"));
				user.setRealname(rs.getString("realname"));
				user.setAddress(rs.getString("address"));
				user.setTel(rs.getString("tel"));
				user.setCart_id(rs.getInt("cart_id"));
				user.setPassword(rs.getString("password"));
				user.setMoney(rs.getFloat("money"));

				all.add(user);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConnection.close(rs, ps, conn);
		}
		return all;
	}

	// addUser
	public boolean addUser(UserBean user) {
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		boolean b = false;
		int lines = 0;
		try {
			conn = DBConnection.getConnection();
			String sql = "insert into user(userid,username,realname,address,tel,cart_id,password,money) values(?,?,?,?,?,?,?,?)";
			ps = conn.prepareStatement(sql);
			ps.setInt(1, user.getUserid());
			ps.setString(2, user.getUsername());
			ps.setString(3, user.getRealname());
			ps.setString(4, user.getAddress());
			ps.setString(5, user.getTel());
			ps.setInt(6, user.getCart_id());
			ps.setString(7, user.getPassword());
			ps.setFloat(8, user.getMoney());
			lines = ps.executeUpdate();
			System.out.println(lines);
			if (lines > 0) {
				b = true;
				return b;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConnection.close(rs, ps, conn);
		}
		return b;
	}
	public void addUser1()throws Exception{
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			conn = DBConnection.getConnection();
			String sql = "insert into user(userid,username,realname,address,tel,password,money)"
					   + " values(?,?,?,?,?,?,?)";
			ps = conn.prepareStatement(sql);
			ps.setInt(1, this.getUserid());
			ps.setString(2, this.getUsername());
			ps.setString(3, this.getRealname());
			ps.setString(4, this.getAddress());
			ps.setString(5, this.getTel());
			ps.setString(6, this.getPassword());
			ps.setFloat(7, this.getMoney());
			ps.executeUpdate();
		} catch(Exception e){
			throw e;
		}finally {
			DBConnection.close(rs, ps, conn);
		}
	}

	// deleteUser
	public boolean deleteUser(String deleteId) {
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		boolean b = false;
		int lines = 0;
		try {
			conn = DBConnection.getConnection();
			String sql = "delete from user where userid = ?";
			ps = conn.prepareStatement(sql);
			ps.setString(1, deleteId);
			lines = ps.executeUpdate();
			System.out.println(lines);
			if (lines > 0) {
				b = true;
				return b;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConnection.close(rs, ps, conn);
		}
		return b;
	}
	public boolean editUser(UserBean edituser, int editid) {
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		boolean b = false;
		int lines = 0;
		try {
			conn = DBConnection.getConnection();
			String sql = "update user set username = ? , userrealname = ? ,cart_id = ? , address = ? ,tel = ? password= ? , money = ? where userid = ?";
			ps = conn.prepareStatement(sql);
			ps.setString(1, edituser.getUsername());
			ps.setString(2, edituser.getRealname());
			ps.setString(3, edituser.getAddress());
			ps.setString(4, edituser.getPassword());
			ps.setString(5, edituser.getTel());
			ps.setInt(6, edituser.getCart_id());
			ps.setFloat(7, edituser.getMoney());
			
			ps.setInt(5, editid);
			lines = ps.executeUpdate();
			System.out.println("lines");
			if (lines > 0) {
				b = true;
				return b;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConnection.close(rs, ps, conn);
		}
		return b;
	}

}