package bean;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


import util.DBConnection;

public class GoodBean {
	private int commodity_id;
	private String commodity_name;
	private String commodity_pic;
	private int commodity_num;
	private float commodity_price;
	private int commodity_sale;
	private String commodity_info;
	private int manager_id;
	private String family_name;
	private String family_id;

	public int getCommodity_id() {
		return commodity_id;
	}

	public void setCommodity_id(int commodity_id) {
		this.commodity_id = commodity_id;
	}

	public String getCommodity_name() {
		return commodity_name;
	}

	public void setCommodity_name(String commodity_name) {
		this.commodity_name = commodity_name;
	}

	public String getCommodity_pic() {
		return commodity_pic;
	}

	public void setCommodity_pic(String commodity_pic) {
		this.commodity_pic = commodity_pic;
	}

	public int getCommodity_num() {
		return commodity_num;
	}

	public void setCommodity_num(int commodity_num) {
		this.commodity_num = commodity_num;
	}

	public float getCommodity_price() {
		return commodity_price;
	}

	public void setCommodity_price(float commodity_price) {
		this.commodity_price = commodity_price;
	}

	public int getCommodity_sale() {
		return commodity_sale;
	}

	public void setCommodity_sale(int commodity_sale) {
		this.commodity_sale = commodity_sale;
	}

	public String getCommodity_info() {
		return commodity_info;
	}

	public void setCommodity_info(String commodity_info) {
		this.commodity_info = commodity_info;
	}

	public int getManager_id() {
		return manager_id;
	}

	public void setManager_id(int manager_id) {
		this.manager_id = manager_id;
	}

	public String getFamily_name() {
		return family_name;
	}

	public void setFamily_name(String family_name) {
		this.family_name = family_name;
	}

	public String getFamily_id() {
		return family_id;
	}

	public void setFamily_id(String family_id) {
		this.family_id = family_id;
	}

	// ��ʾ���е���Ʒ��Ϣ
	public List<GoodBean> listGood() {
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		List<GoodBean> all = new ArrayList<GoodBean>();
		try {
			conn = DBConnection.getConnection();
			String sql = "select * from commodity";
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			while (rs.next()) {
				GoodBean good = new GoodBean();
				good.setCommodity_id(rs.getInt("commodity_id"));
				good.setCommodity_name(rs.getString("commodity_name"));
				good.setCommodity_pic(rs.getString("commodity_pic"));
				good.setCommodity_num(rs.getInt("commodity_num"));
				good.setCommodity_price(rs.getFloat("commodity_price"));
				good.setCommodity_sale(rs.getInt("commodity_sale"));
				good.setCommodity_info(rs.getString("commodity_info"));
				good.setManager_id(rs.getInt("manager_id"));
				all.add(good);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConnection.close(rs, ps, conn);
		}
		return all;
	}

	// ������Ʒ���ơ����Ȳ鿴��Ʒ��Ϣ��ģ����ѯ��
	public List<GoodBean> searchGood(String key) {
		Connection conn = null;
		// CallableStatement cs = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		List<GoodBean> all = new ArrayList<GoodBean>();
		try {
			conn = DBConnection.getConnection();
			String sql = "select * from commodity LEFT OUTER JOIN classify ON(commodity.commodity_id=classify.commodity_id) LEFT OUTER JOIN commodity_family ON(classify.family_id = commodity_family.family_id) where (commodity_family.family_name like \"%\"?\"%\" OR commodity.commodity_name like \"%\"?\"%\") order by commodity_sale desc,commodity_price asc";
			ps = conn.prepareStatement(sql);
			ps.setString(1, key);
			ps.setString(2, key);
			rs = ps.executeQuery();
			while (rs.next()) {
				GoodBean good = new GoodBean();
				good.setCommodity_id(rs.getInt("commodity.commodity_id"));
				good.setCommodity_name(rs.getString("commodity_name"));
				good.setCommodity_pic(rs.getString("commodity_pic"));
				good.setCommodity_num(rs.getInt("commodity_num"));
				good.setCommodity_price(rs.getFloat("commodity_price"));
				good.setCommodity_sale(rs.getInt("commodity_sale"));
				good.setCommodity_info(rs.getString("commodity_info"));
				good.setManager_id(rs.getInt("manager_id"));
				good.setFamily_name(rs.getString("family_name"));
				all.add(good);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConnection.close(rs, ps, conn);
		}
		return all;
	}

	// ��ʾĳ����Ʒ����ϸ��Ϣ
	public GoodBean listGoodById(int id) {
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		GoodBean good = new GoodBean();
		try {
			conn = DBConnection.getConnection();
			String sql = "select * from commodity where commodity_id = ?";
			ps = conn.prepareStatement(sql);
			ps.setInt(1, id);
			rs = ps.executeQuery();
			if (rs.next()) {
				good.setCommodity_id(rs.getInt("commodity_id"));
				good.setCommodity_name(rs.getString("commodity_name"));
				good.setCommodity_pic(rs.getString("commodity_pic"));
				good.setCommodity_num(rs.getInt("commodity_num"));
				good.setCommodity_price(rs.getFloat("commodity_price"));
				good.setCommodity_sale(rs.getInt("commodity_sale"));
				good.setCommodity_info(rs.getString("commodity_info"));
				good.setManager_id(rs.getInt("manager_id"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConnection.close(rs, ps, conn);
		}
		return good;
	}

	// ��ʾĳһ�����Ʒ
	public List<GoodBean> KindGood(String kindId) {
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		List<GoodBean> all = new ArrayList<GoodBean>();
		try {
			conn = DBConnection.getConnection();
			String sql = new String();
			if (kindId == "") {
				sql = "select * from commodity LEFT OUTER JOIN classify ON(commodity.commodity_id=classify.commodity_id) LEFT OUTER JOIN commodity_family ON(classify.family_id = commodity_family.family_id) order by commodity_sale desc,commodity_price asc";
				ps = conn.prepareStatement(sql);
			} else {
				sql = "select * from commodity LEFT OUTER JOIN classify ON(commodity.commodity_id=classify.commodity_id) LEFT OUTER JOIN commodity_family ON(classify.family_id = commodity_family.family_id) where commodity_family.family_id = ? order by commodity_sale desc,commodity_price asc";
				ps = conn.prepareStatement(sql);
				ps.setString(1, kindId);
			}
			// System.out.println(sql);
			rs = ps.executeQuery();
			while (rs.next()) {
				GoodBean good = new GoodBean();
				good.setCommodity_id(rs.getInt("commodity.commodity_id"));
				good.setCommodity_name(rs.getString("commodity_name"));
				good.setCommodity_pic(rs.getString("commodity_pic"));
				good.setCommodity_num(rs.getInt("commodity_num"));
				good.setCommodity_price(rs.getFloat("commodity_price"));
				good.setCommodity_sale(rs.getInt("commodity_sale"));
				good.setCommodity_info(rs.getString("commodity_info"));
				good.setManager_id(rs.getInt("manager_id"));
				good.setFamily_name(rs.getString("family_name"));
				good.setFamily_id(rs.getString("family_id"));
				all.add(good);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConnection.close(rs, ps, conn);
		}
		return all;
	}

	// ��ʾ���Nǰʮ����Ʒ----ʵ����ͼ
	public List<GoodBean> hotGood() {
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		List<GoodBean> all = new ArrayList<GoodBean>();
		try {
			conn = DBConnection.getConnection();
			String sql = "select * from commodity order by commodity_sale desc limit 10";
			// System.out.println(sql);
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			while (rs.next()) {
				GoodBean good = new GoodBean();
				good.setCommodity_id(rs.getInt("commodity.commodity_id"));
				good.setCommodity_name(rs.getString("commodity_name"));
				good.setCommodity_pic(rs.getString("commodity_pic"));
				good.setCommodity_num(rs.getInt("commodity_num"));
				good.setCommodity_price(rs.getFloat("commodity_price"));
				good.setCommodity_sale(rs.getInt("commodity_sale"));
				good.setCommodity_info(rs.getString("commodity_info"));
				good.setManager_id(rs.getInt("manager_id"));
				all.add(good);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConnection.close(rs, ps, conn);
		}
		return all;
	}

	// ��ʾ��Ʒ��Ϣ����
	public List<GoodBean> listGoodM() {
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		List<GoodBean> all = new ArrayList<GoodBean>();
		try {
			conn = DBConnection.getConnection();
			String sql = new String();
			sql = "select * from commodity LEFT OUTER JOIN classify ON(commodity.commodity_id=classify.commodity_id) LEFT OUTER JOIN commodity_family ON(classify.family_id = commodity_family.family_id) order by commodity_sale desc,commodity_price asc";
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			while (rs.next()) {
				GoodBean good = new GoodBean();
				good.setCommodity_id(rs.getInt("commodity.commodity_id"));
				good.setCommodity_name(rs.getString("commodity_name"));
				good.setCommodity_pic(rs.getString("commodity_pic"));
				good.setCommodity_num(rs.getInt("commodity_num"));
				good.setCommodity_price(rs.getFloat("commodity_price"));
				good.setCommodity_sale(rs.getInt("commodity_sale"));
				good.setCommodity_info(rs.getString("commodity_info"));
				good.setManager_id(rs.getInt("manager_id"));
				good.setFamily_name(rs.getString("family_name"));
				good.setFamily_id(rs.getString("family_id"));
				all.add(good);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConnection.close(rs, ps, conn);
		}
		return all;
	}

	// ��ʾ��Ʒ��Ϣ������һ����¼
	public GoodBean listOneGoodM(String id) {
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		GoodBean good = new GoodBean();
		try {
			conn = DBConnection.getConnection();
			String sql = new String();
			sql = "select * from commodity LEFT OUTER JOIN classify ON(commodity.commodity_id=classify.commodity_id) LEFT OUTER JOIN commodity_family ON(classify.family_id = commodity_family.family_id) where commodity.commodity_id = ?";
			ps = conn.prepareStatement(sql);
			ps.setString(1, id);
			rs = ps.executeQuery();
			if (rs.next()) {
				good.setCommodity_id(rs.getInt("commodity.commodity_id"));
				good.setCommodity_name(rs.getString("commodity_name"));
				good.setCommodity_pic(rs.getString("commodity_pic"));
				good.setCommodity_num(rs.getInt("commodity_num"));
				good.setCommodity_price(rs.getFloat("commodity_price"));
				good.setCommodity_sale(rs.getInt("commodity_sale"));
				good.setCommodity_info(rs.getString("commodity_info"));
				good.setManager_id(rs.getInt("manager_id"));
				good.setFamily_name(rs.getString("family_name"));
				good.setFamily_id(rs.getString("family_id"));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConnection.close(rs, ps, conn);
		}
		return good;
	}

	// ����һ����Ʒ��Ϣ
	public boolean addGood(GoodBean good) {
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		boolean b = false;
		int lines = 0;
		try {
			conn = DBConnection.getConnection();
			String sql = "insert into commodity(commodity_name,commodity_num,commodity_price,commodity_info,manager_id) values(?,?,?,?,?)";
			ps = conn.prepareStatement(sql);
			ps.setString(1, good.getCommodity_name());
			ps.setInt(2, good.getCommodity_num());
			ps.setFloat(3, good.getCommodity_price());
			ps.setString(4, good.getCommodity_info());
			ps.setInt(5, good.getManager_id());
			lines = ps.executeUpdate();
			if (lines > 0) {
				b = true;
				return b;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConnection.close(rs, ps, conn);
		}
		return b;
	}

	public void addGood1()throws Exception{
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			conn = DBConnection.getConnection();
			String sql = "insert into commodity(commodity_name,commodity_num,commodity_price,commodity_info)"
					   + " values(?,?,?,?)";
			ps = conn.prepareStatement(sql);
			ps.setString(1, this.getCommodity_name());
			ps.setInt(2, this.getCommodity_num());
			ps.setFloat(3, this.getCommodity_price());
			ps.setString(4, this.getCommodity_info());
			ps.executeUpdate();
		} catch(Exception e){
			throw e;
		}finally {
			DBConnection.close(rs, ps, conn);
		}
	}

	// ɾ��һ����Ʒ��Ϣ
	public boolean deleteGood(String deleteId) {
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		boolean b = false;
		int lines = 0;
		try {
			conn = DBConnection.getConnection();
			String sql = "delete from commodity where commodity_id = ?";
			ps = conn.prepareStatement(sql);
			ps.setString(1, deleteId);
			lines = ps.executeUpdate();
			if (lines > 0) {
				b = true;
				return b;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConnection.close(rs, ps, conn);
		}
		return b;
	}

	// ����һ����Ʒ��Ϣ
	public boolean editGood(GoodBean editgood, int editid) {
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		boolean b = false;
		int lines = 0;
		try {
			conn = DBConnection.getConnection();
			String sql = "update commodity set commodity_name = ? , commodity_price = ? , commodity_num = ? , commodity_info = ? where commodity_id = ?";
			ps = conn.prepareStatement(sql);
			ps.setString(1, editgood.getCommodity_name());
			ps.setFloat(2, editgood.getCommodity_price());
			ps.setInt(3, editgood.getCommodity_num());
			ps.setString(4, editgood.getCommodity_info());
			ps.setInt(5, editid);
			lines = ps.executeUpdate();
			System.out.println("���£�"+lines);
			if (lines > 0) {
				b = true;
				return b;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConnection.close(rs, ps, conn);
		}
		return b;
	}
}