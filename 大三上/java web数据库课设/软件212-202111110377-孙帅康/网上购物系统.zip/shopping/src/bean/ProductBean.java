package bean;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import util.DBConnection;

public class ProductBean {

	private int vip_id;
	private int cart_id;
	private int commodity_id;
	private String grade;
	private String  text;
	private int manager_id;
	private int flag;
	
//vip
	public int getVip_id()
	{
		return vip_id;
	}

	public void setVip_id(int vip_id)
	{
		this.vip_id = vip_id;
	}
	//cart_id

	public int getCart_id()
	{
		return cart_id;
	}

	public void setCart_id(int cart_id)
	{
		this.cart_id = cart_id;
	}
//commodity_id
	public float getCommodity_id()
	{
		return commodity_id;
	}

	public void setCommodity_id(int commodity_id)
	{
		this.commodity_id = commodity_id;
	}
//grade
	public String getGrade()
	{
		return grade;
	}

	public void setGrade(String grade)
	{
		this.grade = grade;
	}
	//text
	public String getText()
	{
		return text;
	}

	public void setText(String text)
	{
		this.text = text;
	}
	//manager_id
	public int getManager_id()
	{
		return manager_id;
	}

	public void setManager_id(int manager_id)
	{
		this.manager_id = manager_id;
	}
	//flag
	public int getFlag()
	{
		return flag;
	}

	public void setFlag(int flag)
	{
		this.flag = flag;
	}
		
		
			
				
				
				
				
			
			

	// 鏄剧ず鎵�鏈夌殑鍟嗗搧淇℃伅
	public List<ProductBean> listProduct() {
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		List<ProductBean> all = new ArrayList<ProductBean>();
		try {
			conn = DBConnection.getConnection();
			String sql = "select * from product";
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			while (rs.next()) {
				
				ProductBean product = new ProductBean();
				product.setVip_id(rs.getInt("vip_id"));
				product.setCart_id(rs.getInt("cart_id"));
				product.setCommodity_id(rs.getInt("commodity_id"));
				product.setGrade(rs.getString("grade"));
				product.setText(rs.getString("text"));
				product.setManager_id(rs.getInt("manager_id"));
				product.setFlag(rs.getInt("flag"));
				all.add(product);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConnection.close(rs, ps, conn);
		}
		return all;
	}
	public List<ProductBean> listProductPass() {
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		List<ProductBean> all = new ArrayList<ProductBean>();
		try {
			conn = DBConnection.getConnection();
			String sql = "select * from product where flag=0";
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			while (rs.next()) {
				
				ProductBean product = new ProductBean();
				product.setVip_id(rs.getInt("vip_id"));
				product.setCart_id(rs.getInt("cart_id"));
				product.setCommodity_id(rs.getInt("commodity_id"));
				product.setGrade(rs.getString("grade"));
				product.setText(rs.getString("text"));
				product.setManager_id(rs.getInt("manager_id"));
				product.setFlag(rs.getInt("flag"));
				all.add(product);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConnection.close(rs, ps, conn);
		}
		return all;
	}



}
