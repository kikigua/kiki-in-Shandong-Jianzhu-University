package bean;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import util.DBConnection;

public class Shopping_cartBean {
	private int cart_id;
	private int capacity;
	//
	//cart_id
		public int getCart_id()
		{
			return cart_id;
		}

		public void setCart_id(int cart_id)
		{
			this.cart_id = cart_id;
		}
		//capacity
	public int getCapacity() {
		return capacity;
	}

	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}

	
	public List<Shopping_cartBean> listShopping_cart(){
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		List<Shopping_cartBean> all = new ArrayList<Shopping_cartBean>();
		try {
			conn = DBConnection.getConnection();
			String sql = "select * from shopping_cart";
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			while (rs.next()) {
				Shopping_cartBean shopping_cart = new Shopping_cartBean();
				shopping_cart.setCart_id(rs.getInt("cart_id"));
			
				shopping_cart.setCapacity(rs.getInt("capacity"));
				all.add(shopping_cart);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConnection.close(rs, ps, conn);
		}
		return all;
	}

}
