package bean;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import util.DBConnection;

public class ManagerBean {
	private int manager_id;
	private String username;
	private String tel;

	public int getManager_id() {
		return manager_id;
	}

	public void setManager_id(int manager_id) {
		this.manager_id = manager_id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getTel() {
		return tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}
	
	public List<ManagerBean> listManager(){
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		List<ManagerBean> all = new ArrayList<ManagerBean>();
		try {
			conn = DBConnection.getConnection();
			String sql = "select * from managers";
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			while (rs.next()) {
				ManagerBean manager = new ManagerBean();
				manager.setManager_id(rs.getInt("manager_id"));
				manager.setUsername(rs.getString("username"));
				manager.setTel(rs.getString("tel"));
				all.add(manager);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConnection.close(rs, ps, conn);
		}
		return all;
	}

}

