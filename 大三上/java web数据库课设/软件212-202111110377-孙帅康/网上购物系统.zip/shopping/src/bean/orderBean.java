package bean;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import util.DBConnection;
import bean.orderBean;

public class orderBean {
	private int order_id;
	private Date orderdate;
	private String orderstatus_id;
	private int vip_id;
	private int manager_id;
	private float countmoney;
	private String orderstatus;
	private String username;
	
	public int getorder_id() {
		return order_id;
	}

	public void setorder_id(int order_id2) {
		this.order_id = order_id2;
	}

	public Date getorderdate() {
		return orderdate;
	}

	public void setorderdate(Date orderdate) {
		this.orderdate = orderdate;
	}

	public String getorderstatus_id() {
		return orderstatus_id;
	}

	public void setorderstatus_id(String orderstatus_id) {
		this.orderstatus_id = orderstatus_id;
	}

	public int getvip_id() {
		return vip_id;
	}

	public void setvip_id(int vip_id) {
		this.vip_id = vip_id;
	}
	public int getManager_id() {
		return manager_id;
	}

	public void setManager_id(int manager_id) {
		this.manager_id = manager_id;
	}
	public int getOrder_id() {
		return order_id;
	}

	public void setOrder_id(int order_id) {
		this.order_id = order_id;
	}

	public Date getOrderdate() {
		return orderdate;
	}

	public void setOrderdate(Date orderdate) {
		this.orderdate = orderdate;
	}

	public String getOrderstatus_id() {
		return orderstatus_id;
	}

	public void setOrderstatus_id(String orderstatus_id) {
		this.orderstatus_id = orderstatus_id;
	}

	public int getVip_id() {
		return vip_id;
	}

	public void setVip_id(int vip_id) {
		this.vip_id = vip_id;
	}

	public float getCountmoney() {
		return countmoney;
	}

	public void setCountmoney(float countmoney) {
		this.countmoney = countmoney;
	}

	public String getOrderstatus() {
		return orderstatus;
	}

	public void setOrderstatus(String orderstatus) {
		this.orderstatus = orderstatus;
	}
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}
	// ��ʾ���еĶ�����Ϣ
	public List<orderBean> listOrder() {
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		List<orderBean> all = new ArrayList<orderBean>();
		try {
			conn = DBConnection.getConnection();
			String sql = "select * from `order`,orderstatus,vip,user where `order`.orderstatus_id = orderstatus.orderstatus_id and `order`.vip_id = `vip`.vip_id AND `vip`.userid = `user`.userid order by order_id";
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			while (rs.next()) {
				orderBean order = new orderBean();
				order.setOrder_id(rs.getInt("order_id"));
				order.setOrderdate(rs.getDate("orderdate"));
				order.setOrderstatus_id(rs.getString("orderstatus_id"));
				order.setVip_id(rs.getInt("vip_id"));
				order.setManager_id(rs.getInt("manager_id"));
				order.setUsername(rs.getString("username"));
				order.setCountmoney(rs.getFloat("countmoney"));	
				order.setOrderstatus(rs.getString("orderstatus"));	
				all.add(order);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConnection.close(rs, ps, conn);
		}
		return all;
	}
//��ʾvip������Ϣ
		public List<orderBean> listvipOrder() {
			Connection conn = null;
			PreparedStatement ps = null;
			ResultSet rs = null;
			List<orderBean> all = new ArrayList<orderBean>();
			try {
				conn = DBConnection.getConnection();
				String sql = "select * from `order`,orderstatus where `order`.orderstatus_id = orderstatus.orderstatus_id and vip_id = 2 order by order_id asc";
				ps = conn.prepareStatement(sql);
				rs = ps.executeQuery();
				while (rs.next()) {
					orderBean order = new orderBean();
					order.setOrder_id(rs.getInt("order_id"));
					order.setOrderdate(rs.getDate("orderdate"));
					order.setOrderstatus_id(rs.getString("orderstatus_id"));
					order.setCountmoney(rs.getFloat("countmoney"));	
					order.setOrderstatus(rs.getString("orderstatus"));	
					all.add(order);
				}
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				DBConnection.close(rs, ps, conn);
			}
			return all;
		}
	
//���Ӷ���
//	public boolean orderAdd() {
//		Connection conn = null;
//		PreparedStatement ps = null;
//		ResultSet rs = null;
//		boolean flag = false;
//		try {
//
//			conn = DBConnection.getConnection();
//			String sql = "insert into order(order_id,orderstate,vip_id,countmoney) values(?,?,?,?)";
//			ps = conn.prepareStatement(sql);
//			ps.setInt(1, this.order_id);
//			ps.setString(3, this.orderstatus);
//			ps.setInt(4, this.vip_id);
//			ps.setFloat(5, this.countmoney);
//			ps.executeUpdate();
//			flag = true;
//		} catch (SQLException e) {
//
//			e.printStackTrace();
//		} finally {
//			DBConnection.close(rs, ps, conn);
//		}
//		return flag;
//	}
	
//���¶���
//	public boolean orderUpdate() {
//		Connection conn = null;
//		PreparedStatement ps = null;
//		ResultSet rs = null;
//		boolean flag = false;
//		try {
//			conn = DBConnection.getConnection();
//			String sql = "update order set orderstate=?,vip_id=?,countmoney=? where order_id=?";
//			ps = conn.prepareStatement(sql);
//			ps.setString(2, this.orderstatus);
//			ps.setInt(3, this.vip_id);
//			
//			ps.setInt(5, this.order_id);
//			ps.executeUpdate();
//			flag = true;
//		} catch (SQLException e) {
//			e.printStackTrace();
//		} finally {
//			DBConnection.close(rs, ps, conn);
//		}
//		return flag;
//	}
//ɾ������
//		public boolean deleteOrder(String deleteId) {
//			Connection conn = null;
//			PreparedStatement ps = null;
//			ResultSet rs = null;
//			boolean b = false;
//			int lines = 0;
//			try {
//				conn = DBConnection.getConnection();
//				String sql = "delete from `order` where order_id = ?";
//				ps = conn.prepareStatement(sql);
//				ps.setString(1, deleteId);
//				lines = ps.executeUpdate();
//				System.out.println(lines);
//				if (lines > 0) {
//					b = true;
//					return b;
//				}
//			} catch (SQLException e) {
//				e.printStackTrace();
//			} finally {
//				DBConnection.close(rs, ps, conn);
//			}
//			return b;
//		}
	// ��Ա���ݶ���״̬�����ڲ�ѯ������Ϣ
	public List<orderBean> searchOrder(String key) {
		Connection conn = null;
//		CallableStatement cs = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		List<orderBean> all = new ArrayList<orderBean>();
		try {
			conn = DBConnection.getConnection();
			String sql = "select * from `order`,orderstatus where `order`.orderstatus_id = orderstatus.orderstatus_id and (`orderstatus`.orderstatus like ? OR `order`.orderdate like binary ?) and vip_id = 2 order by order_id asc ";
			ps = conn.prepareStatement(sql);
			ps.setString(1, key);
			ps.setString(2, key);
			rs = ps.executeQuery();
			while (rs.next()) {
				orderBean order = new orderBean();
				order.setOrder_id(rs.getInt("order_id"));
				order.setOrderdate(rs.getDate("orderdate"));
				order.setOrderstatus_id(rs.getString("orderstatus_id"));
				order.setCountmoney(rs.getFloat("countmoney"));	
				order.setOrderstatus(rs.getString("orderstatus"));	
				all.add(order);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConnection.close(rs, ps, conn);
		}
		return all;
	}
	// ����Ա���ݶ���ID���û����ƣ�����״̬��ѯ������Ϣ
	public List<orderBean> searchOrderAll(String key) {
		Connection conn = null;
//		CallableStatement cs = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		List<orderBean> all = new ArrayList<orderBean>();
		try {
			conn = DBConnection.getConnection();
			String sql = "select * from `order`,orderstatus,user,vip where `order`.orderstatus_id = orderstatus.orderstatus_id and `order`.vip_id = `vip`.vip_id AND `vip`.userid = `user`.userid and (`orderstatus`.orderstatus like ? OR `order`.order_id like ? OR `user`.username like ?) order by order_id asc ";
			ps = conn.prepareStatement(sql);
			ps.setString(1, key);
			ps.setString(2, key);
			ps.setString(3, key);
			rs = ps.executeQuery();
			while (rs.next()) {
				orderBean order = new orderBean();
				order.setOrder_id(rs.getInt("order_id"));
				order.setOrderdate(rs.getDate("orderdate"));
				order.setOrderstatus_id(rs.getString("orderstatus_id"));
				order.setVip_id(rs.getInt("vip_id"));
				order.setUsername(rs.getString("username"));
				order.setCountmoney(rs.getFloat("countmoney"));	
				order.setOrderstatus(rs.getString("orderstatus"));	
				all.add(order);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConnection.close(rs, ps, conn);
		}
		return all;
	}
//���Ӷ���
//	public void addorder(orderBean order) {
//		Connection conn=null;
//		Statement st=null;
//		ResultSet rs=null;
//		try {
//			conn=DBConnection.getConnection();
//			String sql="insert into order(Order_id,Orderstatus,Vip_id,Username)"+"values('"+order.getOrder_id()+"','"+order.getOrderstatus()+"','"+order.getVip_id()+"','"+order.getUsername()+"')";
//			st=conn.prepareStatement(sql);
//			st.execute(sql);
//		}catch(SQLException e) {
//			System.out.println("����ʧ�ܣ�"+e.getMessage());
//		}finally {
//			DBConnection.close(rs, st, conn);
//		}
//	}
// ���Ӷ�����Ϣ
		public boolean addOrder(orderBean order) {
			Connection conn = null;
			PreparedStatement ps = null;
			ResultSet rs = null;
			boolean b = false;
			int lines = 0;
			try {
				conn = DBConnection.getConnection();
				String sql = "insert into `order`(order_id,orderstatus,vip_id,countmoney) values(?,?,?,?) where `order`.orderstatus_id = orderstatus.orderstatus_id and `order`.vip_id = `vip`.vip_id AND `vip`.userid = `user`.userid ";
				ps = conn.prepareStatement(sql);
				ps.setInt(1, order.getOrder_id());
				ps.setString(2, order.getOrderstatus());
				ps.setInt(3, order.getVip_id());
				ps.setFloat(4, order.getCountmoney());
				lines = ps.executeUpdate();
				System.out.println(lines);
				if (lines > 0) {
					b = true;
					return b;
				}
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				DBConnection.close(rs, ps, conn);
			}
			return b;
		}
//ɾ��������Ϣ
	public boolean deleteOrder(String deleteId) {
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		boolean b = false;
		int lines = 0;
		try {
			conn = DBConnection.getConnection();
			String sql = "delete from `order` where order_id = ?";
			ps = conn.prepareStatement(sql);
			ps.setString(1, deleteId);
			lines = ps.executeUpdate();
			System.out.println(lines);
			if (lines > 0) {
				b = true;
				return b;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConnection.close(rs, ps, conn);
		}
		return b;
	}
	// ����һ��������Ϣ
		public boolean editOrder(orderBean editorder, int editid) {
			Connection conn = null;
			PreparedStatement ps = null;
			ResultSet rs = null;
			boolean b = false;
			int lines = 0;
			try {
				conn = DBConnection.getConnection();
				String sql = "update `order` set order_id = ? , orderstatus = ? , vip_id = ? , countmoney= ? where order_id = ?";
				ps = conn.prepareStatement(sql);
				ps.setInt(1, editorder.getorder_id());
				ps.setString(2, editorder.getOrderstatus());
				ps.setInt(3, editorder.getVip_id());
				ps.setFloat(4, editorder.getCountmoney());
				ps.setInt(5, editid);
				lines = ps.executeUpdate();
				System.out.println("���£�"+lines);
				if (lines > 0) {
					b = true;
					return b;
				}
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				DBConnection.close(rs, ps, conn);
			}
			return b;
		}
		//��ʾ���嶩����Ϣ

		public orderBean listUserorderById(int id) {
			Connection conn = null;
			PreparedStatement ps = null;
			ResultSet rs = null;
			orderBean order = new orderBean();
			try {
				conn = DBConnection.getConnection();
				String sql = "select * from `order`,orderstatus,user,vip where `order`.orderstatus_id = orderstatus.orderstatus_id and `order`.vip_id = `vip`.vip_id AND `vip`.userid = `user`.userid and order_id = ?";
				ps = conn.prepareStatement(sql);
				ps.setInt(1, id);
				rs = ps.executeQuery();
				if (rs.next()) {
					
					order.setOrder_id(rs.getInt("order_id"));
					order.setOrderdate(rs.getDate("orderdate"));
					order.setOrderstatus_id(rs.getString("orderstatus_id"));
					order.setVip_id(rs.getInt("vip_id"));
					order.setManager_id(rs.getInt("manager_id"));
					order.setUsername(rs.getString("username"));
					order.setCountmoney(rs.getFloat("countmoney"));	
					order.setOrderstatus(rs.getString("orderstatus"));	
					
				}
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				DBConnection.close(rs, ps, conn);
			}
			return order;
		}
}

