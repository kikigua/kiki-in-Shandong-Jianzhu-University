package bean;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import util.DBConnection;

public class GoodKindBean {
	private int family_id;
	private String family_name;

	public int getFamily_id() {
		return family_id;
	}

	public void setFamily_id(int family_id) {
		this.family_id = family_id;
	}

	public String getFamily_name() {
		return family_name;
	}

	public void setFamily_name(String family_name) {
		this.family_name = family_name;
	}

	// ��ʾ���е���Ʒ���
	public List<GoodKindBean> listGoodKind() {
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		List<GoodKindBean> all = new ArrayList<GoodKindBean>();
		try {
			conn = DBConnection.getConnection();
			String sql = "select * from commodity_family";
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			while (rs.next()) {
				GoodKindBean kindName = new GoodKindBean();
				kindName.setFamily_id(rs.getInt("family_id"));
				kindName.setFamily_name(rs.getString("family_name"));
				all.add(kindName);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConnection.close(rs, ps, conn);
		}
		return all;
	}
	
	// ����һ����Ʒ��Ϣ
		public boolean addGoodKind(String addkindname) {
			Connection conn = null;
			PreparedStatement ps = null;
			ResultSet rs = null;
			boolean b = false;
			int lines = 0;
			try {
				conn = DBConnection.getConnection();
				String sql = "insert into commodity_family(family_name) values(?)";
				ps = conn.prepareStatement(sql);
				ps.setString(1, addkindname);
				lines = ps.executeUpdate();
				System.out.println(lines);
				if (lines > 0) {
					b = true;
					return b;
				}
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				DBConnection.close(rs, ps, conn);
			}
			return b;
		}

}

