package bean;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import util.DBConnection;

public class CartBean
{

	private String commodity_name;
	private String commodity_pic;
	private float commodity_price;
	private int commodity_id;
	private int cart_id;
	private int good_nums;
	private float sum;

	public float getSum()
	{
		return sum;
	}

	public void setSum(float sum)
	{
		this.sum = sum;
	}

	public int getCommodity_id()
	{
		return commodity_id;
	}

	public void setCommodity_id(int commodity_id)
	{
		this.commodity_id = commodity_id;
	}

	public int getCart_id()
	{
		return cart_id;
	}

	public void setCart_id(int cart_id)
	{
		this.cart_id = cart_id;
	}

	public String getCommodity_name()
	{
		return commodity_name;
	}

	public void setCommodity_name(String commodity_name)
	{
		this.commodity_name = commodity_name;
	}

	public String getCommodity_pic()
	{
		return commodity_pic;
	}

	public void setCommodity_pic(String commodity_pic)
	{
		this.commodity_pic = commodity_pic;
	}

	public float getCommodity_price()
	{
		return commodity_price;
	}

	public void setCommodity_price(float commodity_price)
	{
		this.commodity_price = commodity_price;
	}

	public int getGood_nums()
	{
		return good_nums;
	}

	public void setGood_nums(int good_nums)
	{
		this.good_nums = good_nums;
	}

	// ��ȡ���ﳵ�б�
	public List<CartBean> listMycart()
	{
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		List<CartBean> cart = new ArrayList<CartBean>();
		try
		{
			conn = DBConnection.getConnection();
			String sql = "select * from purchase,commodity where commodity.commodity_id=purchase.commodity_id and cart_id= ?; ";

			ps = conn.prepareStatement(sql);
			ps.setInt(1, 3);
			rs = ps.executeQuery();
			while (rs.next())
			{
				CartBean commcart = new CartBean();
				commcart.setCommodity_id(rs.getInt("commodity_id"));
				commcart.setCart_id(rs.getInt("cart_id"));
				commcart.setCommodity_name(rs.getString("commodity_name"));
				commcart.setCommodity_pic(rs.getString("commodity_pic"));
				commcart.setGood_nums(rs.getInt("good_nums"));
				commcart.setCommodity_price(rs.getFloat("commodity_price"));
				cart.add(commcart);
			}
		} catch (SQLException e)
		{
			e.printStackTrace();
		} finally
		{
			DBConnection.close(rs, ps, conn);
		}
		return cart;
	}

	// ɾ�����ﳵ��Ʒ
	public boolean deleteCart(String commID, String cartID)
	{
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		boolean b = false;
		int lines = 0;
		try
		{
			conn = DBConnection.getConnection();
			String sql = "delete from purchase where commodity_id = ? and cart_id=? ";
			ps = conn.prepareStatement(sql);
			ps.setString(1, commID);
			ps.setString(2, cartID);
			lines = ps.executeUpdate();
			System.out.println("lines:" + lines);
			if (lines > 0)
			{
				b = true;
				return b;
			}
		} catch (SQLException e)
		{
			e.printStackTrace();
		} finally
		{
			DBConnection.close(rs, ps, conn);
		}
		return b;
	}

	// ��չ��ﳵ��Ʒ
	public boolean ClearCart(String cartID)
	{
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		boolean b = false;
		int lines = 0;
		try
		{
			conn = DBConnection.getConnection();
			String sql = "delete from purchase where commodity_id = ? and cart_id=? ";
			ps = conn.prepareStatement(sql);
			ps.setString(2, cartID);
			lines = ps.executeUpdate();
			System.out.println("lines:" + lines);
			if (lines > 0)
			{
				b = true;
				return b;
			}
		} catch (SQLException e)
		{
			e.printStackTrace();
		} finally
		{
			DBConnection.close(rs, ps, conn);
		}
		return b;
	}

	// ����
	public Float sum()
	{
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		float totalsum = 0;

		try
		{
			conn = DBConnection.getConnection();
			String sql = "select SUM(commodity_price) as totalsum FROM	purchase,	commodity WHERE 	commodity.commodity_id = purchase.commodity_id and cart_id=?;";
			ps = conn.prepareStatement(sql);
			ps.setInt(1, 3);
			rs = ps.executeQuery();
			while (rs.next())
			{
				totalsum = rs.getFloat("totalsum");

			}

			System.out.println("totalsum:" + totalsum);
		} catch (SQLException e)
		{
			e.printStackTrace();
		} finally
		{
			DBConnection.close(rs, ps, conn);
		}
		return totalsum;
	}
//	�ӹ��ﳵ
	public boolean addCart(CartBean cart) {
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		boolean b = false;
		int lines = 0;
		try {
			conn = DBConnection.getConnection();
			String sql = "insert into purchase(commodity_id,cart_id,good_nums) values(?,?,?)";
			ps = conn.prepareStatement(sql);
			ps.setInt(1, cart.getCommodity_id());
			ps.setInt(2, cart.getCart_id());
			ps.setInt(3, cart.getGood_nums());
			lines = ps.executeUpdate();
			if (lines > 0) {
				b = true;
				return b;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConnection.close(rs, ps, conn);
		}
		return b;
	}
}