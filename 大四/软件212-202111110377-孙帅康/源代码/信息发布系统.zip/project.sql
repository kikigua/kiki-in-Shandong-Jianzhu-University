/*
Navicat MySQL Data Transfer

Source Server         : mysql823
Source Server Version : 80023
Source Host           : localhost:3406
Source Database       : project

Target Server Type    : MYSQL
Target Server Version : 80023
File Encoding         : 65001

Date: 2024-09-17 16:26:38
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for bill
-- ----------------------------
DROP TABLE IF EXISTS `bill`;
CREATE TABLE `bill` (
  `id` int NOT NULL,
  `money` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `coach_id` int DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `class_id` int DEFAULT NULL,
  `time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of bill
-- ----------------------------

-- ----------------------------
-- Table structure for class
-- ----------------------------
DROP TABLE IF EXISTS `class`;
CREATE TABLE `class` (
  `id` int NOT NULL,
  `vedeo_url` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `price` varchar(255) DEFAULT NULL,
  `coach_id` int DEFAULT NULL,
  `status` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of class
-- ----------------------------

-- ----------------------------
-- Table structure for coach
-- ----------------------------
DROP TABLE IF EXISTS `coach`;
CREATE TABLE `coach` (
  `id` int NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `age` int DEFAULT NULL,
  `introduce` varchar(255) DEFAULT NULL,
  `sex` varchar(10) DEFAULT NULL,
  `type_id` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of coach
-- ----------------------------

-- ----------------------------
-- Table structure for crole
-- ----------------------------
DROP TABLE IF EXISTS `crole`;
CREATE TABLE `crole` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `status` char(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of crole
-- ----------------------------
INSERT INTO `crole` VALUES ('3', '康复教练', 'V', '2023-09-28 08:40:20', '2023-09-28 15:08:00');
INSERT INTO `crole` VALUES ('5', '瑜伽健身教练', 'V', '2023-09-28 09:20:29', '2023-09-28 09:20:29');
INSERT INTO `crole` VALUES ('7', '塑形教练', 'V', '2023-09-28 11:07:29', '2023-09-28 11:07:29');
INSERT INTO `crole` VALUES ('8', '康健教练', 'V', '2023-09-28 13:49:10', '2023-09-28 13:49:10');
INSERT INTO `crole` VALUES ('9', '短跑教练', 'V', '2023-09-28 14:32:37', '2023-09-28 14:33:23');

-- ----------------------------
-- Table structure for tb_action
-- ----------------------------
DROP TABLE IF EXISTS `tb_action`;
CREATE TABLE `tb_action` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `action_code` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '行为编号',
  `action_name` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '行为名称',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `unq_action_name` (`action_name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='行为表';

-- ----------------------------
-- Records of tb_action
-- ----------------------------
INSERT INTO `tb_action` VALUES ('1', 'INSERT', '添加');
INSERT INTO `tb_action` VALUES ('2', 'DELETE', '删除');
INSERT INTO `tb_action` VALUES ('3', 'UPDATE', '修改');
INSERT INTO `tb_action` VALUES ('4', 'SELECT', '查询');
INSERT INTO `tb_action` VALUES ('5', 'APPROVAL', '审批');
INSERT INTO `tb_action` VALUES ('6', 'EXPORT', '导出');
INSERT INTO `tb_action` VALUES ('7', 'BACKUP', '备份');
INSERT INTO `tb_action` VALUES ('8', 'ARCHIVE', '归档');

-- ----------------------------
-- Table structure for tb_dept
-- ----------------------------
DROP TABLE IF EXISTS `tb_dept`;
CREATE TABLE `tb_dept` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `dept_name` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '部门名称',
  `tel` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '部门电话',
  `email` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '部门邮箱',
  `desc` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `unq_dept_name` (`dept_name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='部门表';

-- ----------------------------
-- Records of tb_dept
-- ----------------------------
INSERT INTO `tb_dept` VALUES ('1', '管理部1', '010-12345678', 'manage@163.com', '管理部负责管理公司所有事务');
INSERT INTO `tb_dept` VALUES ('2', '行政部', null, 'tech@163.com', null);
INSERT INTO `tb_dept` VALUES ('3', '技术部', '010-12345678', 'tech@163.com', null);
INSERT INTO `tb_dept` VALUES ('4', '市场部', null, 'tech@163.com', null);
INSERT INTO `tb_dept` VALUES ('5', '后勤部', null, 'tech@163.com', null);
INSERT INTO `tb_dept` VALUES ('6', '人事部', null, '106135489@qq.com', null);

-- ----------------------------
-- Table structure for tb_module
-- ----------------------------
DROP TABLE IF EXISTS `tb_module`;
CREATE TABLE `tb_module` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `module_code` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '模块编号',
  `module_name` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '模块名称',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `unq_module_id` (`module_code`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='模块资源表';

-- ----------------------------
-- Records of tb_module
-- ----------------------------
INSERT INTO `tb_module` VALUES ('1', 'USER', '用户管理');
INSERT INTO `tb_module` VALUES ('2', 'DEPT', '部门管理');
INSERT INTO `tb_module` VALUES ('3', 'ROLE', '角色管理');
INSERT INTO `tb_module` VALUES ('4', 'TEACHER', '讲师管理');
INSERT INTO `tb_module` VALUES ('5', 'POSITION', '职务管理');

-- ----------------------------
-- Table structure for tb_permission
-- ----------------------------
DROP TABLE IF EXISTS `tb_permission`;
CREATE TABLE `tb_permission` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `permission_name` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '权限',
  `module_id` int unsigned NOT NULL COMMENT '模块ID',
  `action_id` int unsigned NOT NULL COMMENT '行为ID',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `unq_permission` (`permission_name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=893 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='权限表';

-- ----------------------------
-- Records of tb_permission
-- ----------------------------
INSERT INTO `tb_permission` VALUES ('1', 'USER:INSERT', '1', '1');
INSERT INTO `tb_permission` VALUES ('2', 'USER:DELETE', '1', '2');
INSERT INTO `tb_permission` VALUES ('3', 'USER:UPDATE', '1', '3');
INSERT INTO `tb_permission` VALUES ('4', 'USER:SELECT', '1', '4');
INSERT INTO `tb_permission` VALUES ('5', 'DEPT:INSERT', '2', '1');
INSERT INTO `tb_permission` VALUES ('6', 'DEPT:DELETE', '2', '2');
INSERT INTO `tb_permission` VALUES ('7', 'DEPT:UPDATE', '2', '3');
INSERT INTO `tb_permission` VALUES ('8', 'DEPT:SELECT', '2', '4');
INSERT INTO `tb_permission` VALUES ('9', 'ROLE:INSERT', '3', '1');
INSERT INTO `tb_permission` VALUES ('10', 'ROLE:DELETE', '3', '2');
INSERT INTO `tb_permission` VALUES ('11', 'ROLE:UPDATE', '3', '3');
INSERT INTO `tb_permission` VALUES ('12', 'ROLE:SELECT', '3', '4');
INSERT INTO `tb_permission` VALUES ('666', 'TEACHER:INSERT', '4', '1');
INSERT INTO `tb_permission` VALUES ('667', 'TEACHER:DELETE', '4', '2');
INSERT INTO `tb_permission` VALUES ('668', 'TEACHER:UPDATE', '4', '3');
INSERT INTO `tb_permission` VALUES ('669', 'TEACHER:SELECT', '4', '4');
INSERT INTO `tb_permission` VALUES ('888', 'POSITION:INSERT', '5', '1');
INSERT INTO `tb_permission` VALUES ('889', 'POSITION:DELETE', '5', '2');
INSERT INTO `tb_permission` VALUES ('890', 'POSITION:UPDATE', '5', '3');
INSERT INTO `tb_permission` VALUES ('891', 'POSITION:SELECT', '5', '4');
INSERT INTO `tb_permission` VALUES ('892', 'ROOT', '0', '0');

-- ----------------------------
-- Table structure for tb_position
-- ----------------------------
DROP TABLE IF EXISTS `tb_position`;
CREATE TABLE `tb_position` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '主键|列表字段|input',
  `name` varchar(50) NOT NULL COMMENT '职位名称|唯一|列表字段|查询字段|input',
  `status` char(1) DEFAULT 'V' COMMENT '状态|列表字段|select[enums:{key: ''V'',value: ''有效''},{key: ''I'',value: ''无效''}]',
  `created_at` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_at` datetime DEFAULT NULL COMMENT '修改时间|列表字段|date',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unq_name` (`name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='职位';

-- ----------------------------
-- Records of tb_position
-- ----------------------------
INSERT INTO `tb_position` VALUES ('1', 'java讲师', 'V', '2023-09-20 09:03:49', '2023-09-20 09:03:49');
INSERT INTO `tb_position` VALUES ('2', '前端讲师', 'V', '2023-09-20 09:03:50', '2023-09-20 09:03:50');
INSERT INTO `tb_position` VALUES ('3', '111', 'V', '2023-09-20 09:03:50', '2023-09-28 11:13:19');

-- ----------------------------
-- Table structure for tb_role
-- ----------------------------
DROP TABLE IF EXISTS `tb_role`;
CREATE TABLE `tb_role` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `role_name` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '角色名称',
  `permissions` varchar(200) NOT NULL COMMENT '权限集合',
  `desc` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '描述',
  `default_permissions` varchar(200) DEFAULT NULL COMMENT '系统角色内置权限',
  `systemic` tinyint(1) DEFAULT '0' COMMENT '是否为系统内置角色',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `unq_role_name` (`role_name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='角色表';

-- ----------------------------
-- Records of tb_role
-- ----------------------------
INSERT INTO `tb_role` VALUES ('1', '总经理', '[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]', null, null, '0');
INSERT INTO `tb_role` VALUES ('2', '部门经理', '[1, 2, 3, 4, 5, 6, 7, 8]', null, null, '0');
INSERT INTO `tb_role` VALUES ('3', '普通员工', '[1, 2, 3, 4]', null, null, '0');
INSERT INTO `tb_role` VALUES ('4', 'HR', '[5, 6, 7, 8]', null, null, '0');
INSERT INTO `tb_role` VALUES ('5', '财务', '[9, 10, 11, 12]', null, null, '0');
INSERT INTO `tb_role` VALUES ('6', '超级管理员', '[0]', '超级管理员用户不能删除和修改', null, '0');

-- ----------------------------
-- Table structure for tb_teacher
-- ----------------------------
DROP TABLE IF EXISTS `tb_teacher`;
CREATE TABLE `tb_teacher` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '主键|列表字段|input',
  `name` varchar(50) NOT NULL COMMENT '姓名|列表字段|查询字段|input',
  `nickname` varchar(50) DEFAULT NULL COMMENT '昵称|唯一|列表字段|input|排序',
  `image` varchar(100) DEFAULT NULL COMMENT '头像|upload',
  `image_size` int DEFAULT NULL COMMENT '大小|列表字段|input',
  `position_id` int DEFAULT NULL COMMENT '职位|列表字段|select[db:position]',
  `motto` varchar(50) DEFAULT NULL COMMENT '座右铭|列表字段|textarea',
  `introduce` varchar(500) DEFAULT NULL COMMENT '简介|rich',
  `sort` int unsigned DEFAULT NULL COMMENT '顺序|顺序调整|列表字段|number|排序',
  `created_at` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_at` datetime DEFAULT NULL COMMENT '修改时间|列表字段|date',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unq_nickname` (`nickname`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='讲师';

-- ----------------------------
-- Records of tb_teacher
-- ----------------------------
INSERT INTO `tb_teacher` VALUES ('1', '孔子', 'kong', 'http://file.szaptk.com/productImage-title-header.png', '1', '1', '座右铭1', '简介1', '1', '2023-09-20 09:03:50', '2023-09-20 09:03:50');
INSERT INTO `tb_teacher` VALUES ('2', '老子', 'lao', 'http://file.szaptk.com/productImage-title-header.png', '1', '2', '座右铭2', '简介2', '2', '2023-09-20 09:03:50', '2023-09-20 09:03:50');
INSERT INTO `tb_teacher` VALUES ('3', '孟子', 'meng', 'http://file.szaptk.com/productImage-title-header.png', '1', '1', '座右铭3', '简介3', '3', '2023-09-20 09:03:50', '2023-09-20 09:03:50');
INSERT INTO `tb_teacher` VALUES ('4', '荀子', 'xun', 'http://file.szaptk.com/productImage-title-header.png', '1', '2', '座右铭4', '简介4', '4', '2023-09-20 09:03:50', '2023-09-20 09:03:50');
INSERT INTO `tb_teacher` VALUES ('5', '墨子', 'mo', 'http://file.szaptk.com/productImage-title-header.png', '1', '1', '座右铭5', '简介5', '5', '2023-09-20 09:03:50', '2023-09-20 09:03:50');
INSERT INTO `tb_teacher` VALUES ('6', '帝子', 'di', 'http://file.szaptk.com/productImage-title-header.png', '1', '2', '座右铭6', '简介6', '6', '2023-09-20 09:03:50', '2023-09-20 09:03:50');
INSERT INTO `tb_teacher` VALUES ('7', '门子', 'men', 'http://file.szaptk.com/productImage-title-header.png', '1', '2', '座右铭7', '简介7', '7', '2023-09-20 09:03:50', '2023-09-20 09:03:50');

-- ----------------------------
-- Table structure for tb_user
-- ----------------------------
DROP TABLE IF EXISTS `tb_user`;
CREATE TABLE `tb_user` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '主键',
  `username` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '用户名',
  `password` varchar(2000) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '密码',
  `open_id` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '长期授权字符串',
  `nickname` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '昵称',
  `photo` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '头像网址',
  `name` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '姓名',
  `sex` enum('男','女') CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '性别',
  `tel` char(11) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '手机号码',
  `email` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '邮箱',
  `hiredate` date DEFAULT NULL COMMENT '入职日期',
  `role` varchar(100) NOT NULL COMMENT '角色',
  `root` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否是超级管理员',
  `dept_id` int unsigned DEFAULT NULL COMMENT '部门编号',
  `status` tinyint NOT NULL COMMENT '状态',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `unq_open_id` (`open_id`) USING BTREE,
  UNIQUE KEY `unq_username` (`username`) USING BTREE,
  KEY `unq_email` (`email`) USING BTREE,
  KEY `idx_dept_id` (`dept_id`) USING BTREE,
  KEY `idx_status` (`status`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='用户表';

-- ----------------------------
-- Records of tb_user
-- ----------------------------
INSERT INTO `tb_user` VALUES ('1', 'admin', 'F8833383029D93ACBD66F6C8D81602DD', 'onRW_4lxZC4nMNTnSDl5DMk74eoc', '超级管理员', 'https://thirdwx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTKycDpBjeJZdJ6JsdqOzZsCAssFHw19QEueDzqkxexMklT5K3XW01iaa0dh0Zm9j6tWiaY7RVVmUxaw/132', '管理员', '男', '18013876546', 'admin@aliyun.com', '2021-12-10', '[1]', '1', '1', '1', '2024-08-20 12:58:52');
INSERT INTO `tb_user` VALUES ('2', 'A00001', '5DF0443D0E23790ABE9DBB27B182569D', null, null, null, '张三', '男', '15678998778', 'zbc@163.com', '2023-03-21', '[1, 2]', '0', '2', '1', '2024-08-20 11:51:44');
INSERT INTO `tb_user` VALUES ('3', 'A00002', 'B5D4BF117B7DCAA3DD0D6B8E1D3E4707', null, null, null, '西施', '女', '12323232323', 'test@qq.com', '2023-03-21', '[5]', '0', '1', '1', '2024-08-20 11:51:44');
INSERT INTO `tb_user` VALUES ('4', 'A00003', '3CB29CF034F862A20203AC6E8AFB1EA9', null, null, null, '关羽', '男', '18013897865', 'test@qq.com', '2023-03-22', '[3]', '0', '3', '1', '2024-08-20 11:51:44');
INSERT INTO `tb_user` VALUES ('5', 'A00004', '51EF8D462904E3852BB7CC0393821473', null, null, null, '曹操', '男', '18012987656', 'cao@a.com', '2023-03-22', '[2]', '0', '4', '1', '2024-08-20 11:51:44');
INSERT INTO `tb_user` VALUES ('6', 'A00006', '4BF2265A0F44A8AA7C010599AD93D3AD', null, null, null, '刘备', '男', '18013809876', 'liubei@qq.com', '2023-03-22', '[3]', '0', '5', '1', '2024-08-20 11:51:44');
INSERT INTO `tb_user` VALUES ('7', 'A00007', 'A54DDC4EE15022A2A705EC6EAD66ED34', null, null, null, '张飞', '男', '18012765478', 'tt@qq.com', '2023-03-22', '[3]', '0', '2', '1', '2024-08-20 11:51:44');

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `account` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `nickname` varchar(255) DEFAULT NULL,
  `height` double DEFAULT NULL,
  `weight` double DEFAULT NULL,
  `sex` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `tel` char(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('3', 'gaomengqi', 'gao12345', '龙泉', '163', '92', '女', '15668313895', '高孟琪');
INSERT INTO `user` VALUES ('6', 'Aa1235', '123456', null, '188', '120', '男', '18253439325', '王永昌');
INSERT INTO `user` VALUES ('7', 'avsgv', '1567864', null, '185', '180', '男', '15689596565', '于海腾');
INSERT INTO `user` VALUES ('8', 'aaa1111111', 'BAF679046145B8E88D22585304FFBECA', null, '199', '50', '男', '19511563000', 'zhangsan');
