package com.study.qsapi.service;

import com.study.qsapi.util.PageUtil;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.HashMap;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;//静态导入
@SpringBootTest
public class DeptServiceTest {
    @Autowired
    private DeptService deptService;
    @Test
    public void testSearchDeptByPage(){
        HashMap map=new HashMap();//准备参数,分页拦截器必须传入page和length
        map.put("page",1);//第一页
        map.put("length",10);//每页10条
        map.put("deptName","管理");//查询条件，如果不设置查询条件，就是查询所有
        PageUtil pageData = deptService.searchDeptByPage(map);//执行分页查询，返回分页对象
        System.out.print(pageData);
    }
}
