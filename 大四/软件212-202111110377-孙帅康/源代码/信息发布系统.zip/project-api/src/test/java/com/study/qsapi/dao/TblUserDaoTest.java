package com.study.qsapi.dao;


import com.study.qsapi.db.dao.TbUserDao;
import com.sun.scenario.effect.impl.sw.java.JSWBlend_EXCLUSIONPeer;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.ArrayList;
import java.util.HashMap;
import static org.junit.jupiter.api.Assertions.*;//静态导入
@SpringBootTest
public class TblUserDaoTest {
    @Autowired
    private TbUserDao userDao;
    @Test
    public void testLogin() throws Exception{
        HashMap paramMap=new HashMap();

        paramMap.put("username","admin");
        paramMap.put("password","abc123456");
        Integer id=userDao.login(paramMap);
        assertNotNull(id);
    }

    @Test
    public void testListPageUser() throws Exception{
        HashMap paramMap=new HashMap();
        paramMap.put("page",1);
        paramMap.put("length",10);
        paramMap.put("sex","男");
        ArrayList<HashMap> list = userDao.listPageUser(paramMap);
        list.stream().forEach(System.out::println);
        System.out.println(paramMap.get("totalCount"));
    }

    @Test
    public void testSearchUserByPage() throws Exception{
        HashMap paramMap=new HashMap();
        paramMap.put("start",1);
        paramMap.put("length",10);
        paramMap.put("sex","男");
        ArrayList<HashMap> list = userDao.searchUserByPage(paramMap);
        list.stream().forEach(System.out::println);
    }
}
