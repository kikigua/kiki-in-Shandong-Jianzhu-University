package com.study.qsapi.service;

import com.study.qsapi.util.PageUtil;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.HashMap;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest
public class TeacherServiceTest {
    @Autowired
    private TeacherService teacherService;
    @Test
    public void testListPageTeacher(){
        HashMap map=new HashMap();
        map.put("page",1);//分页查询第一页
        map.put("length",10);//每页10条数据
        map.put("name","子");//查询条件
        PageUtil pageUtil =teacherService.listPageTeacher(map);//分页查询
        assertTrue(pageUtil.getList().size()>0);//断言查询结果大于0
        System.out.print(pageUtil);
    }
}
