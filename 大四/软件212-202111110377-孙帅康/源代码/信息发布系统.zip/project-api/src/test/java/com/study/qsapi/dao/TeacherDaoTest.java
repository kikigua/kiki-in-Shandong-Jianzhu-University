package com.study.qsapi.dao;

import com.study.qsapi.db.dao.PositionMapper;
import com.study.qsapi.db.dao.TeacherMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.HashMap;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest
public class TeacherDaoTest {
    @Autowired
    private TeacherMapper teacherMapper;
    @Test
    public void testListPageTeacher(){
        HashMap map=new HashMap();
        map.put("page",1);//分页查询第一页
        map.put("length",10);//每页10条数据
        map.put("name","子");//查询条件
        List<HashMap> list=teacherMapper.listPageTeacher(map);//分页查询
        assertTrue(list.size()>0);//断言查询结果大于0
        list.stream().forEach(System.out::println);//打印查询结果
    }
}
