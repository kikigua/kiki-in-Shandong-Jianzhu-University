package com.study.qsapi.dao;

import com.study.qsapi.db.dao.CroleDao;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.HashMap;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest
public class CroleDaoTest {
    @Autowired
    private CroleDao croleDao;
    @Test
    public void testListPagePosition(){
        HashMap map=new HashMap();
        map.put("page",1);//分页查询第一页
        map.put("length",10);//每页10条数据
        map.put("name","java");
        List<HashMap> list=croleDao.listPagePosition(map);//分页查询
        assertTrue(list.size()>0);//断言查询结果大于0
        list.stream().forEach(System.out::println);//打印查询结果
    }

    @Test
    public void testDeleteByIds(){
        Integer[] ids={ 2 };
        int result=croleDao.deleteByIds(ids);
        assertTrue(result>0);//断言查询结果大于0
    }
}
