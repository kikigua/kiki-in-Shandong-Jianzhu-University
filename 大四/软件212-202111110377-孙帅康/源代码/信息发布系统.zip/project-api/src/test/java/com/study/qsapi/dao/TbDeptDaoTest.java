package com.study.qsapi.dao;

import com.study.qsapi.db.dao.TbDeptDao;
import com.study.qsapi.db.pojo.TbDept;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.HashMap;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;//静态导入
@SpringBootTest
public class TbDeptDaoTest {
    @Autowired //注入DeptDao
    private TbDeptDao deptDao;
    @Test
    public void testListPageDept() {
        HashMap map = new HashMap();//准备参数,分页拦截器必须传入page和length
        map.put("page", 1);//第一页
        map.put("length", 10);//每页10条
        map.put("deptName", "管理");//查询条件
        List<HashMap> list = deptDao.listPageDept(map);//执行分页查询
        assertTrue(list.size() > 0);//断言查询查询集合长度大于0
        list.stream().forEach(System.out::println);//遍历输出
    }
    @Test
    public void testInsert(){
        TbDept t=new TbDept();
        t.setDeptName("测试部门");
        t.setDesc("测试部门描述");
        int i=deptDao.insert(t);
        assertTrue(i>0);//判断表达式是否为真
        //assertEquals(1,i); //判断期望值与实际值是否相等
    }
}
