package com.study.qsapi.web.form;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

@Data
@Schema(description = "添加职务表单")
public class InsertPositionForm {
    @NotBlank(message = "name不能为空")
    @Schema(description = "职务名称")
    private String name;

    @NotBlank(message = "status不能为空")
    @Schema(description = "状态")
    private String status;
}
