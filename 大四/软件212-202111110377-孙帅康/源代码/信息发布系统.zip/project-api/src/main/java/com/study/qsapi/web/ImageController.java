package com.study.qsapi.web;

import com.study.qsapi.dto.CkEditorResult;
import com.study.qsapi.dto.WangEditorResult;
import com.study.qsapi.util.ImageUploadUtil;
import com.study.qsapi.web.form.TokenForm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import static org.yaml.snakeyaml.tokens.Token.ID.Error;

/**
 * 处理前端图片上传的Controller
 */
@RestController
@RequestMapping("/image")
public class ImageController {

    @Autowired
    private ImageUploadUtil imageUploadUtil;

    /**
     * 七牛云传入上传文件名，获取令牌
     * @param tokenForm
     * @return
     */
    @PostMapping("/upload-token")
    public String getToken(@RequestBody TokenForm tokenForm) {
        System.out.println(tokenForm.getFileName());
        return imageUploadUtil.getToken(tokenForm.getFileName());
    }

    /**
     * ckeditor上传路径
     * @param upload
     * @return
     */
    @PostMapping("/upload-ck")
    public CkEditorResult addCkImage(MultipartFile upload) {
        CkEditorResult ckEditorResult=new CkEditorResult();
        String url=imageUploadUtil.uploadImageToQiNiu("image/", upload);
        if(url!=null){ //图片上传成功
            ckEditorResult.setUrl(url);
        }else{ //上传失败
            CkEditorResult.Error error=ckEditorResult.new Error();
            error.setMessage("上传失败");
            ckEditorResult.setError(error);
        }
        return ckEditorResult;
    }

    @PostMapping("/upload-wang")
    public WangEditorResult addResource(MultipartFile uploadFile) {
        WangEditorResult uploadResult=new WangEditorResult();
        String url=imageUploadUtil.uploadImageToQiNiu("image/",uploadFile);
        if(url!=null){ //图片上传成功
            uploadResult.setErrno(0);
            WangEditorResult.Data data=new WangEditorResult().new Data();
            data.setUrl(url);
            uploadResult.setData(data);
        }else{ //上传失败
            uploadResult.setErrno(1);
            uploadResult.setMessage("图片上传失败");
        }
        return uploadResult;
    }
}
