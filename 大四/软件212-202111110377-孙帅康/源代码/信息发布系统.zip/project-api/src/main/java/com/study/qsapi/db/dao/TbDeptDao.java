package com.study.qsapi.db.dao;


import com.study.qsapi.db.pojo.TbDept;
import org.apache.ibatis.annotations.Mapper;

import java.util.ArrayList;
import java.util.HashMap;

@Mapper
public interface TbDeptDao {
    public ArrayList<HashMap> searchAllDept();
    public HashMap searchById(int id);

    //分页查询
    ArrayList<HashMap> listPageDept(HashMap map);
    //新增
    int insert(TbDept dept);
    //更新
    int update(TbDept dept);
    //是否可以删除
    public boolean searchCanDelete(Integer[] ids);
    //删除
    public int deleteDeptByIds(Integer[] ids);
}