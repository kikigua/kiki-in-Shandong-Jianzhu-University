package com.study.qsapi.db.dao;

import com.study.qsapi.db.pojo.CUser;
import org.apache.ibatis.annotations.Mapper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;

@Mapper
public interface CUserDao {
    public int deleteUserByIds(Integer[] ids);
    //分页查询
    public HashMap searchUserById(int userId); // 查询更新后的记录

    public int update(HashMap param);

    public int insert(CUser user);

    public ArrayList<HashMap> listPageUser(HashMap param);

    /**
     * 在StpInterfaceImpl中调用此方法,根据用户id查询其所有权限信息
     * @param userId
     * @return
     */
    public Set<String> searchUserPermissions(int userId);

    public HashMap searchById(int userId);
    public ArrayList<HashMap> searchUserByPage(HashMap param);

    public ArrayList<HashMap> searchAllUser();


}
