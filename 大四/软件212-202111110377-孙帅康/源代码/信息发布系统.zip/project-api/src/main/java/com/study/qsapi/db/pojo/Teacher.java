package com.study.qsapi.db.pojo;

import lombok.Data;

import java.util.Date;
@Data
public class Teacher {
    private Integer id;

    private String name;

    private String nickname;

    private String image;

    private Integer imageSize;

    private Integer positionId;

    private String motto;

    private String introduce;

    private Integer sort;

    private Date createdAt;

    private Date updatedAt;
}