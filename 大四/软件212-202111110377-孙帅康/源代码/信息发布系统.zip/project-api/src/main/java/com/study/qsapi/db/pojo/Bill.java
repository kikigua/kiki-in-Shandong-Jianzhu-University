package com.study.qsapi.db.pojo;

/**
 * user
 *
 * @author
 */
public class Bill {

}
