package com.study.qsapi.web;

import cn.dev33.satoken.annotation.SaCheckPermission;
import cn.dev33.satoken.annotation.SaMode;
import cn.hutool.json.JSONUtil;
import com.study.qsapi.db.pojo.TbDept;
import com.study.qsapi.service.DeptService;
import com.study.qsapi.util.PageUtil;
import com.study.qsapi.dto.R;
import com.study.qsapi.web.form.*;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cglib.beans.BeanCopier;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.HashMap;

@RestController
@RequestMapping("/dept")
@Tag(name = "DeptController", description = "部门Web接口")
public class DeptController {

    @Autowired
    private DeptService deptService;

    @GetMapping("/searchAllDept")
    @Operation(summary = "查询所有部门")
    public R searchAllDept() {
        ArrayList<HashMap> list = deptService.searchAllDept();
        return R.ok().put("list", list);
    }

    @PostMapping("/searchById")
    @Operation(summary = "根据ID查询部门")
    @SaCheckPermission(value = {"ROOT", "DEPT:SELECT"}, mode = SaMode.OR)
    public R searchById(@Valid @RequestBody SearchByIdForm form) {
        HashMap map = deptService.searchById(form.getId());
        return R.ok(map);
    }

    //分页查询
    @PostMapping("/searchDeptByPage")
    @Operation(summary = "分页查询部门")
    @SaCheckPermission(value = {"ROOT", "DEPT:SELECT"}, mode = SaMode.OR)
    public R searchDeptByPage(@Valid @RequestBody SearchDeptByPageForm form) {
        HashMap map=JSONUtil.parse(form).toBean(HashMap.class);//将form转成HashMap
        PageUtil pageUtil=deptService.searchDeptByPage(map);//调用service进行分页查询
        return R.ok().put("page", pageUtil); //返回分页数据
    }
    //新增

    @PostMapping("/insert")
    @Operation(summary = "新增部门")
    @SaCheckPermission(value = {"ROOT", "DEPT:INSERT"}, mode = SaMode.OR)
    public R insert(@Valid @RequestBody InsertDeptForm form){
        TbDept dept=JSONUtil.parse(form).toBean(TbDept.class);//转换成pojo
        int rows=deptService.insert(dept);//调用service完成新增,返回影响的行数
        return R.ok().put("rows", rows); //将rows返回给前端
    }
    //更新
    @PostMapping("/update")
    @Operation(summary = "更新部门")
    @SaCheckPermission(value = {"ROOT", "DEPT:UPDATE"}, mode = SaMode.OR)
    public R update(@Valid @RequestBody UpdateDeptForm form){
        TbDept dept=JSONUtil.parse(form).toBean(TbDept.class);//转换成pojo
        int rows=deptService.update(dept);//调用service完成新增,返回影响的行数
        return R.ok().put("rows", rows); //将rows返回给前端
    }
    //删除
    @PostMapping("/deleteDeptByIds")
    @Operation(summary = "删除部门")
    @SaCheckPermission(value = {"ROOT", "DEPT:DELETE"}, mode = SaMode.OR)
    public R delete(@Valid @RequestBody DeleteByIdsForm form){
        int rows = deptService.deleteDeptByIds(form.getIds());//调用service完成删除,返回影响的行数
        return R.ok().put("rows", rows); //将rows返回给前端
    }
}