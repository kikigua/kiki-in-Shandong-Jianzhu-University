package com.study.qsapi.web.form;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;

@Data
@Schema(description = "添加职务表单")
public class InsertCRoleForm {
    @NotBlank(message = "name不能为空")
    @Schema(description = "职务名称")
    private String name;

    @NotBlank(message = "status不能为空")
    @Schema(description = "状态")
    private String status;
}
