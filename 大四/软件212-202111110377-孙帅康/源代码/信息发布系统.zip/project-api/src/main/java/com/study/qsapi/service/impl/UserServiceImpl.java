package com.study.qsapi.service.impl;



import com.study.qsapi.db.dao.TbUserDao;
import com.study.qsapi.db.pojo.TbUser;
import com.study.qsapi.util.PageUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;
@Service
public class UserServiceImpl implements com.study.qsapi.service.UserService {
    @Autowired
    private RedisTemplate redisTemplate;
    @Autowired
    private TbUserDao userDao;
    @Override
    public int deleteUserByIds(Integer[] ids) {
        int rows = userDao.deleteUserByIds(ids);
        return rows;
    }
    @Override
    public HashMap searchUserById(int userId) {
        HashMap map = userDao.searchUserById(userId);
        return map;
    }
    @Override
    public int update(HashMap param) {
        int rows = userDao.update(param);
        return rows;
    }
    @Override
    public int insert(TbUser user) {
        int rows = userDao.insert(user);
        return rows;
    }
    @Override
    public PageUtil searchUserByPage(HashMap param) {
        ArrayList<HashMap> list = userDao.listPageUser(param);
        PageUtil pageUtils = new PageUtil(list, param);
        return pageUtils;
    }

    @Override
    public Set<String> searchUserPermissions(int userId) {
        Set<String> permissions = userDao.searchUserPermissions(userId);
        return permissions;
    }
    @Override
    public HashMap searchById(int userId) {
        HashMap map = userDao.searchById(userId);
        return map;
    }
    @Override
    public HashMap searchUserSummary(int userId) {
        HashMap map = userDao.searchUserSummary(userId);
        return map;
    }
    @Override
    public ArrayList<HashMap> searchAllUser() {
        ArrayList<HashMap> list = userDao.searchAllUser();
        return list;
    }

    //登录方法
    @Override
    public Integer login(HashMap map) {
        return userDao.login(map);
    }


    //修改密码

    @Override
    public Integer updatePassword(HashMap map) {
        return userDao.updatePassword(map);
    }
}
