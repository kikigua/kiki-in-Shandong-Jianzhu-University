package com.study.qsapi.web.form;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Data
@Schema(description = "更新教师表单")
public class UpdateTeacherForm {
    @NotNull(message = "id不能为空")
    @Schema(description = "教师ID")
    private Integer id;
    @NotBlank(message = "name不能为空")
    @Schema(description = "教师名称")
    private String name;
    @NotBlank(message = "nickname不能为空")
    @Schema(description = "教师昵称")
    private String nickname;
    @NotBlank(message = "image不能为空")
    @Schema(description = "教师头像")
    private String image;
    @NotNull(message = "imageSize不能为空")
    @Min(value = 1, message = "imageSize不能小于0")
    @Schema(description = "头像大小")
    private Integer imageSize;
    @NotNull(message = "positionId不能为空")
    @Schema(description = "职位id")
    private Integer positionId;
    @NotBlank(message = "motto不能为空")
    @Schema(description = "座右铭")
    private String motto;
    @NotBlank(message = "introduce不能为空")
    @Schema(description = "个人简介")
    private String introduce;
    @NotNull(message = "sort不能为空")
    @Schema(description = "顺序")
    private Integer sort;
}
