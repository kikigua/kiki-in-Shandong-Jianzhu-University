package com.study.qsapi.service.impl;

import com.study.qsapi.db.dao.TeacherMapper;
import com.study.qsapi.db.pojo.Teacher;
import com.study.qsapi.service.TeacherService;
import com.study.qsapi.util.PageUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.HashMap;
import java.util.List;

@Service
public class TeacherServiceImpl implements TeacherService {

    @Autowired
    private TeacherMapper teacherMapper;

    @Override
    public PageUtil listPageTeacher(HashMap map) {
        List<HashMap> list=teacherMapper.listPageTeacher(map);
        return new PageUtil(list, map);
    }

    @Override
    public int deleteByIds(Integer[] ids) {
        return teacherMapper.deleteByIds(ids);
    }

    @Override
    public int insertSelective(Teacher record) {
        record.setCreatedAt(new Date()); //设置创建时间
        record.setUpdatedAt(new Date()); //设置更新时间
        return teacherMapper.insertSelective(record);
    }

    @Override
    public Teacher selectById(Integer id) {
        return teacherMapper.selectByPrimaryKey(id);
    }

    @Override
    public int updateTeacher(Teacher record) {
        record.setUpdatedAt(new Date()); //设置更新时间
        return teacherMapper.updateByPrimaryKeySelective(record);
    }
}
