package com.study.qsapi.enums;

/**
 * 服务器端返回信息的枚举类型
 *
 */
public enum ResultEnum {

    SUCCESS(6666, "业务处理成功"),
    BUSINIESS_FAIL(7777, "业务处理失败");

    private Integer code;

    private String desc;

    ResultEnum(Integer code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getDesc() {
        return desc;
    }
}
