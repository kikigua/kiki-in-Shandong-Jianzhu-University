package com.study.qsapi.service.impl;

import com.study.qsapi.db.dao.PositionMapper;
import com.study.qsapi.db.pojo.Position;
import com.study.qsapi.service.PositionService;
import com.study.qsapi.util.PageUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.HashMap;
import java.util.List;

@Service //将类添加到Spring容器里
public class PositionServiceImpl implements PositionService {
    @Autowired
    private PositionMapper positionMapper;
    @Override
    public PageUtil listPagePosition(HashMap map) {
        List<HashMap> list=positionMapper.listPagePosition(map);
        PageUtil pageUtil=new PageUtil(list,map);//将返回的数据封装到PageUtil对象里
        return pageUtil;
    }

    @Override
    public int deleteByIds(Integer[] ids) {
        return positionMapper.deleteByIds(ids);
    }
    @Override
    public int insertPosition(Position position) {
        position.setCreatedAt(new Date());//设置创建时间
        position.setUpdatedAt(new Date());//设置最新更新时间
        return positionMapper.insertSelective(position);
    }

    @Override
    public Position selectById(Integer id) {
        return positionMapper.selectByPrimaryKey(id);
    }
    @Override
    public int updatePosition(Position position) {
        position.setUpdatedAt(new Date());//设置更新时间
        return positionMapper.updateByPrimaryKeySelective(position);
    }

    @Override
    public List<HashMap> listValidPosition() {
        return positionMapper.listValidPosition();
    }
}
