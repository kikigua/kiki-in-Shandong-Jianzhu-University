package com.study.qsapi.service;

import com.study.qsapi.db.pojo.CUser;
import com.study.qsapi.db.pojo.TbUser;
import com.study.qsapi.util.PageUtil;

import java.util.ArrayList;
import java.util.HashMap;

public interface CUserService {
    PageUtil ListPageUser(HashMap map);
    int deleteUserByIds(Integer[] ids);

    HashMap searchUserById(int userId);

    int update(HashMap param);

    int insert(CUser user);

    PageUtil searchUserByPage(HashMap param);

    HashMap searchById(int userId);

    ArrayList<HashMap> searchAllUser();
}
