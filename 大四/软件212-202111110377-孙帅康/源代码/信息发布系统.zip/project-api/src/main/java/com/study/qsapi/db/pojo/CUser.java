package com.study.qsapi.db.pojo;

import lombok.Data;

import java.util.Date;

/**
 * user
 *
 * @author
 */
@Data
public class CUser {
    /**
     * 主键
     */
    private Integer id;

    /**
     * 用户名
     */
    private String account;


    /**
     * 密码
     */
    private String password;

    /**
     * 昵称
     */
    private String nickname;


    /**
     * 姓名
     */
    private String name;

    /**
     * 性别
     */
    private String sex;

    /**
     * 手机号码
     */
    private String tel;

    /**
     * 身高
     */
    private String height;
    /**
     * 体重
     */
    private  String weight;
}
