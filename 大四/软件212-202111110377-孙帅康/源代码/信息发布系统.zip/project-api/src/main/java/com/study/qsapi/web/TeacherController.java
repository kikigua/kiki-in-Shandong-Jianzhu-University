package com.study.qsapi.web;

import cn.dev33.satoken.annotation.SaCheckPermission;
import cn.dev33.satoken.annotation.SaMode;
import cn.hutool.json.JSONUtil;
import com.study.qsapi.db.pojo.Teacher;
import com.study.qsapi.dto.R;
import com.study.qsapi.service.TeacherService;
import com.study.qsapi.util.PageUtil;
import com.study.qsapi.web.form.*;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.HashMap;

@RequestMapping("/teacher")
@RestController
@Tag(name = "TeacherController", description = "教师Web接口")
public class TeacherController {
    @Autowired
    private TeacherService teacherService;
    @PostMapping("/listPageTeacher")
    @Operation(summary = "教师分页查询")
    @SaCheckPermission(value = {"ROOT", "TEACHER:SELECT"}, mode = SaMode.OR)
    public R listPageTeacher(@Valid @RequestBody SearchTeacherByPageForm form){
        HashMap map= JSONUtil.parse(form).toBean(HashMap.class); //将form转成HashMap
        PageUtil pageUtil=teacherService.listPageTeacher(map);//调用service完成分页查询
        return R.ok().put("page",pageUtil);
    }

    @PostMapping("/delete")
    @Operation(summary = "教师批量删除")
    @SaCheckPermission(value = {"ROOT", "TEACHER:DELETE"}, mode = SaMode.OR)
    public R delete(@Valid @RequestBody DeleteByIdsForm form){
        int rows=teacherService.deleteByIds(form.getIds());
        return R.ok().put("rows",rows);
    }

    @PostMapping("/insert")
    @Operation(summary = "教师添加")
    @SaCheckPermission(value = {"ROOT", "TEACHER:INSERT"}, mode = SaMode.OR)
    public R insert(@Valid @RequestBody InsertTeacherForm form){
        Teacher teacher=JSONUtil.parse(form).toBean(Teacher.class); //将form转成Teacher对象
        int rows=teacherService.insertSelective(teacher);
        return R.ok().put("rows", rows);
    }

    @GetMapping("/selectById")
    @Operation(summary = "根据ID查询教师")
    @SaCheckPermission(value = {"ROOT", "TEACHER:SELECT"}, mode = SaMode.OR)
    public R selectById(@Valid SearchByIdForm form){
        Teacher teacher=teacherService.selectById(form.getId());
        return R.ok().put("teacher",teacher);
    }

    @PostMapping("/update")
    @Operation(summary = "教师更新")
    @SaCheckPermission(value = {"ROOT", "TEACHER:UPDATE"}, mode = SaMode.OR)
    public R update(@Valid @RequestBody UpdateTeacherForm form){
        Teacher teacher=JSONUtil.parse(form).toBean(Teacher.class); //将form转成Teacher对象
        int rows=teacherService.updateTeacher(teacher);
        return R.ok().put("rows", rows);
    }
}
