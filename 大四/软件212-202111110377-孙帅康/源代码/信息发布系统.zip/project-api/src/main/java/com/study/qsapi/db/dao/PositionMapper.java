package com.study.qsapi.db.dao;

import com.study.qsapi.db.pojo.Position;
import org.apache.ibatis.annotations.Mapper;

import java.util.HashMap;
import java.util.List;

@Mapper
public interface PositionMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(Position record);

    int insertSelective(Position record);

    Position selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(Position record);

    int updateByPrimaryKey(Position record);

    /**
     * 分页查询:
     * @param map
     * @return
     */
    List<HashMap> listPagePosition(HashMap map);

    /**
     * 批量删除
     * @param ids 要删除的id数组
     * @return
     */
    int deleteByIds(Integer[] ids);

    /**
     * 查询所有有效职位
     * @return
     */
    List<HashMap> listValidPosition();

}