package com.study.qsapi;

import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.EnableAsync;

import java.text.SimpleDateFormat;
import java.util.Date;

@SpringBootApplication
@ServletComponentScan
@Slf4j
@EnableAsync
public class ProjectApiApplication {
    private static final Logger LOG= LoggerFactory.getLogger(ProjectApiApplication.class);
    public static void main(String[] args) {
        SpringApplication app = new SpringApplication(ProjectApiApplication.class);
        Environment env = app.run(args).getEnvironment();
        LOG.info("启动成功！！");
        LOG.info("服务启动地址：\t http://127.0.0.1:{}", env.getProperty("server.port"));
        LOG.info("接口测试地址：\t http://localhost:{}/project-api/swagger-ui.html",env.getProperty("server.port"));
    }

}
