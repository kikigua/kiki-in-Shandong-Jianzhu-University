package com.study.qsapi.db.dao;


import com.study.qsapi.db.pojo.TbRole;
import org.apache.ibatis.annotations.Mapper;

import java.util.ArrayList;
import java.util.HashMap;


@Mapper
public interface TbRoleDao {
    /**
     * 查询所有角色,人员修改页面的角色下拉框加载此查询返回的数据
     * @return
     */
    public ArrayList<HashMap> searchAllRole();

    /**
     * 根据id查询某个角色,进入角色修改页面时调用此方法
     * @param id
     * @return
     */
    public HashMap searchById(int id);

    /**
     * 查询当前页的角色
     */
    public ArrayList<HashMap> listPageRole(HashMap param);

    /**
     * 添加新的角色
     * @param role
     * @return
     */
    public int insert(TbRole role);

    /**
     * 根据角色id查询此角色下的所有用户,然后将其踢下线
     * @param roleId
     * @return
     */
    public ArrayList<Integer> searchUserIdByRoleId(int roleId);

    /**
     * 更新角色
     * @param role
     * @return
     */
    public int update(TbRole role);

    /**
     * 查询更新后的数据,角色更新成功后,查出更新后的数据用于更新页面
     * @param id
     * @return
     */
    public HashMap searchUpdatedRoleById(int id);

    /**
     * 删除时,先调用此方法进行判断本次删除的记录是否都能删除
     * @param ids
     * @return
     */
    public boolean searchCanDelete(Integer[] ids);

    /**
     * 删除指定的所有记录
     * @param ids
     * @return
     */
    public int deleteRoleByIds(Integer[] ids);
}
