package com.study.qsapi.service;

import com.study.qsapi.db.pojo.Teacher;
import com.study.qsapi.util.PageUtil;

import java.util.HashMap;

public interface TeacherService{
    /**
     *
     * @param map
     * @return 分页对象
     */
    PageUtil listPageTeacher(HashMap map);
    /**
     * 批量删除
     * @param ids
     * @return
     */
    int deleteByIds(Integer[] ids);

    /**
     * 新增教师
     * @param record
     * @return
     */
    int insertSelective(Teacher record);


    /**
     * 根据主键查询
     * @param id
     * @return
     */
    Teacher selectById(Integer id);

    /**
     *
     * @param record
     * @return
     */
    int  updateTeacher(Teacher record);
}
