package com.study.qsapi.web;

import cn.dev33.satoken.annotation.SaCheckLogin;
import cn.dev33.satoken.annotation.SaCheckPermission;
import cn.dev33.satoken.annotation.SaMode;
import cn.dev33.satoken.stp.StpUtil;
import cn.hutool.core.util.ArrayUtil;
import cn.hutool.json.JSONUtil;

import com.study.qsapi.db.pojo.TbUser;
import com.study.qsapi.service.UserService;
import com.study.qsapi.util.PageUtil;
import com.study.qsapi.dto.R;
import com.study.qsapi.web.form.*;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Set;

@RestController
@RequestMapping("/user")
@Tag(name = "UserController", description = "用户Web接口")
public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping("/deleteUserByIds")
    @SaCheckPermission(value = {"ROOT", "USER:DELETE"}, mode = SaMode.OR)
    @Operation(summary = "删除用户")
    public R deleteUserByIds(@Valid @RequestBody DeleteByIdsForm form) {
        Integer userId = StpUtil.getLoginIdAsInt(); // 获得当前用户的id
        if (ArrayUtil.contains(form.getIds(), userId)) {
            return R.error("您不能删除自己的帐户");
        }
        int rows = userService.deleteUserByIds(form.getIds());
        if (rows > 0) {
            //把被删除的用户踢下线
            for (Integer id : form.getIds()) {
                StpUtil.logoutByLoginId(id);
            }
        }
        return R.ok().put("rows", rows);
    }

    @PostMapping("/update")
    @SaCheckPermission(value = {"ROOT", "USER:UPDATE"}, mode = SaMode.OR)
    @Operation(summary = "修改用户")
    public R update(@Valid @RequestBody UpdateUserForm form) {
        HashMap param = JSONUtil.parse(form).toBean(HashMap.class);
        param.replace("role", JSONUtil.parseArray(form.getRole()).toString());
        int rows = userService.update(param);
        R r=R.ok().put("rows", rows);
        if (rows == 1) {
            //修改资料后，把该用户踢下线
            StpUtil.logoutByLoginId(form.getUserId());
            HashMap map=userService.searchUserById(form.getUserId()); // 查询更新后的数据
            r.put("map",map);
        }


        return r;
    }

    @PostMapping("/insert")
    @SaCheckPermission(value = {"ROOT", "USER:INSERT"}, mode = SaMode.OR)
    @Operation(summary = "添加用户")
    public R insert(@Valid @RequestBody InsertUserForm form) {
        TbUser user = JSONUtil.parse(form).toBean(TbUser.class);
        user.setStatus((byte) 1);
        user.setRole(JSONUtil.parseArray(form.getRole()).toString());
        user.setCreateTime(new Date());
        int rows = userService.insert(user);
        return R.ok().put("rows", rows);
    }

    @PostMapping("/searchUserByPage")
    @Operation(summary = "查询用户分页记录")
    @SaCheckPermission(value = {"ROOT", "USER:SELECT"}, mode = SaMode.OR)
    public R searchUserByPage(@Valid @RequestBody SearchUserByPageForm form) {
        HashMap param = JSONUtil.parse(form).toBean(HashMap.class);
        PageUtil pageUtils = userService.searchUserByPage(param);
        return R.ok().put("page", pageUtils);
    }

//    /**
//     * 登陆成功后加载用户的基本信息
//     */
    @GetMapping("/loadUserInfo")
    @Operation(summary = "登陆成功后加载用户的基本信息")
    @SaCheckLogin
    public R loadUserInfo() {
        int userId = StpUtil.getLoginIdAsInt();//获取当前用户的id
        HashMap summary = userService.searchUserSummary(userId);
        return R.ok(summary);
    }

    @PostMapping("/searchById")
    @Operation(summary = "根据ID查找用户")
    @SaCheckPermission(value = {"ROOT", "USER:SELECT"}, mode = SaMode.OR)
    public R searchById(@Valid @RequestBody SearchByIdForm form) {
        HashMap map = userService.searchById(form.getId());
        return R.ok(map);
    }


    @GetMapping("/logout")
    @Operation(summary = "退出系统")
    public R logout(){
        StpUtil.logout();
        return R.ok();
    }

    @GetMapping("/searchAllUser")
    @Operation(summary = "查询所有用户")
    @SaCheckLogin
    public R searchAllUser() {
        ArrayList<HashMap> list = userService.searchAllUser();
        return R.ok().put("list", list);
    }

    //登录方法

    @PostMapping("/login")
    @Operation(summary = "用户登录")
    public R login(@Valid @RequestBody LoginForm form){
        HashMap map=JSONUtil.parse(form).toBean(HashMap.class);//将form的数据转成map
        Integer userId=userService.login(map);//调用Service完成登录验证
        R r=R.ok();
        r.put("result",userId!=null?true:false);//添加登录是否成功的信息
        if(userId!=null){ //登录成功
            //调用sa-token提供的方法,此方法会根据userId产生token并将其存入redis,并会将其以cookie的方式返回给客户端
            StpUtil.login(userId);
            Set<String> permissions=userService.searchUserPermissions(userId);//查出登录的权限信息
            r.put("permissions", permissions);//将权限信息存入r对象
        }
        return r;
    }

    //修改密码
    @PostMapping("/updatePassword")
    @SaCheckLogin
    @Operation(summary = "密码修改")
    public R updatePassword(@Valid @RequestBody UpdatePasswordForm form){
        Integer userId=StpUtil.getLoginIdAsInt();//获取当前登录用户的id
        HashMap map=new HashMap();//准备参数
        map.put("userId", userId);//这里的key值要与mybatis映射文件中的参数名一致
        map.put("password", form.getPassword());
        int rows=userService.updatePassword(map);//调用Service完成密码修改,返回此操作影响的行数
        return R.ok().put("rows", rows);
    }
}

