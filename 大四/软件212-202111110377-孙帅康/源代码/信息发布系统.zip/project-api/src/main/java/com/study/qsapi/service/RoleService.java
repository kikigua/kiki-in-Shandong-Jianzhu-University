package com.study.qsapi.service;

import com.study.qsapi.db.pojo.TbRole;
import com.study.qsapi.util.PageUtil;

import java.util.ArrayList;
import java.util.HashMap;

public interface RoleService {
    ArrayList<HashMap> searchAllRole();

    HashMap searchById(int id);

    PageUtil searchRoleByPage(HashMap param);

    int insert(TbRole role);

    ArrayList<Integer> searchUserIdByRoleId(int roleId);

    int update(TbRole role);

    HashMap searchUpdatedRoleById(int id);

    int deleteRoleByIds(Integer[] ids);
}
