package com.study.qsapi.service.impl;

import com.study.qsapi.db.dao.CUserDao;
import com.study.qsapi.db.pojo.CUser;
import com.study.qsapi.db.pojo.TbUser;
import com.study.qsapi.util.PageUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

@Service
public class CUserServiceImpl implements com.study.qsapi.service.CUserService {

    @Autowired
    private CUserDao cUserDao;

    @Override
    public PageUtil ListPageUser(HashMap map) {
        return null;
    }

    @Override
    public int deleteUserByIds(Integer[] ids) {//根据id删除用户
        int rows = cUserDao.deleteUserByIds(ids);
        return rows;

    }
    @Override
    public HashMap searchUserById(int userId) {//根据id查询用户
        HashMap map = cUserDao.searchUserById(userId);
        return map;
    }
    @Override
    public int update(HashMap param) {//更新用户
        int rows = cUserDao.update(param);
        return rows;
    }



    @Override
    public int insert(CUser user) {//插入用户
        int rows = cUserDao.insert(user);
        return rows;
    }
    @Override
    public PageUtil searchUserByPage(HashMap param) {//查询用户分页记录
        ArrayList<HashMap> list = cUserDao.listPageUser(param);
        PageUtil pageUtils = new PageUtil(list, param);
        return pageUtils;
    }



    @Override
    public HashMap searchById(int userId) {//根据用户查找id
        HashMap map = cUserDao.searchById(userId);
        return map;
    }

    @Override
    public ArrayList<HashMap> searchAllUser() {//查询所有用户
        ArrayList<HashMap> list = cUserDao.searchAllUser();
        return list;
    }


}
