package com.study.qsapi.db.dao;


import com.study.qsapi.db.pojo.TbUser;
import org.apache.ibatis.annotations.Mapper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;

@Mapper
public interface TbUserDao {
    public int deleteUserByIds(Integer[] ids);

    public HashMap searchUserById(int userId); // 查询更新后的记录

    public int update(HashMap param);

    public int insert(TbUser user);

    public ArrayList<HashMap> listPageUser(HashMap param);



    /**
     * 在StpInterfaceImpl中调用此方法,根据用户id查询其所有权限信息
     * @param userId
     * @return
     */
    public Set<String> searchUserPermissions(int userId);

    public HashMap searchById(int userId);


    public HashMap searchUserSummary(int userId);

    public HashMap searchUserInfo(int userId);

    public ArrayList<HashMap> searchUserByPage(HashMap param);

    public long searchUserCount(HashMap param);

    public Integer searchIdByOpenId(String openId);

    public Integer searchDeptManagerId(int id);

    public Integer searchGmId();

    public ArrayList<HashMap> searchAllUser();

    //登录方法

    public Integer login(HashMap map);

    //修改密码
    public Integer updatePassword(HashMap map);
}