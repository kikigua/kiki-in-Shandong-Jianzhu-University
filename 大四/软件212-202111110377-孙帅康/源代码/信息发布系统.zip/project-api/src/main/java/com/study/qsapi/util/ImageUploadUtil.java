package com.study.qsapi.util;

import com.google.gson.Gson;
import com.qiniu.common.QiniuException;
import com.qiniu.common.Zone;
import com.qiniu.http.Response;
import com.qiniu.storage.UploadManager;
import com.qiniu.storage.model.DefaultPutRet;
import com.qiniu.util.Auth;
import com.qiniu.storage.Configuration;
import com.study.qsapi.config.QiNiuConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;

@Component
public class ImageUploadUtil {

    @Autowired
    private QiNiuConfig qiNiuConfig;

    /**
     * 获取前端上传的Token
     * @param fileName
     * @return
     * @throws IOException
     */
    public String getToken(String fileName) {
        Auth auth = Auth.create(qiNiuConfig.getAccessKey(), qiNiuConfig.getSecretKey());
        String upToken;
        //upToken = auth.uploadToken(qiNiuConfig.getBucket());//简单上传凭证,这种凭证上传同名文件会失败
        upToken = auth.uploadToken(qiNiuConfig.getBucket(), fileName);//覆盖上传凭证
        return upToken;
    }

    /**
     * 上传MultipartFile 到七牛云服务器，自己的七牛云
     * @param dir: 七牛云bucket下的目录
     * @param file
     * @return
     * @throws IOException
     */
    public String uploadImageToQiNiu(String dir, MultipartFile file) {
        String filename = file.getOriginalFilename();
        String fullName = dir + filename;
        //构造一个带指定Zone对象的配置类
        Configuration cfg = new Configuration(Zone.zone2());
        //...其他参数参考类注释
        UploadManager uploadManager = new UploadManager(cfg);
        //把文件转化为字节数组
        InputStream is = null;
        ByteArrayOutputStream bos = null;
        try {
            is = file.getInputStream();
            bos = new ByteArrayOutputStream();
            byte[] b = new byte[1024];
            int len = -1;
            while ((len = is.read(b)) != -1){
                bos.write(b, 0, len);
            }
            byte[] uploadBytes= bos.toByteArray();
            Auth auth = Auth.create(qiNiuConfig.getAccessKey(), qiNiuConfig.getSecretKey());
            String upToken;
            //upToken = auth.uploadToken(qiNiuConfig.getBucket());//简单上传凭证,这种凭证上传同名文件会失败
            upToken = auth.uploadToken(qiNiuConfig.getBucket(), fullName);//覆盖上传凭证,带文件名的上传凭证,同名文件会覆盖
            //默认上传接口回复对象
            DefaultPutRet putRet;
            //进行上传操作，传入文件的字节数组，文件名，上传空间，得到回复对象
            Response response = uploadManager.put(uploadBytes, fullName, upToken);
            putRet = new Gson().fromJson(response.bodyString(), DefaultPutRet.class);
            System.out.println(putRet.key);//key 文件名
            System.out.println(putRet.hash);//hash 七牛返回的文件存储的地址，可以使用这个地址加七牛给你提供的前缀访问到这个视频。
            return qiNiuConfig.getEndpoint()+qiNiuConfig.getDomainOfBucket()+"/"+fullName;
        }catch (QiniuException e){
            e.printStackTrace();
        }catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 上传MultipartFile 到七牛云服务器，企业的七牛云
     * @param file
     * @param prefix
     * @return
     * @throws IOException
     */
//    public String uploadImageToQiNiu(String prefix, MultipartFile file) {
//        String filename = file.getOriginalFilename();
//        String resourceName = prefix+filename;
//        //构造一个带指定Zone对象的配置类
//        Configuration cfg = new Configuration(Zone.zone2());
//        //...其他参数参考类注释
//        UploadManager uploadManager = new UploadManager(cfg);
//        //把文件转化为字节数组
//        InputStream is = null;
//        ByteArrayOutputStream bos = null;
//        try {
//            is = file.getInputStream();
//            bos = new ByteArrayOutputStream();
//            byte[] b = new byte[1024];
//            int len = -1;
//            while ((len = is.read(b)) != -1){
//                bos.write(b, 0, len);
//            }
//            byte[] uploadBytes= bos.toByteArray();
//
//            Auth auth = Auth.create(qiNiuConfig.getAccessKey(), qiNiuConfig.getSecretKey());
//            String upToken;
//            upToken = auth.uploadToken(qiNiuConfig.getBucket(), resourceName);//覆盖上传凭证
//            //默认上传接口回复对象
//            DefaultPutRet putRet;
//            //进行上传操作，传入文件的字节数组，文件名，上传空间，得到回复对象
//            Response response = uploadManager.put(uploadBytes, resourceName, upToken);
//            putRet = new Gson().fromJson(response.bodyString(), DefaultPutRet.class);
//            System.out.println(putRet.key);//key 文件名
//            System.out.println(putRet.hash);//hash 七牛返回的文件存储的地址，可以使用这个地址加七牛给你提供的前缀访问到这个视频。
//            return qiNiuConfig.getEndpoint()+qiNiuConfig.getDomainOfBucket()+"/"+resourceName;
//        }catch (QiniuException e){
//            e.printStackTrace();
//        }catch (IOException e) {
//            e.printStackTrace();
//        }
//        return null;
//    }

      //上传到minio图片服务器
//    @Value("${minio.endpoint}")
//    private  String ENDPOINT;
//    @Value("${minio.bucketName}")
//    private  String BUCKETNAME;
//    @Value("${minio.accessKey}")
//    private  String ACCESSKEY;
//    @Value("${minio.secretKey}")
//    private  String SECRETKEY;

    /**
     * 将图片上传到Minio图片服务器
     * @param prefix
     * @param uploadFile
     * @return
     */
//    public String uploadImageToQiNiu(String prefix, MultipartFile uploadFile){
//        String filename = uploadFile.getOriginalFilename();
//        String resourceName = prefix+"-"+filename;
//        MinioClient minioClient = null; // 连接
//        try(InputStream inputStream = uploadFile.getInputStream();) {
//            minioClient = MinioClient.builder()
//                    .endpoint(ENDPOINT)
//                    .credentials(ACCESSKEY, SECRETKEY)
//                    .build();
//            if (!minioClient.bucketExists(BucketExistsArgs.builder().bucket(BUCKETNAME).build())) { // 是否存在名为"XXX"的bucket
//                minioClient.makeBucket(MakeBucketArgs.builder().bucket(BUCKETNAME).build());
//            }
//            // 存储文件
//            minioClient.putObject(PutObjectArgs.builder()
//                    .bucket(BUCKETNAME)
//                    .object(resourceName)
//                    .stream(inputStream, inputStream.available(), -1)
//                    .contentType(uploadFile.getContentType())
//                    .build()
//            );
//            //以下的方式获取的url中有大量参数信息，较冗余
////            String url = minioClient.getPresignedObjectUrl(
////                    GetPresignedObjectUrlArgs.builder()
////                            .method(Method.GET)
////                            .bucket(BUCKETNAME)
////                            .object(resourceName)
////                            .build());
//            //使用minio客户端工具mc.exe，将bucket的访问权限设置为public,可以直接访问bucket中的图片
//            return ENDPOINT+"/"+BUCKETNAME+"/"+resourceName;
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//        }
//        return null;
//    }

    /**
     * 根据字节数返回长度字符串
     * @param size
     * @return
     */
    public String getFileSize(long size) {
        double length = size;
        //如果字节数少于1024，则直接以B为单位，否则先除于1024，后3位因太少无意义
        if (length < 1024) {
            return length + "B";
        } else {
            length = length / 1024.0;
        }
        //如果原字节数除于1024之后，少于1024，则可以直接以KB作为单位
        //因为还没有到达要使用另一个单位的时候
        //接下去以此类推
        if (length < 1024) {
            return Math.round(length * 100) / 100.0 + "KB";
        } else {
            length = length / 1024.0;
        }
        if (length < 1024) {
            //因为如果以MB为单位的话，要保留最后1位小数，
            //因此，把此数乘以100之后再取余
            return Math.round(length * 100) / 100.0 + "MB";
        } else {
            //否则如果要以GB为单位的，先除于1024再作同样的处理
            return Math.round(length / 1024 * 100) / 100.0 + "GB";
        }
    }

}
