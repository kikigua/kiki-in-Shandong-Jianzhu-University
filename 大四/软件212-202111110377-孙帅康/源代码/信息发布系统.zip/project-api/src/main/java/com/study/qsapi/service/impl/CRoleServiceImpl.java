package com.study.qsapi.service.impl;

import com.study.qsapi.db.dao.CroleDao;

import com.study.qsapi.db.pojo.CRole;

import com.study.qsapi.service.CRoleService;
import com.study.qsapi.service.PositionService;
import com.study.qsapi.util.PageUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.HashMap;
import java.util.List;

@Service
public class CRoleServiceImpl implements CRoleService {
    @Autowired
    private CroleDao croleDao;
   @Override
    public PageUtil listPagePosition(HashMap map) {
        List<HashMap> list=croleDao.listPagePosition(map);
        PageUtil pageUtil=new PageUtil(list,map);//将返回的数据封装到PageUtil对象里
        return pageUtil;
    }

    @Override
    public int deleteByIds(Integer[] ids) {
        return croleDao.deleteByIds(ids);
    }
    @Override
    public int insertPosition(CRole cRole) {
        cRole.setCreatedAt(new Date());//设置创建时间
        cRole.setUpdatedAt(new Date());//设置最新更新时间
        return croleDao.insertSelective(cRole);
    }

    @Override
    public CRole selectById(Integer id) {
        return croleDao.selectByPrimaryKey(id);
    }
    @Override
    public int updatePosition(CRole cRole) {
        cRole.setUpdatedAt(new Date());//设置更新时间
        return croleDao.updateByPrimaryKeySelective(cRole);
    }

    @Override
    public List<HashMap> listValidPosition() {
        return croleDao.listValidPosition();
    }

}
