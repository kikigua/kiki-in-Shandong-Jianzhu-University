package com.study.qsapi.web;

import cn.dev33.satoken.annotation.SaCheckLogin;
import cn.dev33.satoken.annotation.SaCheckPermission;
import cn.dev33.satoken.annotation.SaMode;
import cn.dev33.satoken.stp.StpUtil;
import cn.hutool.core.util.ArrayUtil;
import cn.hutool.json.JSONUtil;
import com.study.qsapi.db.pojo.CUser;
import com.study.qsapi.db.pojo.TbUser;
import com.study.qsapi.dto.R;
import com.study.qsapi.service.CUserService;
import com.study.qsapi.util.PageUtil;
import com.study.qsapi.web.form.*;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

@RestController
@RequestMapping("/cuser")
@Tag(name = "CUserController", description = "私教用户Web接口")
public class CUserController {

    @Autowired
    private CUserService cUserSerive;

    @PostMapping("/deleteUserByIds")
    @SaCheckPermission(value = {"ROOT", "CUSER:DELETE"}, mode = SaMode.OR)
    @Operation(summary = "删除用户")
    public R deleteUserByIds(@Valid @RequestBody DeleteByIdsForm form) {
        Integer userId = StpUtil.getLoginIdAsInt(); // 获得当前用户的id

        int rows = cUserSerive.deleteUserByIds(form.getIds());
        if (rows > 0) {
            //把被删除的用户踢下线
            for (Integer id : form.getIds()) {
                StpUtil.logoutByLoginId(id);
            }
        }
        return R.ok().put("rows", rows);
    }

    @PostMapping("/update")
    @SaCheckPermission(value = {"ROOT", "CUSER:UPDATE"}, mode = SaMode.OR)
    @Operation(summary = "修改用户")
    public R update(@Valid @RequestBody UpdateCuserForm form) {
        HashMap param = JSONUtil.parse(form).toBean(HashMap.class);
//        param.replace("role", JSONUtil.parseArray(form.getRole()).toString());
        int rows = cUserSerive.update(param);
        R r= R.ok().put("rows", rows);
        if (rows == 1) {
            //修改资料后，把该用户踢下线
            StpUtil.logoutByLoginId(form.getUserId());
            HashMap map=cUserSerive.searchUserById(form.getUserId()); // 查询更新后的数据
            r.put("map",map);
        }


        return r;
    }

    @PostMapping("/insert")
    @SaCheckPermission(value = {"ROOT", "CUSER:INSERT"}, mode = SaMode.OR)
    @Operation(summary = "添加用户")
    public R insert(@Valid @RequestBody InsertCUserForm form) {
        CUser user = JSONUtil.parse(form).toBean(CUser.class);
     //   user.setStatus((byte) 1);
//        user.setRole(JSONUtil.parseArray(form.getRole()).toString());
      //  user.setCreateTime(new Date());
        int rows = cUserSerive.insert(user);
        return R.ok().put("rows", rows);
    }

    @PostMapping("/searchUserByPage")
    @Operation(summary = "查询用户分页记录")
    @SaCheckPermission(value = {"ROOT", "CUSER:SELECT"}, mode = SaMode.OR)
    public R searchUserByPage(@Valid @RequestBody SearchCUserByPageForm form) {
        HashMap param = JSONUtil.parse(form).toBean(HashMap.class);
        PageUtil pageUtils = cUserSerive.searchUserByPage(param);
        System.out.println("你哈"+ pageUtils);
        return R.ok().put("page", pageUtils);

    }

//    //    /**
////     * 登陆成功后加载用户的基本信息
////     */
//    @GetMapping("/loadUserInfo")
//    @Operation(summary = "登陆成功后加载用户的基本信息")
//    @SaCheckLogin
//    public R loadUserInfo() {
//        int userId = StpUtil.getLoginIdAsInt();//获取当前用户的id
//        HashMap summary = userService.searchUserSummary(userId);
//        return R.ok(summary);
//    }

    @PostMapping("/searchById")
    @Operation(summary = "根据ID查找用户")
    @SaCheckPermission(value = {"ROOT", "CUSER:SELECT"}, mode = SaMode.OR)
    public R searchById(@Valid @RequestBody SearchByIdForm form) {
        HashMap map = cUserSerive.searchById(form.getId());
        return R.ok(map);
    }


//    @GetMapping("/logout")
//    @Operation(summary = "退出系统")
//    public R logout(){
//        StpUtil.logout();
//        return R.ok();
//    }

    @GetMapping("/searchAllUser")
    @Operation(summary = "查询所有用户")
    @SaCheckLogin
    public R searchAllUser() {
        ArrayList<HashMap> list = cUserSerive.searchAllUser();
        return R.ok().put("list", list);
    }

//    //登录方法
//    @PostMapping("/login")
//    @Operation(summary = "登录系统")
//    public R login(@Valid @RequestBody LoginForm form){//将数据封装到form表单里进行校验
//        //将form的数据转成param
//        HashMap param= JSONUtil.parse(form).toBean(HashMap.class);
//        //调用service完成登录验证，将Param传进去，返回的是id
//        Integer userId=userService.login(param);
//        R r=R.ok().put("result", userId!=null?true:false);//添加登录是否成功的信息
//        if(userId!=null){//登录成功
//            StpUtil.login(userId);//标记当前会话登录的用户id
//            //查出所有权限信息
//            Set<String> permissions=userService.searchUserPermissions(userId);
//            r.put("permissions", permissions);
//        }
//        return r;
//    }
//    //修改密码
//    @PostMapping("/updatePassword")
//    @SaCheckLogin
//    @Operation(summary = "修改密码")
//    public R updatePassword(@Valid @RequestBody UpdatePasswordForm form){
//        int userId = StpUtil.getLoginIdAsInt();
//        HashMap param = new HashMap(){{
//            put("userId", userId);
//            put("password", form.getPassword());
//        }};
//        int rows = userService.updatePassword(param);
//        return R.ok().put("rows", rows);
//    }
}
