package com.study.qsapi.service;

import com.study.qsapi.db.pojo.TbDept;
import com.study.qsapi.util.PageUtil;

import java.util.ArrayList;
import java.util.HashMap;

public interface DeptService {
    ArrayList<HashMap> searchAllDept();

    HashMap searchById(int id);

    //分页查询,返回分页对象,PageUtil
    PageUtil searchDeptByPage(HashMap map);
    //新增
    int insert(TbDept dept);
    //更新
    int update(TbDept dept);
    //删除
    public int deleteDeptByIds(Integer[] ids);
}
