package com.study.qsapi.service.impl;

import com.study.qsapi.db.dao.TbPermissionDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
@Service
public class PermissionServiceImpl implements com.study.qsapi.service.PermissionService {
    @Autowired
    private TbPermissionDao permissionDao;


    @Override
    public ArrayList<HashMap> searchAllPermission() {
        ArrayList<HashMap> list = permissionDao.searchAllPermission();
        return list;
    }
}
