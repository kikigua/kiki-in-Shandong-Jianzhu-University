package com.study.qsapi.db.dao;

import com.study.qsapi.db.pojo.CRole;

import com.study.qsapi.db.pojo.CRole;
import org.apache.ibatis.annotations.Mapper;

import java.util.HashMap;
import java.util.List;

@Mapper
public interface CroleDao {
    int deleteByPrimaryKey(Integer id);

    int insert(CRole crole);

    int insertSelective(CRole record);

    CRole selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(CRole record);

    int updatePosition(CRole record);

    /**
     * 分页查询:
     * @param map
     * @return
     */
    List<HashMap> listPagePosition(HashMap map);

    /**
     * 批量删除
     * @param ids 要删除的id数组
     * @return
     */
    int deleteByIds(Integer[] ids);

    /**
     * 查询所有有效职位
     * @return
     */
    List<HashMap> listValidPosition();
}
