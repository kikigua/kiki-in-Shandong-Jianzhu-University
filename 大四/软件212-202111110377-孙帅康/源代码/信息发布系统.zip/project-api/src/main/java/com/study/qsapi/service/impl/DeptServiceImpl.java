package com.study.qsapi.service.impl;



import com.study.qsapi.db.dao.TbDeptDao;
import com.study.qsapi.db.pojo.TbDept;
import com.study.qsapi.exception.ProjectException;
import com.study.qsapi.util.PageUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

@Service
public class DeptServiceImpl implements com.study.qsapi.service.DeptService {
    @Autowired
    private TbDeptDao deptDao;

    @Override
    public ArrayList<HashMap> searchAllDept() {
        ArrayList<HashMap> list = deptDao.searchAllDept();
        return list;
    }

    @Override
    public HashMap searchById(int id) {
        HashMap map = deptDao.searchById(id);
        return map;
    }

    //分页查询

    @Override
    public PageUtil searchDeptByPage(HashMap map) {
        List<HashMap> list=deptDao.listPageDept(map);
        return new PageUtil(list,map);
    }

    //新增

    @Override
    public int insert(TbDept dept) {
        return deptDao.insert(dept);
    }

    //更新
    @Override
    public int update(TbDept dept) {
        return deptDao.update(dept);
    }

    //删除
    @Transactional(rollbackFor = Exception.class) //表示此方法运行在事务中
    public int deleteDeptByIds(Integer[] ids) {
        if(!deptDao.searchCanDelete(ids)){
            throw new ProjectException("有员工属于该部门,不能删除");
        }
        return deptDao.deleteDeptByIds(ids);
    }
}
