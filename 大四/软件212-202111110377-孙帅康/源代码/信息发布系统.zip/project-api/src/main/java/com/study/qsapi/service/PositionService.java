package com.study.qsapi.service;

import com.study.qsapi.db.pojo.Position;
import com.study.qsapi.util.PageUtil;

import java.util.HashMap;
import java.util.List;

public interface PositionService {
    /**
     * 分页查询:
     * @param map
     * @return 分页对象
     */
    PageUtil listPagePosition(HashMap map);

    /**
     * 批量删除
     * @param ids 要删除的id数组
     * @return
     */
    int deleteByIds(Integer[] ids);

    /**
     * 新增职务
     * @param position
     * @return
     */
    int insertPosition(Position position);

    /**
     * 根据ID查询职务信息
     * @param id
     * @return
     */
    Position selectById(Integer id);

    /**
     * 根据ID更新职务信息
     * @param position
     * @return
     */
    int updatePosition(Position position);
    /**
     * 查询所有有效职位
     * @return
     */
    List<HashMap> listValidPosition();
}
