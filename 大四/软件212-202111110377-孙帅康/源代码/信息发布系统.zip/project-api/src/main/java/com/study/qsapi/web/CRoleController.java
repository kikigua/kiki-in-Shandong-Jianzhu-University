package com.study.qsapi.web;

import cn.dev33.satoken.annotation.SaCheckPermission;
import cn.dev33.satoken.annotation.SaMode;
import cn.hutool.json.JSONUtil;
import com.study.qsapi.db.pojo.CRole;
import com.study.qsapi.dto.R;
import com.study.qsapi.service.CRoleService;
import com.study.qsapi.util.PageUtil;
import com.study.qsapi.web.form.*;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.HashMap;

@RestController
@RequestMapping("/crole")
@Tag(name = "CRoleController", description = "私教角色Web接口")
public class CRoleController {
    @Autowired
    private CRoleService cRoleService;
    @PostMapping("/listPagePostion")
    @Operation(summary = "职务分页查询")
    @SaCheckPermission(value = {"ROOT", "POSITION:SELECT"}, mode = SaMode.OR)
    public R listPagePostion(@Valid @RequestBody SearchCRoleByPageForm form){
        HashMap map= JSONUtil.parse(form).toBean(HashMap.class); //将form转成HashMap
        PageUtil pageUtil=cRoleService.listPagePosition(map);//调用service完成分页查询
        return R.ok().put("page",pageUtil);
    }

    @PostMapping("/delete")
    @Operation(summary = "职务删除")
    @SaCheckPermission(value = {"ROOT", "POSITION:DELETE"}, mode = SaMode.OR)
    public R deleteByIds(@Valid @RequestBody DeleteByIdsForm form){
        int rows=cRoleService.deleteByIds(form.getIds());
        return R.ok().put("rows",rows);
    }

    @PostMapping("/insert")
    @Operation(summary = "职务添加")
    @SaCheckPermission(value = {"ROOT", "POSITION:INSERT"}, mode = SaMode.OR)
    public R insert(@Valid @RequestBody InsertCRoleForm form){
        CRole cRole=JSONUtil.parse(form).toBean(CRole.class); //form转成对象
        int rows = cRoleService.insertPosition(cRole);//添加数据
        return R.ok().put("rows", rows);
    }

    @PostMapping("/selectById")
    @Operation(summary = "根据ID查询职务")
    @SaCheckPermission(value = {"ROOT", "POSITION:SELECT"}, mode = SaMode.OR)
    public R selectById(@Valid @RequestBody SearchByIdForm form){
        CRole cRole=cRoleService.selectById(form.getId());
        return R.ok().put("position",cRole);
    }

    @PostMapping("/update")
    @Operation(summary = "职务更新")
    @SaCheckPermission(value = {"ROOT", "POSITION:UPDATE"}, mode = SaMode.OR)
    public R update(@Valid @RequestBody UpdatePositionForm form){
        CRole cRole=JSONUtil.parse(form).toBean(CRole.class); //form转成对象
        int rows = cRoleService.updatePosition(cRole);//更新数据
        return R.ok().put("rows", rows);
    }

    @RequestMapping(value="/listValidPosition", method={ RequestMethod.POST, RequestMethod.GET })
    @Operation(summary = "查询所有有效职位")
    @SaCheckPermission(value = {"ROOT", "POSITION:SELECT"}, mode = SaMode.OR)
    public R listValidPosition(){
        return R.ok().put("list",cRoleService.listValidPosition());
    }
}
