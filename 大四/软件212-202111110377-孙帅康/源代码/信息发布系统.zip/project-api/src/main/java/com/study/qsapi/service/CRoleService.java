package com.study.qsapi.service;

import com.study.qsapi.db.pojo.CRole;
import com.study.qsapi.db.pojo.CUser;
import com.study.qsapi.db.pojo.Position;
import com.study.qsapi.util.PageUtil;

import java.util.HashMap;
import java.util.List;

public interface CRoleService {
    /**
     * 分页查询:
     * @param map
     * @return 分页对象
     */
    PageUtil listPagePosition(HashMap map);

    /**
     * 批量删除
     * @param ids 要删除的id数组
     * @return
     */
    int deleteByIds(Integer[] ids);

    /**
     * 新增职务
     * @param cRole
     * @return
     */
    int insertPosition(CRole cRole);
    /**
     * 根据ID查询职务信息
     * @param id
     * @return
     */
    CRole selectById(Integer id);

    /**
     * 根据ID更新职务信息
     * @param cRole
     * @return
     */
    int updatePosition(CRole cRole);
    /**
     * 查询所有有效职位
     * @return
     */
    List<HashMap> listValidPosition();

}
