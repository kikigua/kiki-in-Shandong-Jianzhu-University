package com.study.qsapi.db.dao;

import com.study.qsapi.db.pojo.Teacher;
import org.apache.ibatis.annotations.Mapper;

import java.util.HashMap;
import java.util.List;

@Mapper
public interface TeacherMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(Teacher record);

    int insertSelective(Teacher record);

    Teacher selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(Teacher record);

    int updateByPrimaryKey(Teacher record);

    /**
     *
     * @param map
     * @return
     */
    List<HashMap> listPageTeacher(HashMap map);

    /**
     * 批量删除
     * @param ids
     * @return
     */
    int deleteByIds(Integer[] ids);
}