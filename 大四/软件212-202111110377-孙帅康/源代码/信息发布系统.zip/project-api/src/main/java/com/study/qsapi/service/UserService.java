package com.study.qsapi.service;

import com.study.qsapi.db.pojo.TbUser;
import com.study.qsapi.util.PageUtil;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;

public interface UserService {
    int deleteUserByIds(Integer[] ids);

    HashMap searchUserById(int userId);

    int update(HashMap param);

    int insert(TbUser user);

    PageUtil searchUserByPage(HashMap param);

    Set<String> searchUserPermissions(int userId);

    HashMap searchById(int userId);

    HashMap searchUserSummary(int userId);

    ArrayList<HashMap> searchAllUser();

    //登录方法
    Integer login(HashMap map);

    //修改密码
    public Integer updatePassword(HashMap map);
}
