import {
	createRouter,
	createWebHistory,
	createWebHashHistory
}
from 'vue-router'
import Login from '../views/login.vue'
//import Linechart from '../views/stat/linechart.vue'
import NotFound from "../views/404.vue"


const routes = [
	{
	  path: '/', // 默认路由
	  name: 'Index',
	  redirect: '/login' // 重定向到登录页面
	},
	{
		path: '/login',
		name: 'Login',
		component: Login
	},
	{
		path: '/main',
		name: 'Main',
    component: () => import('../views/main.vue'),
		redirect: '/home', // 设置home中的<router-view></router-view>的默认路由
		children: [
			{
				path: '/home',
				name: 'Home',
        component: () => import('../views/home.vue'),
				meta: {
					title: '首页',
				}
			},
			{
				path: '/user',
				name: 'User',
        component: () => import('../views/user.vue'),
				meta: {
					title: '用户管理',
					isTab: true
				}
			},
			{
				path: '/dept',
				name: 'Dept',
        component: () => import('../views/dept.vue'),
				meta: {
					title: '部门管理',
					isTab: true
				}
			},
			{
				path: "/role",
				name: "Role",
        component: () => import('../views/role.vue'),
				meta: {
					title: "角色管理",
					isTab: true
				}
			},
			{
			path: "/cuser",
					name: "Cuser",
			component: () => import('../views/cuser.vue'),
					meta: {
						title: "个人信息",
						isTab: true
					}	
			},{
				path: "/crole",
						name: "CRole",
				component: () => import('../views/crole.vue'),
						meta: {
							title: "身份管理",
							isTab: true
						}
			}
		]
	},
	{
		path: "/404",
		name: "NotFound",
		component: NotFound
	},
	{
		path: '/:pathMatch(.*)*',
		redirect: "/404"
	}
]

const router = createRouter({
  base:"/",
	history: createWebHashHistory(),
	//history: createWebHistory(),
	routes
})

//路由在进入页面时要做的事
router.beforeEach((to, from, next) => {
	if (to.name != "Login") { // 不是登录页面
		let permissions = localStorage.getItem("permissions")
		let token = localStorage.getItem("token")
		let avtivity_time =parseInt(localStorage.getItem("activity_time"));
		let now_time = parseInt(new Date().getTime()/1000);
		if((now_time - avtivity_time)>60*60 && !isNaN(avtivity_time)){//判断是否超过60分钟没有请求
			localStorage.removeItem("activity_time")
			next({ name: 'Login' }) // 进入登录页面
		}else{
			if (permissions == null || permissions == ""||token == null || token == "") { // 未登录
				next({ name: 'Login' }) // 进入登录页面
			} else {
				localStorage.setItem("activity_time",parseInt(new Date().getTime()/1000));
				next()
			}
		}
	} else {
		next() // 进入下一页面
	}
	// return
})



export default router
