<template>
	<div class="page">
		<el-row type="flex" justify="center" align="middle" class="container">
			<el-col :lg="14" :xl="10" class="hidden-md-and-down">
				<el-row class="panel">
					<el-col :span="12">
						<div class="left">
							<img src="../assets/login/logo.png" class="logo" style="width: 200px; margin-left: 10px; margin-bottom: 60px;"/>
							<img src="../assets/login/big-1.png" class="big" style="margin-top: -30px;"/>
						</div>
					</el-col>
					<el-col :span="12">
						<div class="right">
							<div class="title-container">
								<h2 style="font-size: 22px; line-height: 22px; height: 22px; margin-top:10px;">信息发布系统</h2>
								<span>( 1.0 )</span>
							</div>
							<div>
								<div class="row">
									<el-input
										v-model="username"
										placeholder="用户名"
										prefix-icon="el-icon-user"
										clearable="clearable"
									/>
								</div>
								<div class="row">
									<el-input
										type="password"
										v-model="password"
										placeholder="密码"
										prefix-icon="el-icon-lock"
										clearable="clearable"
									/>
								</div>
								<div class="row">
									<el-button type="primary" class="btn" @click="handleLogin">登陆系统</el-button>
								</div>
							</div>
							<div>
								<div class="qrCode-container">
									<img src="../assets/login/phone.png" height="148" />
								</div>
							</div>
						</div>
					</el-col>
				</el-row>
			</el-col>
		</el-row>
	</div>
</template>

<script setup>
import router from '../router/index.js';
import { isUsername, isPassword } from '../utils/validate.js'
import { post } from '../utils/request.js'
import { defineComponent, reactive, toRefs, inject } from 'vue'
import { ElMessage } from 'element-plus'
import { useCookies } from "vue3-cookies"
const useLoginEffect = () => { // 封装登录逻辑
  const { cookies } = useCookies();
  // 数据
  const user = reactive({
    username: 'admin',
    password: '123456'
  })
  // 方法
  const handleLogin= async ()=>{
    if(!isUsername(user.username)){ //校验用户名
      ElMessage({message:"用户名格式错误", type:"error", offset:200, duration:1200 })
    }else if(!isPassword(user.password)){
      ElMessage({message:"密码格式错误", type:"error", offset:200, duration:1200 })
    }else{
      await post('user/login', user)
        .then((resp)=>{ //响应成功的回调, resp:返回的数据
          console.log(resp)
          if(resp.data.result){ //登录成功
            const permissions=resp.data.permissions//从响应数据中取权限
            const token=cookies.get("token")//从cookie中取令牌
            //将数据存入localStorage,实现数据跨页面共享
            localStorage.setItem("token", token)
            localStorage.setItem("permissions", permissions)
            router.push({name: 'Main'})//进入主页面
          }else{ //登录失败
            ElMessage({message:"用户名或密码错误", type:"error", offset:200, duration:1200 })
          }
        })
        .catch((err)=>{ //响应异常的回调, err:错误信息
          console.log(err)
        })
    }
  }
  const { username, password } = toRefs(user) //对user解构，toRefs的作用是使解构返回响应式数据
  return { username, password, handleLogin }
}

const { username, password, handleLogin } = useLoginEffect()

</script>

<style lang="less" scoped="scoped">
@import url('login.less');
</style>
