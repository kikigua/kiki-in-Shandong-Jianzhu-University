<template>
	<el-dialog title="提示" v-model="visible" width="25%">
		<el-form :model="dataForm" :rules="dataRule" ref="df" label-width="80px">
			<el-form-item label="原密码" prop="password">
				<el-input type="password" v-model="dataForm.password" size="default" clearable />
			</el-form-item>
			<!-- prop属性和验证规则中的名字相对应 -->
			<el-form-item label="新密码" prop="newPassword">
				<el-input type="password" v-model="dataForm.newPassword" size="default" clearable />
			</el-form-item>
			<el-form-item label="确认密码" prop="confirmPassword">
				<el-input type="password" v-model="dataForm.confirmPassword" size="default" clearable />
			</el-form-item>
		</el-form>
		<template #footer>
			<span class="dialog-footer">
				<el-button size="default" @click="visible = false">取消</el-button>	
				<el-button type="primary" size="default" @click="dataFormSubmit">确定</el-button>
			</span>
		</template>
	</el-dialog>
</template>

<script setup>
import { ref, reactive, nextTick } from 'vue'
import { ElMessage } from 'element-plus'
import { post } from '../utils/request.js'

const pwdInitEffect = () => { // 封装页面初始化逻辑
  // 数据
  const visible = ref(false)
  const df = ref(null) // 获得页面的dom元素
  const dataForm = reactive({
    password: '',
    newPassword: '',
    confirmPassword: ''
  })
  //方法
  //页面初始化
  const init=()=>{
    visible.value=true //显示弹层
    nextTick(()=>{
      df.value.resetFields()//重置表单
    })
  }
  //表单提交
  const dataFormSubmit=()=>{
    df.value.validate(async (valid)=>{ //调用表单的validate方法进行表单验证
      if(valid){ //数据校验通过
        const data={"password":dataForm.newPassword}//准备发送的数据
        await post("user/updatePassword", data) //发送请求，完成修改密码的功能
          .then((resp)=>{ //响应成功的回调
            console.log(resp)
            if(resp.data.rows==1){ //更新成功
              visible.value = false //隐藏弹层
              ElMessage({message:"密码修改成功", type:"info", offset:200, duration:1200 })
            }else{
              ElMessage({message:"密码修改失败", type:"error", offset:200, duration:1200 })
            }
          })
          .catch((err)=>{ //响应失败的回调
            console.log(err)
          })
      }
    }) 
  }
  return { visible, df, dataForm, init, dataFormSubmit }
}

const validatorRule = (dataForm) => { //封装客户端数据验证规则
  const dataRule = ref('');
  const validateConfirmPassword = (rule, value, callback) => { //自定义验证规则
  	if (value != dataForm.newPassword) {
  		callback(new Error('两次输入的密码不一致'));
  	} else {
  		callback();
  	}
  };
  dataRule.value = {
    password: [{ required: true, pattern: '^[a-zA-Z0-9]{6,20}$', message: '密码格式错误' }],
    newPassword: [{ required: true, pattern: '^[a-zA-Z0-9]{6,20}$', message: '密码格式错误' }],
    confirmPassword: [
    	{ required: true, pattern: '^[a-zA-Z0-9]{6,20}$', message: '密码格式错误' },
    	{ validator: validateConfirmPassword, trigger: 'blur' }
    ]
  }
  return { dataRule }
}
const { visible, df, dataForm, init, dataFormSubmit } = pwdInitEffect()
const { dataRule } = validatorRule(dataForm) 

defineExpose({ init }) //向父组件暴露init方法
</script>

<style></style>
