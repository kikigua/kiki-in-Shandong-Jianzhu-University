<template>
	<el-dialog
		:title="!dataForm.id ? '新增' : '修改'"
		v-if="isAuth(['ROOT', 'DEPT:INSERT', 'DEPT:UPDATE'])"
		:close-on-click-modal="false"
		v-model="visible"
		width="420px"
	>
		<el-form :model="dataForm" ref="df" :rules="dataRule" label-width="60px">
			<el-form-item label="类型" prop="name">
				<el-input v-model="dataForm.name" size="default" style="width:100%" clearable />
			</el-form-item>
			<el-form-item label="状态" prop="status">
        <!--
          下拉列表绑定的数组
          const options=[{"key":"V","value":"有效"}, {"key":"I","value":"无效"}]
        -->
				<el-select v-model="dataForm.status" class="m-2" placeholder="Select" size="large">
				  <el-option
				    v-for="item in options"
				    :key="item.key"
				    :label="item.value"
				    :value="item.key"
				  />
				</el-select>
			</el-form-item>
		</el-form>
		<template #footer>
			<span class="dialog-footer">
				<el-button size="default" @click="visible = false">取消</el-button>
				<el-button type="primary" size="default" @click="dataFormSubmit">确定</el-button>
			</span>
		</template>
	</el-dialog>
</template>

<script setup>
import dayjs from 'dayjs';
import { defineComponent, ref, reactive, nextTick } from 'vue'
import { ElMessage } from 'element-plus'
import { post, get, multiStrictGet } from '../utils/request.js'

const emits=defineEmits(['refreshData'])

const pageInitEffect = () => { // 封装页面初始化逻辑
  // 数据
  const visible = ref(false) //弹层是否可见
  const df = ref(null) // 获得页面的dom元素
  const dataForm = reactive({
    id: null, 
  	name: null, //职务名称
  	status: null //状态
  })
  const options=[{"key":"V","value":"有效"}, {"key":"I","value":"无效"}] //下拉列表的数据源
  // 方法
  //初始化
  const init = async (id)=>{
    visible.value = true
    dataForm.id = id //设置id
    nextTick(()=>{
      df.value.resetFields() //重置表单
    })
    await post("crole/selectById", {"id":id}) //获取要修改的数据
      .then((resp)=>{
        console.log(resp)
        dataForm.name = resp.data.crole.name //将返回的数据赋值给dataForm
        dataForm.status = resp.data.crole.status
      })
      .catch((err)=>{
        console.log(err)
      })
  }
  //新增/修改保存
  const dataFormSubmit= ()=>{
    df.value.validate(async (valid)=>{
      if(valid){ //验证通过
        await post('crole/update', dataForm) //更新保存
          .then((resp)=>{
            console.log(resp)
            if(resp.data.rows===1){ //成功
              emits('refreshData') //触发事件refreshDataList，调用loadDataList()方法，重新加载数据列表
              visible.value = false //关闭弹层
              ElMessage({message:"操作成功", type:"success", offset:200, duration:1200 })
            }else{ //失败
              ElMessage({message:"操作失败", type:"error", offset:200, duration:1200 })
            }
          })
          .catch((err)=>{
            console.log(err)
          })
      }
    })
  }
  
  return { visible, dataForm, df, init, dataFormSubmit, options }
}

const validatorRule = () => { //封装客户端数据验证规则
  const dataRule = ref('');
  dataRule.value = {
		name: [ //文本框的验证规则
			{ required: true, message: "职位名称格式错误", trigger: "blur" },
      { whitespace: true, message: "职位名称格式错误", trigger: "blur" }
		],
		status: [ //下拉的验证规则
			{ required: true, message: '状态不能为空' }
		]
  }
  return { dataRule }
}
//父传入子refreshDataList和refreshUpdateEle事件
const { visible, dataForm, df, init, dataFormSubmit, options } = pageInitEffect()
const { dataRule } = validatorRule()

defineExpose({ init })//向父组件暴露init方法

</script>

<style lang="less" scoped="scoped">
</style>
