<template>
	<!--isAuth是定义再main.js中的公共函数-->
	<div v-if="isAuth(['ROOT', 'USER:SELECT'])">
		<el-form :inline="true" :model="dataForm" :rules="dataRule" ref="df">
			<el-form-item prop="name">
				<el-input
					v-model="dataForm.name"
					placeholder="姓名"
					size="default"
					class="input"
					clearable="clearable"
					@blur="searchHandle()"
					@keyup.enter.native="$event.target.blur()"
				/>
			</el-form-item>
			<el-form-item>
				<el-select v-model="dataForm.sex" class="input" placeholder="性别" size="default" clearable="clearable">
					<el-option label="男" value="男" />
					<el-option label="女" value="女" />
				</el-select>
			</el-form-item>
			<el-form-item>
				<el-select v-model="dataForm.role" class="input" placeholder="角色" size="default" clearable="clearable">
					<el-option v-for="one in roleList" :label="one.roleName" :value="one.roleName" />
				</el-select>
			</el-form-item>
			<el-form-item>
				<el-select
					v-model="dataForm.deptId"
					class="input"
					placeholder="部门"
					size="default"
					clearable="clearable"
				>
					<el-option v-for="one in deptList" :label="one.deptName" :value="one.id" />
				</el-select>
			</el-form-item>
			<el-form-item>
				<el-select
					v-model="dataForm.status"
					class="input"
					placeholder="状态"
					size="default"
					clearable="clearable"
				>
					<el-option label="在职" value="1" />
					<el-option label="离职" value="2" />
				</el-select>
			</el-form-item>
			<el-form-item>
				<el-button size="default" type="primary" @click="searchHandle()">查询</el-button>
				<el-button
					size="default"
					type="primary"
					:disabled="!isAuth(['ROOT', 'USER:INSERT'])"
					@click="addHandle()"
				>
					新增
				</el-button>
				<el-button
					size="default"
					type="danger"
					:disabled="!isAuth(['ROOT', 'USER:DELETE'])"
					@click="deleteHandle()"
				>
					批量删除
				</el-button>
			</el-form-item>
		</el-form>
		<!--
		cell-style="padding: 4px 0"
		-->
		<el-table
			:data="dataList"
			border
			v-loading.fullscreen.lock="dataListLoading"
			element-loading-text="数据加载中..."
			@selection-change="selectionChangeHandle"
			style="width: 100%;"
			size="default"
		>
			<el-table-column type="selection" header-align="center" align="center" width="50"/>
			<el-table-column type="index" header-align="center" align="center" width="60" label="序号">
				<!--相当于 v-slot:default="scope",匿名插槽-->
				<template #default="scope">
					<span>{{ (pageIndex - 1) * pageSize + scope.$index + 1 }}</span>
				</template>
			</el-table-column>
			<el-table-column prop="name" header-align="center" align="center" min-width="80" label="姓名" />
			<el-table-column prop="sex" header-align="center" align="center" min-width="60" label="性别" />
			<el-table-column
				prop="email"
				header-align="center"
				align="center"
				min-width="200"
				label="邮箱"
				:show-overflow-tooltip="true"
			/>
			<el-table-column
				prop="roles"
				header-align="center"
				align="center"
				min-width="150"
				label="角色"
				:show-overflow-tooltip="true"
			/>
			<el-table-column prop="dept" header-align="center" align="center" min-width="100" label="部门" />
			<el-table-column prop="status" header-align="center" align="center" min-width="100" label="状态" />
			<el-table-column header-align="center" align="center" width="150" label="操作">
				<template #default="scope">
					<el-button
						link
						type="primary"
						size="default"
						v-if="isAuth(['ROOT', 'USER:UPDATE'])"
						@click="updateHandle(scope.row.id, scope.$index)"
					>
						修改
					</el-button>
					<el-button
						link
						type="primary"
						size="default"
						:disabled="scope.row.root"
						v-if="isAuth(['ROOT', 'USER:DELETE'])"
						@click="deleteHandle(scope.row.id)"
					>
						删除
					</el-button>
				</template>
			</el-table-column>
		</el-table>


		<el-pagination
			@size-change="sizeChangeHandle"
			@current-change="currentChangeHandle"
			:current-page="pageIndex"
			:page-sizes="[5, 10, 20]"
			:page-size="pageSize"
			:total="totalCount"
			layout="total, sizes, prev, pager, next, jumper"
		></el-pagination>

		<add-or-update ref="addOrUpdateWin" @refreshDataList="loadDataList" @refreshUpdateEle="updateUiEle"></add-or-update>


	</div>
</template>

<script>
import AddOrUpdate from './user-add-or-update.vue';
import { defineComponent, ref, reactive } from 'vue'
import { post, multiStrictGet, get } from '../utils/request.js'
import { ElMessage, ElMessageBox } from 'element-plus'
import { ifEmpty } from '../utils/tool.js'
const pageInitEffect = () => { // 封装页面初始化逻辑:从服务器获取所有当前页老师信息及所有课程列表
  // 数据
  const roleList = ref([])
  const deptList = ref([])
  // 方法
  const getInitData = async () => {
    await multiStrictGet([get('role/searchAllRole'), get('dept/searchAllDept')])
      .then((result) => {
          roleList.value = result[0]?.data.list
          deptList.value = result[1]?.data.list
      }).catch((err) => {
        ElMessage({ message: '服务器错误', offset: 200, center: true })
        console.log(err)
      })
  }
  return { roleList, deptList, getInitData}
}

const userOperateEffect = (dataList, loadDataList) => {
  // 数据
  const editIndex = ref(-1)
  const addOrUpdateWin = ref(null)
  const dataListSelections=ref([]) // 数组里保存的是整个对象
  // 方法
  // 弹出新增层
  const addHandle = () => {
	addOrUpdateWin.value.init() // 调用子组件中的init方法，对弹出层进行初始化
  }
  // 弹出修改层
  const updateHandle = (id, index) => { // id:修改记录的id, index:修改记录在dataList中的下标
	addOrUpdateWin.value.init(id)
	editIndex.value = index // 记住修改记录的下标
  }
  // 更新成功的回调
  const updateUiEle = (updatedEle) => {
	updatedEle.status = updatedEle.status == 1 ? '在职' : '离职'
	dataList.value[editIndex.value] = updatedEle // 显示更新后的数据
  }
  // 表格选中/取消选中触发的事件
  const selectionChangeHandle = (val) => {
  	dataListSelections.value = val
	console.log(dataListSelections.value)
  }
  const deleteHandle = (id) => {
    let ids = id ? [id] : dataListSelections.value.map(item => { return item.id; });
    if (ids.length == 0) {
      ElMessage({ message: '没有选中记录', type: 'warning', offset: 200, duration: 1200 });
    } else {
        ElMessageBox.confirm(`确定要删除选中的记录？`, '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
        }).then( async () => {
			await post('user/deleteUserByIds', { ids }).then((resp) => { // then里的函数对应的是Promise中的resolve
			 if (resp.data.rows > 0) {
			   ElMessage({ message: '操作成功', type: 'success', offset: 200, duration: 1200 })
			   loadDataList();
			 } else {
			   ElMessage({ message: '未能删除记录', type: 'warning', offset: 200, duration: 1200 })
			 }
			}).catch((err) => {
			  console.log(err)
			  ElMessage({ message: '服务器异常', type: 'error', offset: 200, center: true })
			})
        })
    }
  }
  return { addOrUpdateWin, addHandle, updateHandle, updateUiEle, dataListSelections, selectionChangeHandle, deleteHandle }
}

const userMainEffect = () => {
  // 数据
  // 分页数据
  const pageIndex = ref(1)
  const pageSize = ref(10)
  const totalCount = ref(0)
  //加载列表
  const dataListLoading = ref(false)
  const dataList = ref([]) // 响应式数据
  //查询表单
  const dataForm = reactive({
  	name: null, //name: '';后端数据校验会失败,故设置为null
  	sex: null,
  	role: null,
  	deptId: null,
  	status: null
  })
  const df = ref(null) // 获得页面的dom元素，对应页面的<el-form ...... ref="df">
  // 方法
  const loadDataList = async () => {
      dataListLoading.value = true;
      const data = { // 每次加载数据发送的数据对象,对应分页数据和查询数据
          page: pageIndex.value,
          length: pageSize.value,
          name: ifEmpty(dataForm.name),
          sex: ifEmpty(dataForm.sex),
          role: ifEmpty(dataForm.role),
          deptId: ifEmpty(dataForm.deptId),
          status: ifEmpty(dataForm.status)
      };
	  await post('user/searchUserByPage', data).then((resp) => { // then里的函数对应的是Promise中的resolve
	    //console.log(resp)
	    const page = resp.data.page;
	    const list = page.list;
      list.forEach( (one, index) => { // 格式化数据
        one.status = one.status == 1 ? '在职' : '离职'
      })
	    dataList.value = list;
	    totalCount.value = page.totalCount;
	    dataListLoading.value = false;
	  }).catch((err) => {
	    console.log(err)
	    ElMessage({ message: '服务器异常', type: 'error', offset: 200, center: true })
		dataListLoading.value = false;
	  })
  }
  // 分页导航 每次值改变就去请求接口
  const currentChangeHandle = (val) => {
    pageIndex.value = val
    loadDataList()
  }
  const sizeChangeHandle = (val) => {
    pageSize.value = val;
    //更改每页显示记录数量后，都从第一页开始查询
    pageIndex.value = 1;
    loadDataList();
  }
  const searchHandle = () => {
      //先执行表单验证
      df.value.validate(valid => {
          if (valid) {
              //清理页面上的表单验证结果
              df.value.clearValidate();
              //不允许上传空字符串给后端，但是可以传null值
			  //后端采用的是如下正则进行验证： @Pattern(regexp = "^[\\u4e00-\\u9fa5]{1,10}$", message = "name内容不正确")
     //          if (dataForm.name == '') {
     //              dataForm.name = null;
     //          }
			  // if (dataForm.sex == '') {
			  //     dataForm.sex = null;
			  // }
			  // if (dataForm.role == '') {
			  //     dataForm.role = null;
			  // }
			  // if (dataForm.deptId == '') {
			  //     dataForm.deptId = null;
			  // }
			  // if (dataForm.status == '') {
			  //     dataForm.status = null;
			  // }
			  dataForm.name = ifEmpty(dataForm.name)
			  dataForm.sex = ifEmpty(dataForm.sex)
			  dataForm.role = ifEmpty(dataForm.role)
			  dataForm.deptId = ifEmpty(dataForm.deptId)
			  dataForm.status = ifEmpty(dataForm.status)
              //如果当前页面不是第一页，则跳转到第一页显示查询的结果
              if (pageIndex.value != 1) {
                  pageIndex.value = 1;
              }
              loadDataList();
          } else {
              return false;
          }
      });
  }
  return { pageIndex, pageSize, totalCount, dataList, loadDataList, currentChangeHandle, dataForm, dataListLoading, sizeChangeHandle, searchHandle, df }
}
export default defineComponent({
	components: {
		AddOrUpdate
	},
	setup () {
	  const { roleList, deptList, getInitData } = pageInitEffect()
	  getInitData()
	  const { pageIndex, pageSize, totalCount, dataList, loadDataList, currentChangeHandle, dataForm, dataListLoading, sizeChangeHandle, searchHandle, df } = userMainEffect()
	  loadDataList()
	  const { addOrUpdateWin, addHandle, updateHandle, updateUiEle, dataListSelections, selectionChangeHandle, deleteHandle } = userOperateEffect(dataList, loadDataList)
	  return {
	    pageIndex, pageSize, totalCount, dataList, loadDataList, currentChangeHandle,
		dataForm, dataListLoading, sizeChangeHandle, roleList, deptList, searchHandle, df,
		addOrUpdateWin, addHandle, updateHandle, updateUiEle, dataListSelections, selectionChangeHandle, deleteHandle
	  }
	},
	data() {
		return {
			dimissVisible: false,
			dataRule: {
				name: [{ required: false, pattern: '^[\u4e00-\u9fa5]{1,10}$', message: '姓名格式错误' }]
			}
		};
	}
});
</script>

<style lang="less" scoped="scoped"></style>
