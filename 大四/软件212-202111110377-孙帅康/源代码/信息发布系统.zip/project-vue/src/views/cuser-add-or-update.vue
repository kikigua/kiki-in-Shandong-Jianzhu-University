<template>
	<el-dialog
		:title="!dataForm.id ? '新增' : '修改'"
		v-if="isAuth(['ROOT', 'DEPT:INSERT', 'DEPT:UPDATE'])"
		:close-on-click-modal="false"
		v-model="visible"
		width="420px"
	>
		<el-form :model="dataForm" ref="df" :rules="dataRule" label-width="80px">
			<el-form-item label="用户名" prop="account">
				<el-input v-model="dataForm.account" placeholder="字母或者数字,长度5-20" size="default" clearable />
			</el-form-item>
			<el-form-item label="密码" prop="password">
				<el-input type="password" v-model="dataForm.password" placeholder="字母或者数字,长度6-20" size="default" clearable />
			</el-form-item>
			<el-form-item label="姓名" prop="name">
				<el-input v-model="dataForm.name" size="default" placeholder="中文,长度2-10" clearable />
			</el-form-item>
			<el-form-item label="性别" prop="sex">
				<el-select v-model="dataForm.sex" size="default" style="width: 100%;" clearable>
					<el-option label="男" value="男"></el-option>
					<el-option label="女" value="女"></el-option>
				</el-select>
			</el-form-item>
			<el-form-item label="电话" prop="tel">
				<el-input v-model="dataForm.tel" size="default" clearable />
			</el-form-item>
			<el-form-item label="身高" prop="height">
				<el-input v-model="dataForm.height" size="default" clearable />
			</el-form-item>
			<el-form-item label="体重" prop="weight">
				<el-input v-model="dataForm.weight" size="default" clearable />
			</el-form-item>
		</el-form>
		<template #footer>
			<span class="dialog-footer">
				<el-button size="default" @click="visible = false">取消</el-button>
				<el-button type="primary" size="default" @click="dataFormSubmit">确定</el-button>
			</span>
		</template>
	</el-dialog>
</template>

<script setup>
import dayjs from 'dayjs';
import { defineComponent, ref, reactive, nextTick } from 'vue'
import { ElMessage } from 'element-plus'
import { post, get, multiStrictGet } from '../utils/request.js'

const emits=defineEmits(['refreshData'])

const pageInitEffect = () => { // 封装页面初始化逻辑
  // 数据
  const visible = ref(true) //弹层是否可见
  const df = ref(null) // 获得页面的dom元素
  const dataForm = reactive({
  	userId: null,
  	account: null,
  	password: null,
  	name: null,
  	sex: null,
	tel:null,
	nickname:null,
	height:null,
	weight:null
	
  })
  // 方法
  //初始化
  const init = async (id)=>{
    visible.value = true
    nextTick(()=>{
      df.value.resetFields() //重置表单
    })
    dataForm.id = id || 0 //假如id为null(新增时),返回0;  否则返回id自己
    if(dataForm.id){ //表示是修改
      await post("cuser/searchById", {"id": id} ) //发出请求获取要修改的数据
        .then((resp)=>{
          console.log(resp)
		  dataForm.userId = resp.data?.id;
         dataForm.account = resp.data?.account;
         dataForm.password = resp.data?.password;
         dataForm.name = resp.data?.name;
         dataForm.sex = resp.data?.sex;
         dataForm.tel = resp.data?.tel;
         dataForm.nickname = resp.data?.nickname;
         dataForm.height = resp.data?.height;
         dataForm.weight = resp.data?.weight;
        })
        .catch((err)=>{
          console.log(err)
        })
    }
  }
  //新增/修改保存
  const dataFormSubmit= ()=>{
    df.value.validate(async (valid)=>{
      if(valid){ //验证通过
        await post(`cuser/${!dataForm.id?'insert':'update'}`, dataForm) //通过模板字符串动态构建访问路径
          .then((resp)=>{
            console.log(resp)
            if(resp.data.rows===1){ //成功
              emits('refreshData') //触发事件refreshData，调用loadDataList()方法，重新加载数据列表
              visible.value = false //关闭弹层
              ElMessage({message:"操作成功", type:"success", offset:200, duration:1200 })
            }else{ //失败
              ElMessage({message:"操作失败", type:"error", offset:200, duration:1200 })
            }
          })
          .catch((err)=>{
            console.log(err)
          })
      }
    })
  }
  
  return { visible, dataForm, df, init, dataFormSubmit }
}

const validatorRule = () => { //封装客户端数据验证规则
  const dataRule = ref('');
  dataRule.value = {
		account: [{ required: true, pattern: '^[a-zA-Z0-9]{5,20}$', message: '用户名格式错误' }],
		password: [{ required: true, pattern: '^[a-zA-Z0-9]{6,20}$', message: '密码格式错误' }],
		name: [{ required: true, pattern: '^[\u4e00-\u9fa5]{2,10}$', message: '姓名格式错误' }],
		sex: [{ required: true, message: '性别不能为空' }],
		tel: [{ required: true, pattern: '^1\\d{10}$', message: '电话格式错误' }],
		nickname: [{ required: true, message: '昵称不能为空' }],
		height: [{ required: true, message: '身高不能为空' }],
		weight: [{ required: true, message: '体重不能为空' }]
  }
  return { dataRule }
}
//父传入子refreshDataList和refreshUpdateEle事件
const { visible, dataForm, df, init, dataFormSubmit } = pageInitEffect()
const { dataRule } = validatorRule()

defineExpose({ init })//向父组件暴露init方法

</script>

<style lang="less" scoped="scoped">
</style>
