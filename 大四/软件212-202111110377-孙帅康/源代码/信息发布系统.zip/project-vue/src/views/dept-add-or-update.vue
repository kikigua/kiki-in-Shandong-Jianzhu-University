<template>
	<el-dialog
		:title="!dataForm.id ? '新增' : '修改'"
		v-if="isAuth(['ROOT', 'DEPT:INSERT', 'DEPT:UPDATE'])"
		:close-on-click-modal="false"
		v-model="visible"
		width="420px"
	>
		<el-form :model="dataForm" ref="df" :rules="dataRule" label-width="60px">
			<el-form-item label="部门" prop="deptName">
				<el-input v-model="dataForm.deptName" size="default" style="width:100%" clearable />
			</el-form-item>
			<el-form-item label="电话" prop="tel">
				<el-input v-model="dataForm.tel" size="default" style="width:100%" clearable />
			</el-form-item>
			<el-form-item label="邮箱" prop="email">
				<el-input v-model="dataForm.email" size="default" style="width:100%" clearable />
			</el-form-item>
			<el-form-item label="备注" prop="desc">
				<el-input v-model="dataForm.desc" style="width:100%" size="default" maxlength="20" clearable />
			</el-form-item>
		</el-form>
		<template #footer>
			<span class="dialog-footer">
				<el-button size="default" @click="visible = false">取消</el-button>
				<el-button type="primary" size="default" @click="dataFormSubmit">确定</el-button>
			</span>
		</template>
	</el-dialog>
</template>

<script setup>
import dayjs from 'dayjs';
import { defineComponent, ref, reactive, nextTick } from 'vue'
import { ElMessage } from 'element-plus'
import { post, get, multiStrictGet } from '../utils/request.js'

const emits=defineEmits(['refreshData'])

const pageInitEffect = () => { // 封装页面初始化逻辑
  // 数据
  const visible = ref(false) //弹层是否可见
  const df = ref(null) // 获得页面的dom元素
  const dataForm = reactive({
  	id: null,
  	deptName: null,
  	tel: null,
  	email: null,
  	desc: null
  })
  // 方法
  //初始化
  const init = async (id)=>{
    visible.value = true
    nextTick(()=>{
      df.value.resetFields() //重置表单
    })
    dataForm.id = id || 0 //假如id为null(新增时),返回0;  否则返回id自己
    if(dataForm.id){ //表示是修改
      await post("dept/searchById", {"id": id} ) //发出请求获取要修改的数据
        .then((resp)=>{
          console.log(resp)
          dataForm.deptName = resp.data?.deptName
          dataForm.tel = resp.data?.tel
          dataForm.email = resp.data?.email
          dataForm.desc = resp.data?.desc
        })
        .catch((err)=>{
          console.log(err)
        })
    }
  }
  //新增/修改保存
  const dataFormSubmit= ()=>{
    df.value.validate(async (valid)=>{
      if(valid){ //验证通过
        await post(`dept/${!dataForm.id?'insert':'update'}`, dataForm) //通过模板字符串动态构建访问路径
          .then((resp)=>{
            console.log(resp)
            if(resp.data.rows===1){ //成功
              emits('refreshData') //触发事件refreshData，调用loadDataList()方法，重新加载数据列表
              visible.value = false //关闭弹层
              ElMessage({message:"操作成功", type:"success", offset:200, duration:1200 })
            }else{ //失败
              ElMessage({message:"操作失败", type:"error", offset:200, duration:1200 })
            }
          })
          .catch((err)=>{
            console.log(err)
          })
      }
    })
  }
  
  return { visible, dataForm, df, init, dataFormSubmit }
}

const validatorRule = () => { //封装客户端数据验证规则
  const dataRule = ref('');
  dataRule.value = {
		deptName: [
			{ required: true, pattern: '^[a-zA-Z0-9\u4e00-\u9fa5]{2,10}$', message: '部门名称格式错误' }
		],
		tel: [
			{
				required: false,
				pattern: '^1\\d{10}$|^(0\\d{2,3}\-){0,1}[1-9]\\d{6,7}$',
				message: '电话格式错误'
			}
		],
		email: [
			{
				required: false,
				pattern: '^([a-zA-Z]|[0-9])(\\w|\-|\\.)+@[a-zA-Z0-9]+\.([a-zA-Z]{2,4})$',
        //pattern: '^\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$',
				message: '邮箱格式错误'
			}
		]
  }
  return { dataRule }
}
//父传入子refreshDataList和refreshUpdateEle事件
const { visible, dataForm, df, init, dataFormSubmit } = pageInitEffect()
const { dataRule } = validatorRule()

defineExpose({ init })//向父组件暴露init方法

</script>

<style lang="less" scoped="scoped">
</style>
