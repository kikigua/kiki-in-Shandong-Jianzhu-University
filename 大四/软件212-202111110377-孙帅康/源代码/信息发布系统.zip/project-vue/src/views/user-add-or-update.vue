<template>
	<el-dialog
		:title="!dataForm.id ? '新增' : '修改'"
		v-if="isAuth(['ROOT', 'USER:INSERT', 'USER:UPDATE'])"
		:close-on-click-modal="false"
		v-model="visible"
		width="450px"
	>
		<el-form :model="dataForm" ref="df" :rules="dataRule" label-width="80px">
			<el-form-item label="用户名" prop="username">
				<el-input v-model="dataForm.username" placeholder="字母或者数字,长度5-20" size="default" clearable />
			</el-form-item>
			<el-form-item label="密码" prop="password">
				<el-input type="password" v-model="dataForm.password" placeholder="字母或者数字,长度6-20" size="default" clearable />
			</el-form-item>
			<el-form-item label="姓名" prop="name">
				<el-input v-model="dataForm.name" size="default" placeholder="中文,长度2-10" clearable />
			</el-form-item>
			<el-form-item label="性别" prop="sex">
				<el-select v-model="dataForm.sex" size="default" style="width: 100%;" clearable>
					<el-option label="男" value="男"></el-option>
					<el-option label="女" value="女"></el-option>
				</el-select>
			</el-form-item>
			<el-form-item label="电话" prop="tel">
				<el-input v-model="dataForm.tel" size="default" clearable />
			</el-form-item>
			<el-form-item label="邮箱" prop="email">
				<el-input v-model="dataForm.email" size="default" clearable />
			</el-form-item>
			<el-form-item label="入职日期" prop="hiredate">
				<el-date-picker
					v-model="dataForm.hiredate"
					type="date"
					placeholder="选择日期"
					size="default"
					:editable="false"
					format="YYYY-MM-DD"
					style="width: 100%;"
				/>
			</el-form-item>
			<el-form-item label="角色" prop="role">
				<el-select
					v-model="dataForm.role"
					size="default"
					placeholder="选择角色"
					style="width: 100%;"
					multiple
					clearable
				>
					<el-option
						v-for="one in roleList"
						:key="one.id"
						:label="one.roleName"
						:value="one.id"
						:disabled="one.roleName == '超级管理员'"
					></el-option>
				</el-select>
			</el-form-item>
			<el-form-item label="部门" prop="deptId">
				<el-select
					v-model="dataForm.deptId"
					size="default"
					placeholder="选择部门"
					style="width: 100%;"
					clearable
				>
					<el-option v-for="one in deptList" :key="one.id" :label="one.deptName" :value="one.id" />
				</el-select>
			</el-form-item>
		</el-form>
		<template #footer>
			<span class="dialog-footer">
				<el-button size="default" @click="visible = false">取消</el-button>
				<el-button type="primary" size="default" @click="dataFormSubmit">确定</el-button>
			</span>
		</template>
	</el-dialog>
</template>

<script>
import dayjs from 'dayjs';
import { defineComponent, ref, reactive, nextTick } from 'vue'
import { ElMessage } from 'element-plus'
import { post, get, multiStrictGet } from '../utils/request.js'

const pageInitEffect = (emit) => { // 封装页面初始化逻辑
  // const dayjs = require(dayjs)
  // 数据
  const visible = ref(false)
  const df = ref(null) // 获得页面的dom元素
  const dataForm = reactive({
  	id: null,
  	username: null,
  	password: null,
  	name: null,
  	sex: null,
  	tel: null,
  	email: null,
  	hiredate: dayjs(new Date()).format('YYYY-MM-DD'),
  	role: null,
  	deptId: null,
  	status: 1
  })
  const roleList = ref([])
  const deptList = ref([])
  // 方法
  const init = async (id) => {
      visible.value = true;  //显示弹窗
	  dataForm.id = id || 0;
      //因为清空表单控件是异步的，所以把清空表单控件放在下次DOM更新循环中
	  // df.value.resetFields();//在此处执行，df为null,需要放在nextTick中执行
      nextTick(() => {
          df.value.resetFields(); 
      })
	  await multiStrictGet([get('role/searchAllRole'), get('dept/searchAllDept')])
	    .then((result) => {
	        roleList.value = result[0]?.data.list
	        deptList.value = result[1]?.data.list
	    }).catch((err) => {
	      ElMessage({ message: '服务器错误', offset: 200, center: true })
	      console.log(err)
	    })
	  if (dataForm.id) {
		await post('user/searchById', { id }).then((resp) => {
		  dataForm.username = resp.data?.username;
		  dataForm.password = resp.data?.password;
		  dataForm.name = resp.data?.name;
		  dataForm.sex = resp.data?.sex;
		  dataForm.tel = resp.data?.tel;
		  dataForm.email = resp.data?.email;
		  dataForm.hiredate = resp.data?.hiredate;
		  dataForm.role = JSON.parse(resp.data?.role);
		  dataForm.deptId = resp.data?.deptId;
		  dataForm.status = resp.data?.status;
		}).catch((err) => { 
		  console.log(err)
		  ElMessage({ message: '服务器异常', type: 'error', offset: 200, center: true, duration: 1200 })
		})
	  }
  }
  const dataFormSubmit =  () => {
    df.value.validate( async (valid) => {
      if (valid) {
          const data = {
              userId: dataForm.id,
              username: dataForm.username,
              password: dataForm.password,
              name: dataForm.name,
              sex: dataForm.sex,
              tel: dataForm.tel,
              email: dataForm.email,
              hiredate: dayjs(dataForm.hiredate).format('YYYY-MM-DD'),
              role: dataForm.role,
              deptId: dataForm.deptId,
              status: dataForm.status
          };
		  await post(`user/${!dataForm.id ? 'insert' : 'update'}`, data).then((resp) => {
		    if (resp.data?.rows == 1) {
		  	  ElMessage({ message: '操作成功', type: 'success', offset: 200, duration: 1200 });
		      visible.value = false
			  if (!dataForm.id) { // 新增成功
				emit('refreshData')  
			  } else { // 更新成功
				emit('refreshUpdateEle', resp.data?.map)
			  }
		    } else {
		  	  ElMessage({ message: '操作失败', type: 'error', offset: 200, duration: 1200 });
		    }
		  }).catch((err) => { 
		    console.log(err)
		    ElMessage({ message: '服务器异常', type: 'error', offset: 200, center: true, duration: 1200 })
		  })
      }
    });
  }
  return { init, visible, df, dataForm, roleList, deptList, dataFormSubmit }
}

const validator = () => {
	const dataRule = ref('');
	dataRule.value = {
		username: [{ required: true, pattern: '^[a-zA-Z0-9]{5,20}$', message: '用户名格式错误' }],
		password: [{ required: true, pattern: '^[a-zA-Z0-9]{6,20}$', message: '密码格式错误' }],
		name: [{ required: true, pattern: '^[\u4e00-\u9fa5]{2,10}$', message: '姓名格式错误' }],
		sex: [{ required: true, message: '性别不能为空' }],
		tel: [{ required: true, pattern: '^1\\d{10}$', message: '电话格式错误' }],
		email: [
			{
				required: true,
				pattern: '^([a-zA-Z]|[0-9])(\\w|\\-)+@[a-zA-Z0-9]+\\.([a-zA-Z]{2,4})$',
				message: '邮箱格式错误'
			}
		],
		hiredate: [{ required: true, trigger: 'blur', message: '入职日期不能为空' }],
		role: [{ required: true, message: '角色不能为空' }],
		deptId: [{ required: true, message: '部门不能为空' }],
		status: [{ required: true, message: '状态不能为空' }]
	}
	return { dataRule }
}
export default defineComponent({
	emits: ['refreshDataList', 'refreshUpdateEle'],
	setup (props, context) {
	  const { emit } = context 
	  const { init, visible, df, dataForm, roleList, deptList, dataFormSubmit } = pageInitEffect(emit)
	  const { dataRule } = validator()
	  return {
	    init, visible, df, dataForm, roleList, deptList, dataFormSubmit, dataRule
	  }
	},
	
});
</script>

<style lang="less" scoped="scoped">
// data: function() {
	// 	return {
	// 		dataRule: {
	// 			username: [{ required: true, pattern: '^[a-zA-Z0-9]{5,20}$', message: '用户名格式错误' }],
	// 			password: [{ required: true, pattern: '^[a-zA-Z0-9]{6,20}$', message: '密码格式错误' }],
	// 			name: [{ required: true, pattern: '^[\u4e00-\u9fa5]{2,10}$', message: '姓名格式错误' }],
	// 			sex: [{ required: true, message: '性别不能为空' }],
	// 			tel: [{ required: true, pattern: '^1\\d{10}$', message: '电话格式错误' }],
	// 			email: [
	// 				{
	// 					required: true,
	// 					pattern: '^([a-zA-Z]|[0-9])(\\w|\\-)+@[a-zA-Z0-9]+\\.([a-zA-Z]{2,4})$',
	// 					message: '邮箱格式错误'
	// 				}
	// 			],
	// 			hiredate: [{ required: true, trigger: 'blur', message: '入职日期不能为空' }],
	// 			role: [{ required: true, message: '角色不能为空' }],
	// 			deptId: [{ required: true, message: '部门不能为空' }],
	// 			status: [{ required: true, message: '状态不能为空' }]
	// 		}
	// 	};
	// }
</style>
