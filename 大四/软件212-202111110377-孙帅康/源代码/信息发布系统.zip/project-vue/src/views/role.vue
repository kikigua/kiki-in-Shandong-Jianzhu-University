<template>
    <div v-if="isAuth(['ROOT', 'ROLE:SELECT'])">
        <el-form :inline="true" :model="dataForm" :rules="dataRule" ref="df">
            <el-form-item prop="roleName">
                <el-input
                    v-model="dataForm.roleName"
                    placeholder="角色名称"
                    size="default"
                    class="input"
                    clearable="clearable"
                    @keyup.enter.native="searchHandle()"
                />
            </el-form-item>
            <el-form-item>
                <el-button size="default" type="primary" @click="searchHandle()">查询</el-button>
                <el-button
                    size="default"
                    type="primary"
                    :disabled="!isAuth(['ROOT', 'ROLE:INSERT'])"
                    @click="addHandle()"
                >
                    新增
                </el-button>
                <el-button
                    size="default"
                    type="danger"
                    :disabled="!isAuth(['ROOT', 'ROLE:DELETE'])"
                    @click="deleteHandle()"
                >
                    批量删除
                </el-button>
            </el-form-item>
        </el-form>
        <el-table
            :data="dataList"
            border
            v-loading.fullscreen.lock="dataListLoading"
			element-loading-text="数据加载中..."
            @selection-change="selectionChangeHandle"
            style="width: 100%;"
            size="default"
        >
            <el-table-column
                type="selection"
				:selectable="selectable"
                header-align="center"
                align="center"
                width="50"
            />
            <el-table-column type="index" header-align="center" align="center" width="100" label="序号">
                <template #default="scope">
                    <span>{{ (pageIndex - 1) * pageSize + scope.$index + 1 }}</span>
                </template>
            </el-table-column>
            <el-table-column prop="roleName" header-align="center" align="center" label="角色名称" min-width="150"/>
            <el-table-column header-align="center" align="center" label="权限数量" min-width="100">
                <template #default="scope">
                    <span>{{ scope.row.permissions }}个</span>
                </template>
            </el-table-column>
            <el-table-column prop="users" header-align="center" align="center" label="关联用户" min-width="100">
                <template #default="scope">
                    <span>{{ scope.row.users }}人</span>
                </template>
            </el-table-column>
            <el-table-column prop="desc" header-align="center" align="center" label="备注" min-width="240" />
            <el-table-column prop="systemic" header-align="center" align="center" label="内置角色" min-width="100">
                <template #default="scope">
                    <span>{{ scope.row.systemic ? '是' : '否' }}</span>
                </template>
            </el-table-column>
            <el-table-column header-align="center" align="center" width="120" label="操作">
                <template #default="scope">
                    <el-button
						link
						type="primary"
                        size="default"
                        :disabled="!isAuth(['ROOT', 'ROLE:UPDATE']) || scope.row.id == 0"
                        @click="updateHandle(scope.row.id, scope.row.systemic, scope.$index)"
                    >
                        修改
                    </el-button>
                    <el-button
						link
						type="primary"
                        size="default"
                        :disabled="!isAuth(['ROOT', 'ROLE:DELETE']) || scope.row.systemic || scope.row.users > 0"
                        @click="deleteHandle(scope.row.id)"
                    >
                        删除
                    </el-button>
                </template>
            </el-table-column>
        </el-table>
        <el-pagination
            @size-change="sizeChangeHandle"
            @current-change="currentChangeHandle"
            :current-page="pageIndex"
            :page-sizes="[5, 10, 20]"
            :page-size="pageSize"
            :total="totalCount"
            layout="total, sizes, prev, pager, next, jumper"
        ></el-pagination>
        <add-or-update ref="addOrUpdateWin" @refreshDataList="loadDataList" @refreshUpdateEle="updateUiEle"></add-or-update>
    </div>
</template>
<script>
import AddOrUpdate from './role-add-or-update.vue'
import { defineComponent, ref, reactive } from 'vue'
import { post, get } from '../utils/request.js'
import { ElMessage, ElMessageBox } from 'element-plus'
import { ifEmpty } from '../utils/tool.js'

const roleOperateEffect = (dataList, loadDataList) => {
  // 数据
  const editIndex = ref(-1)
  const addOrUpdateWin = ref(null)
  const dataListSelections=ref([]) // 数组里保存的是整个对象
  // 方法
  // 弹出新增层
  const addHandle = () => {
	addOrUpdateWin.value.init() // 调用子组件中的init方法，对弹出层进行初始化
  }
  // 弹出修改层
  const updateHandle = (id, systemic, index) => { // id:修改记录的id, index:修改记录在dataList中的下标
  	addOrUpdateWin.value.init(id, systemic)
  	editIndex.value = index // 记住修改记录的下标
  }
  // 更新成功的回调
  const updateUiEle = (updatedEle) => {
  	dataList.value[editIndex.value] = updatedEle // 显示更新后的数据
  }
  // 判断删除复选框是否可勾选
  const selectable = (row, index) => {
      if (row.systemic || row.users > 0) {
          return false;
      }
      return true;
  }
  // 处理选中事件
  const selectionChangeHandle = (val) => {
  	dataListSelections.value = val
  	console.log(dataListSelections.value)
  }
  // 删除事件
  const deleteHandle = (id) => {
	  let ids = id ? [id] : dataListSelections.value.map(item => { return item.id; });
	  if (ids.length == 0) {
	    ElMessage({ message: '没有选中记录', type: 'warning', offset: 200, duration: 1200 });
	  } else {
	      ElMessageBox.confirm(`确定要删除选中的记录？`, '提示', {
	          confirmButtonText: '确定',
	          cancelButtonText: '取消',
	          type: 'warning'
	      }).then( async () => {
	  		await post('role/deleteRoleByIds', { ids }).then((resp) => {
	  		 if (resp.data.rows > 0) {
	  		   ElMessage({ message: '操作成功', type: 'success', offset: 200, duration: 1200 })
	  		   loadDataList();
	  		 } else {
	  		   ElMessage({ message: '未能删除记录', type: 'warning', offset: 200, duration: 1200 })
	  		 }
	  		}).catch((err) => {
	  		  console.log(err)
	  		  ElMessage({ message: '服务器异常', type: 'error', offset: 200, center: true })
	  		})
	      })
	  }
  }
  return { addOrUpdateWin, addHandle, selectionChangeHandle, updateHandle, updateUiEle, selectable, deleteHandle }
}
const roleMainEffect = () => {
  // 数据
  // 分页数据
  const pageIndex = ref(1)
  const pageSize = ref(10)
  const totalCount = ref(0)
  //加载列表
  const dataListLoading = ref(false)
  const dataList = ref([]) // 响应式数据
  //查询表单
  const dataForm = reactive({
  	roleName: null
  })
  const df = ref(null) // 获得页面的dom元素，对应页面的<el-form ...... ref="df">
  // 方法
  const loadDataList = async () => {
      dataListLoading.value = true;
      const data = { // 每次加载数据发送的数据对象,对应分页数据和查询数据
          page: pageIndex.value,
          length: pageSize.value,
		  roleName: ifEmpty(dataForm.roleName),
      };
	  await post('role/searchRoleByPage', data).then((resp) => { // then里的函数对应的是Promise中的resolve
	    console.log(resp)
	    const page = resp.data.page;
	    dataList.value = page.list;
	    totalCount.value = page.totalCount;
	    dataListLoading.value = false;
	  }).catch((err) => {
	    console.log(err)
	    ElMessage({ message: '服务器异常', type: 'error', offset: 200, center: true })
		dataListLoading.value = false;
	  })
  }
  // 分页导航 每次值改变就去请求接口
  const currentChangeHandle = (val) => {
    pageIndex.value = val
    loadDataList()
  }
  const sizeChangeHandle = (val) => {
    pageSize.value = val;
    //更改每页显示记录数量后，都从第一页开始查询
    pageIndex.value = 1;
    loadDataList();
  }
  const searchHandle = () => {
     //先执行表单验证
     df.value.validate(valid => {
         if (valid) {
             //清理页面上的表单验证结果
             df.value.clearValidate();
             //不允许上传空字符串给后端，但是可以传null值
             // if (dataForm.roleName == '') {
             //     dataForm.roleName = null;
             // }
			 dataForm.roleName = ifEmpty(dataForm.roleName)
             //如果当前页面不是第一页，则跳转到第一页显示查询的结果
             if (pageIndex.value != 1) {
                 pageIndex.value = 1;
             }
             loadDataList();
         } else {
             return false;
         }
     });
  }
  return { pageIndex, pageSize, totalCount, dataList, loadDataList, currentChangeHandle, dataForm, dataListLoading, sizeChangeHandle, searchHandle, df }
}
export default defineComponent({
	components: {
		AddOrUpdate
	},
	setup () {
	  const { pageIndex, pageSize, totalCount, dataList, loadDataList, currentChangeHandle, dataForm, dataListLoading, sizeChangeHandle, searchHandle, df } = roleMainEffect()
	  const { addOrUpdateWin, addHandle, selectionChangeHandle, updateHandle, updateUiEle, selectable, deleteHandle } = roleOperateEffect(dataList, loadDataList)
	  loadDataList();
	  return {
	    pageIndex, pageSize, totalCount, dataList, loadDataList, currentChangeHandle, dataForm, dataListLoading, sizeChangeHandle, searchHandle, df,
		addOrUpdateWin, addHandle, selectionChangeHandle, updateHandle, updateUiEle, selectable, deleteHandle
	  }
	},
    data: function() {
        return {
            dataRule: {
                roleName: [{ required: false, pattern: '^[a-zA-Z0-9\u4e00-\u9fa5]{1,10}$', message: '角色格式错误' }]
            }
        };
    },
    methods: {

    }
});
</script>

<style></style>
