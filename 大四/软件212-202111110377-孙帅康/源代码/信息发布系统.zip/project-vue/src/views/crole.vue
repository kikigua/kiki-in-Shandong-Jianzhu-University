<template>
	<div v-if="isAuth(['ROOT', 'CROLE:SELECT'])">
		<el-form :inline="true" :model="dataForm" :rules="dataRule" ref="df">
			<el-form-item prop="n ame">
				<el-input
					v-model="dataForm.name"
					placeholder="身份名称"
					size="default"
					class="input"
					clearable="clearable"
					@blur="searchHandle()"
					@keyup.enter.native="$event.target.blur()"
				/>
			</el-form-item>
			<el-form-item>
				<el-button size="default" type="primary" @click="searchHandle()">查询</el-button>
				<el-button
					size="default"
					type="primary"
					:disabled="!isAuth(['ROOT', 'CROLE:INSERT'])"
					@click="addHandle()"
				>
					新增
				</el-button>
				<el-button
					size="default"
					type="danger"
					:disabled="!isAuth(['ROOT', 'CROLE:DELETE'])"
					@click="deleteHandle()"
				>
					批量删除
				</el-button>
			</el-form-item>
		</el-form>
		<el-table
			:data="dataList"
			border
			v-loading.fullscreen.lock="dataListLoading"
			element-loading-text="数据加载中..."
			@selection-change="selectionChangeHandle"
			size="default"
			style="width: 100%;"
		>
			<el-table-column type="selection" :selectable="selectable" header-align="center" align="center" width="50"/>
			<el-table-column type="index" header-align="center" align="center" width="100" label="序号">
				<template #default="scope">
					<span>{{ (pageIndex - 1) * pageSize + scope.$index + 1 }}</span>
				</template>
			</el-table-column>
			<el-table-column prop="name" header-align="center" align="center" label="身份名称" min-width="150"/>
			<el-table-column  header-align="center" align="center" label="状态" min-width="150">
				<template #default="scope">
					<span>{{ scope.row.status=='V'?'有效':'无效'}}</span>
				</template>

				</el-table-column>
			<el-table-column prop="updatedAt" header-align="center" align="center" label="更新时间" min-width="200">
				<template #default="scope">
					<span>{{ $filters.formatDate( scope.row.updatedAt)}}</span>
				</template>
			</el-table-column>

			<el-table-column header-align="center" align="center" width="150" label="操作">
				<template #default="scope">
					<el-button
						link
						type="primary"
						size="default"
						:disabled="!isAuth(['ROOT', 'CROLE:UPDATE'])"
						@click="updateHandle(scope.row.id)"
					>
						修改
					</el-button>
					<el-button
						link
						type="primary"
						size="default"
						:disabled="!isAuth(['ROOT', 'CROLE:DELETE']) || scope.row.emps > 0"
						@click="deleteHandle(scope.row.id)"
					>
						删除
					</el-button>
				</template>
			</el-table-column>
		</el-table>
		<el-pagination
			@size-change="sizeChangeHandle"
			@current-change="currentChangeHandle"
			:current-page="pageIndex"
			:page-sizes="[5, 10, 20]"
			:page-size="pageSize"
			:total="totalCount"
			layout="total, sizes, prev, pager, next, jumper"
		></el-pagination>
		<!--使用新增/-->
    <Add ref="addWin" @refreshData="loadDataList"></Add>
	<Update ref="updateWin" @refreshData="loadDataList"></Update> 
	</div>
</template>

<script setup>
//引入新增/修改组件
import { defineComponent, ref, reactive } from 'vue'
import { post, get } from '../utils/request.js'
import { ElMessage, ElMessageBox } from 'element-plus'
import { ifEmpty } from '../utils/tool.js'
import Add from './crole-add.vue' //导入添加/修改弹层组件
import Update from './crole-update.vue'
const croleOperateEffect = (dataList, loadDataList) => {
  // 数据
  const addWin=ref(null)//新增弹层
  const updateWin=ref(null)
  const dataListSelections = ref([]) // 勾选的部门记录, 数组里保存的是整个对象
  // 方法
  // 弹出新增层
  const addHandle=()=>{
    addWin.value.init() //调用弹层的init方法,显示出弹层
  }
  // 弹出修改层
  const updateHandle=(id)=>{
    updateWin.value.init(id) //调用弹层的init方法,显示出弹层
  }
  // 更新成功的回调
  // 判断删除复选框是否可勾选
  const selectable = (row, index) => {
      if (row.emps > 0) {
          return false;
      }
      return true;
  }
  // 处理删除选中事件
  const selectionChangeHandle=(val)=>{
    dataListSelections.value= val
    console.log(dataListSelections.value)
  }
  // 删除事件
  const deleteHandle=(id)=>{
    let ids = id?[id]:dataListSelections.value.map(item => item.id) //获取删除数组
    if(ids.length!=0){
      ElMessageBox.confirm("是否删除(y/n)?", "删除确认",{
        confirmButtonText:"确认",
        cancelButtonText:"取消",
        type: "warning"
      }).then( async ()=>{
        await post("crole/delete", { ids })
          .then((resp)=>{
            if(resp.data.rows>0){ //因为是批量删除,会同时删除多条记录，所以需判断rows>0
              ElMessage({message:"删除成功", type:"success", offset:200, duration:1200 })
              loadDataList() //加载删除后的所有记录
            }else{
              ElMessage({message:"删除失败", type:"warning", offset:200, duration:1200 })
            }
          })
          .catch((err)=>{
            ElMessage({message:"服务器异常", type:"error", offset:200, duration:1200 })
          })
      })
    }else{
      ElMessage({message:"请选择要删除的记录", type:"waring", offset:200, duration:1200 })
    }
  }
  
  return { addWin,updateWin, addHandle, updateHandle, selectionChangeHandle, selectable, deleteHandle }
}
const croleMainEffect = () => {
  // 数据
  // 分页数据
  const pageIndex = ref(1)
  const pageSize = ref(10)
  const totalCount = ref(0)
  //加载列表
  const dataListLoading = ref(false)
  const dataList = ref([]) // 数据列表
  //查询表单
  const dataForm = reactive({
  	name: null
  })
  const df = ref(null) // 获得页面的dom元素，对应页面的<el-form ...... ref="df">
  // 方法
  // 加载数据列表
  const loadDataList= async ()=>{
    dataListLoading.value = true//显示动态加载效果
    //准备参数
    const data={
      "page": pageIndex.value,
      "length": pageSize.value,
      "name": ifEmpty(dataForm.name)
    }
    //发出请求，获取当前页的数据
    await post("crole/listPagePostion", data)
      .then((resp)=>{
        console.log(resp)
        dataListLoading.value = false //取消动态加载状态
        dataList.value = resp.data.page.list //设置数据列表
        totalCount.value = resp.data.page.totalCount //设置总条数
      })
      .catch((err)=>{
        console.log(err)
        dataListLoading.value = false
      })
  }
  // 分页导航 每次值改变就去请求接口
  const sizeChangeHandle=(val)=>{
    pageSize.value=val
    pageIndex.value=1 //回到第一页
    loadDataList() //重新加载数据
  }
    
  const currentChangeHandle=(val)=>{
    pageIndex.value=val
    loadDataList() //重新加载数据
  }
  //查询
  const searchHandle = ()=>{
    df.value.validate((valid)=>{
      if(valid){ //表单校验通过
        df.value.clearValidate() //清除表单校验信息
        dataForm.name = ifEmpty(dataForm.name) //假如查询条件为空字符串,将其转成null
        if(pageIndex.value!=1){
          pageIndex.value=1 //回到第一页
        }
        loadDataList() //重新加载数据
      }
    })
  }
  return { pageIndex, pageSize, totalCount, dataListLoading, dataList, dataForm, df, loadDataList, sizeChangeHandle, currentChangeHandle, searchHandle }
}
const validatorRule = () => { //封装客户端数据验证规则
  const dataRule = ref('');
  dataRule.value = {
      name: [
      	{ required: true, pattern: '^[a-zA-Z0-9\u4e00-\u9fa5]{1,10}$', message: '身份名称格式错误' }
      ]
  }
  return { dataRule }
}

const { pageIndex, pageSize, totalCount, dataListLoading, dataList, dataForm, df, loadDataList, sizeChangeHandle, currentChangeHandle, searchHandle  } = croleMainEffect()
const { addWin, updateWin,addHandle, updateHandle, selectionChangeHandle, selectable, deleteHandle } = croleOperateEffect(dataList, loadDataList)
const { dataRule } = validatorRule()
loadDataList();

</script>

<style></style>
