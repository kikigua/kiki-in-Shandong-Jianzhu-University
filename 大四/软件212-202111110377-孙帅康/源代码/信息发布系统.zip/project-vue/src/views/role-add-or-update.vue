<template>
	<el-dialog
		:title="!dataForm.id ? '新增' : '修改'"
		v-if="isAuth(['ROOT', 'ROLE:INSERT', 'ROLE:UPDATE'])"
		:close-on-click-modal="false"
		v-model="visible"
		custom-class="dialog"
		width="692px"
	>
		<el-form :model="dataForm" ref="df" :rules="dataRule" label-width="60px">
			<el-form-item label="角色" prop="roleName">
				<el-input v-model="dataForm.roleName" size="default" style="width:50%" :readonly="systemic" clearable />
				<span class="note">（ 角色名称必须是2~10个字符之间 ）</span>
			</el-form-item>
			<el-form-item label="备注" prop="desc">
				<el-input v-model="dataForm.desc" style="width:50%" size="default" maxlength="20" clearable />
				<span class="note">（ 备注信息必须是20个字符以内 ）</span>
			</el-form-item>
			<el-form-item label="权限" prop="permissions">
				<!--
					:data：permisionList 定义穿梭框左右两边的所有数据，包含状态
					v-model：permissions 定义穿梭框右侧的数据
				-->
				<el-transfer
					v-model="dataForm.permissions"
					:data="permisionList"
					size="default"
					:titles="['权限列表', '具备权限']"
					filterable
					filter-placeholder="请输入权限"
				/>
			</el-form-item>
		</el-form>
		<template #footer>
			<span class="dialog-footer">
				<el-button size="default" @click="visible = false">取消</el-button>
				<el-button type="primary" size="default" @click="dataFormSubmit">确定</el-button>
			</span>
		</template>
	</el-dialog>
</template>

<script>
	
import dayjs from 'dayjs';
import { defineComponent, ref, reactive, nextTick } from 'vue'
import { ElMessage } from 'element-plus'
import { post, get, multiStrictGet } from '../utils/request.js'
import { strToArray } from '../utils/tool.js'

const pageInitEffect = (emit) => { // 封装页面初始化逻辑
  // const dayjs = require(dayjs)
  // 数据
  const visible = ref(false)
  const systemic = ref(false)
  const df = ref(null) // 获得页面的dom元素
  const dataForm = reactive({
  	id: null,
  	roleName: null,
  	permissions: [],
  	desc: null,
  	changed: false
  })
  const permisionList = ref([])
  const oldPermissions = ref([])
  // 方法
  const init = async (id, systemic) => {
      visible.value = true;  //显示弹窗
	  dataForm.id = id || 0;
      //因为清空表单控件是异步的，所以把清空表单控件放在下次DOM更新循环中
	  // df.value.resetFields();//在此处执行，df为null,需要放在nextTick中执行
      nextTick(() => {
          df.value.resetFields(); 
      })
	  let defaultPermissions = [];
	  if (dataForm.id) { // 假如是修改，查询出所有数据
	  	await post('role/searchById', { id: id }).then((resp) => {
		  console.log(resp?.data);
	  	  dataForm.username = resp.data?.username;
	  	  dataForm.roleName = resp.data?.roleName;
	  	  dataForm.desc = resp.data?.desc;
	  	  //dataForm.permissions = resp.data?.permissions;
		  //console.log(typeof(dataForm.permissions)) // object
		  dataForm.permissions = JSON.parse(resp.data?.permissions);
	  	  //保存原始权限数据
	  	  oldPermissions.value = JSON.parse(resp.data?.permissions);
		  console.log(oldPermissions.value)
		  console.log(oldPermissions.value.join())
		  //oldPermissions.value = resp.data?.permissions;
		  //console.log(typeof(resp.data?.permissions)) // 服务器返回的是string
		  //console.log(resp.data?.permissions) // [1, 2, 3, 4, 5, 6, 7, 8, 28, 36, 17]
		  //dataForm是响应式对象，取其属性也是响应式的
		  //console.log(dataForm.permissions) // Proxy {0: 1, 1: 2, 2: 3, 3: 4, 4: 5, 5: 6, 6: 7, 7: 8, 8: 28, 9: 36, 10: 17}
		  console.log(typeof(dataForm.permissions)) // object
	  	  defaultPermissions = strToArray(resp.data?.defaultPermissions);//角色默认权限集合
		  console.log(defaultPermissions)
	  	}).catch((err) => { 
	  	  console.log(err)
	  	  ElMessage({ message: '服务器异常', type: 'error', offset: 200, center: true, duration: 1200 })
	  	})
	  }
	  await get('permission/searchAllPermission',null)
	    .then((resp) => {
			permisionList.value=[] // 清空原有数据
	        for (let one of resp.data?.list) {
	        	let disabled = false;
	        	if (systemic) { // 假如是内置角色
	        		disabled = (defaultPermissions.indexOf(one.id + '') != -1); // 内置角色的默认权限不能修改
	        	}
				//：key 为数据的唯一性标识，label 为显示文本，disabled 表示该项数据是否禁止转移
				// 目标列表中的数据项会同步到绑定至 v-model 的变量
				// 反引号中可以用`${变量}`
	        	permisionList.value.push({ key: one.id, label: `${one.moduleName}（${one.actionName}）`, disabled: disabled });
	        }
	    }).catch((err) => {
	      ElMessage({ message: '服务器错误', offset: 200, center: true })
	      console.log(err)
	    })
  }
  const dataFormSubmit =  () => {
    df.value.validate( async (valid) => {
      if (valid) {
        //因为用户是随机选择权限，所以对选中的权限排序
        dataForm.permissions.sort(function(a, b) {
            return a - b;
        });
        //判断用户选择的权限和原来的权限是否一致？把数组转换成字符串，简化比较两个数组是否一致
        if (dataForm.permissions.join() != oldPermissions.value.join()) {
            dataForm.changed = true;
        } else {
            dataForm.changed = false;
        }
		await post(`role/${!dataForm.id ? 'insert' : 'update'}`, dataForm).then((resp) =>{
            if (resp.data?.rows == 1) {
                ElMessage({ message: '操作成功', type: 'success', offset: 200, duration: 1200 });
                visible.value = false
				if (!dataForm.id) { // 新增成功
					emit('refreshDataList')  
				} else { // 更新成功
					emit('refreshUpdateEle', resp.data?.map)
				}
            } else {
                ElMessage({ message: '操作失败', type: 'error', offset: 200, duration: 1200 });
            }
        });
      }
    });
  }
  return { init, visible, systemic, df, dataForm, permisionList, oldPermissions, dataFormSubmit }
}
export default defineComponent({
	emits: ['refreshDataList','refreshUpdateEle'],
	setup (props, context) {
	  const { emit } = context 
	  const { init, visible, systemic, df, dataForm, permisionList, oldPermissions, dataFormSubmit } = pageInitEffect(emit)
	  return {
	    init, visible, systemic, df, dataForm, permisionList, oldPermissions, dataFormSubmit
	  }
	},
	data: function() {
		return {
			dataRule: {
				roleName: [
					{ required: true, pattern: '^[a-zA-Z0-9\u4e00-\u9fa5]{2,10}$', message: '角色名称格式错误' }
				],
				permissions: [
					{ required: true, trigger: 'blur', message: '角色没有关联权限' },
					{ required: false, trigger: 'change', message: '角色没有关联权限' }
				]
			}
		};
	}
});
</script>

<style lang="less" scoped="scoped">
.note {
	margin-left: 20px;
	color: #999;
}
</style>
