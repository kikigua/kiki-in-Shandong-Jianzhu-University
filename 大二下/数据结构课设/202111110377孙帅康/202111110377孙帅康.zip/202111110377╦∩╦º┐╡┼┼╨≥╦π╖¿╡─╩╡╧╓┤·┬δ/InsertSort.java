package sort;

import java.util.Comparator;

//ֱ�Ӳ�������
public class InsertSort {
    // a[0],..., a[length-1]�������
    @SuppressWarnings("unchecked")
    public static <T> T[] insertSort(T[] a) {// ʹ��T����Ȼ�򣬼���ʵ�ֵ�compareTo
        for (int i = 1; i < a.length; ++i) {
            T ai = a[i];
            int j;
            for (j = i - 1; j >= 0 && ((Comparable<T>) ai).compareTo(a[j]) < 0; j--)
                a[j + 1] = a[j];
            a[j + 1] = ai;
        }
        return a;
    }

    @SuppressWarnings("unchecked")
    public static <T> T[] insertSortSentinel(T a[]) { // ʹ��a[0]��Ϊ�ڱ�
        for (int i = 1; i < a.length; i++) {
            a[0] = a[i];
            int j;
            for (j = i - 1; ((Comparable<T>) a[0]).compareTo(a[j]) < 0; j--)
                a[j + 1] = a[j];
            a[j + 1] = a[0];
        }
        return a;
    }

    public static <T> T[] insertSort(T[] a, Comparator<T> cmp) {// ʹ����������
        for (int i = 1; i < a.length; i++) {
            T ai = a[i];
            int j;
            for (j = i - 1; j >= 0 && cmp.compare(ai, a[j]) < 0; j--)
                a[j + 1] = a[j];
            a[j + 1] = ai;
        }
        return a;
    }


    public static int[] insertSort(int[] a) {// ��Ի�����������
        for (int i = 1; i < a.length; i++) {
            int ai = a[i];
            int j;
            for (j = i - 1; j >= 0 && ai < a[j]; j--)
                a[j + 1] = a[j];
            a[j + 1] = ai;
        }
        return a;
    }

    public static void main(String[] args) {
        Integer[] data = { 9, 1, 8, 2, 3, 10, 4, 5, 6, 7, 9 };
//		insertSort(data, (l, r)-> Integer.compare(l, r));
        for (int i : insertSort(data))
            System.out.print(i + " ");
        System.out.println();
    }
}


