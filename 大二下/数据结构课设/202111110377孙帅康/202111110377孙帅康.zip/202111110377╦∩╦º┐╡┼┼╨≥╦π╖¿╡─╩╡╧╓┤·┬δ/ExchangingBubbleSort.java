package sort;

//�Ľ����ð������
public class ExchangingBubbleSort {

    @SuppressWarnings("unchecked")
    public static <T> T[] bubbleSort1(T[] a) {
        for (int i = 0; i < a.length - 1; ++i) {// ÿ����С�����ݵ�λ��
            boolean flag = true;// �Ƿ���û�����ݽ���
            for (int j = a.length - 1; j > i; --j) {// ͨ�������ҵ�[0,i]��С������
                if (((Comparable<T>) a[j]).compareTo(a[j - 1]) < 0) {
                    T t = a[j];
                    a[j] = a[j - 1];
                    a[j - 1] = t;
                    flag = false;
                }
            }
            if (flag)
                break;
        }
        return a;
    }

    // �������
    @SuppressWarnings("unchecked")
    public static <T> T[] bubbleSort2(T[] a) {
        int right = a.length;
        while (right != 1) {
            int t = 0;
            for (int j = 0; j < right - 1; j++) {
                if (((Comparable<T>) a[j]).compareTo(a[j + 1]) > 0) {
                    T aj = a[j];
                    a[j] = a[j + 1];
                    a[j + 1] = aj;
                    t = j;
                }
            }
            right = t + 1;
        }
        return a;
    }

    // С������
    @SuppressWarnings("unchecked")
    public static <T> T[] bubbleSort(T[] a) {
        int left = 0;
        while (left != a.length - 1) {
            int t = 0;
            for (int j = a.length - 1; j > left; --j) {
                if (((Comparable<T>) a[j]).compareTo(a[j - 1]) < 0) {
                    T aj = a[j];
                    a[j] = a[j - 1];
                    a[j - 1] = aj;
                    t = j;
                }
            }
            if (t == 0)// û�б仯
                break;
            left = t;// �µı仯����bubbleSort1��bubbleSort2��ȣ��ܼ��ٲ���Ҫ�ıȽϣ��ٶȿ죬����bubbleSort������ʵ��
        }
        return a;
    }
    public static void main(String[] args) {
        // TODO Auto-generated method stub
        Integer[] data = { 9, 2, 13, 4, 5, 8, 7, 6, 1 };
        for (int i : bubbleSort(data))
            System.out.print(i + " ");
        System.out.println();
    }

}


